import React, { useState, useEffect } from 'react';
import { View, StyleSheet, FlatList, TouchableOpacity } from 'react-native';
import { Text, Surface, FAB, TextInput, Button, Modal, Portal, Dialog } from 'react-native-paper';
import { SafeAreaView } from 'react-native-safe-area-context';
import { COLORS, SPACING, FONT_SIZE, BORDER_RADIUS } from '../constants/theme';
import { useAccountStore } from '../store/useAccountStore';
import { AccountRow } from '../database/schema';
import { formatCurrency } from '../utils/format';

const ICON_OPTIONS = ['💵', '🏦', '💳', '📱', '💬', '💰', '🪙', '🏧'];
const COLOR_OPTIONS = ['#27AE60', '#3498DB', '#E74C3C', '#1677FF', '#07C160', '#9B59B6', '#F39C12', '#E91E63'];

export default function AccountsScreen() {
  const { accounts, fetchAll, addAccount, updateAccount, deleteAccount } = useAccountStore();
  const [modalVisible, setModalVisible] = useState(false);
  const [editingAccount, setEditingAccount] = useState<AccountRow | null>(null);
  const [name, setName] = useState('');
  const [type, setType] = useState('other');
  const [icon, setIcon] = useState('💰');
  const [color, setColor] = useState('#3498DB');
  const [balance, setBalance] = useState('');
  const [dialogVisible, setDialogVisible] = useState(false);
  const [dialogTitle, setDialogTitle] = useState('');
  const [dialogMessage, setDialogMessage] = useState('');
  const [deleteTarget, setDeleteTarget] = useState<AccountRow | null>(null);

  const showAlert = (title: string, message: string) => {
    setDialogTitle(title);
    setDialogMessage(message);
    setDialogVisible(true);
  };

  const handleConfirmDelete = async () => {
    if (deleteTarget) {
      await deleteAccount(deleteTarget.id);
      setDeleteTarget(null);
      setDialogVisible(false);
      fetchAll();
    }
  };

  useEffect(() => {
    fetchAll();
  }, []);

  const totalBalance = accounts.reduce((sum, acc) => sum + acc.balance, 0);

  const handleAdd = () => {
    setEditingAccount(null);
    setName('');
    setType('other');
    setIcon('💰');
    setColor('#3498DB');
    setBalance('0');
    setModalVisible(true);
  };

  const handleEdit = (account: AccountRow) => {
    setEditingAccount(account);
    setName(account.name);
    setType(account.type);
    setIcon(account.icon);
    setColor(account.color);
    setBalance(account.balance.toString());
    setModalVisible(true);
  };

  const handleSave = async () => {
    if (!name.trim()) {
      showAlert('提示', '请输入账户名称');
      return;
    }

    const parsedBalance = parseFloat(balance) || 0;

    if (editingAccount) {
      await updateAccount(editingAccount.id, name, type, icon, color, parsedBalance);
    } else {
      await addAccount(name, type, icon, color);
    }
    setModalVisible(false);
  };

  const handleDelete = (account: AccountRow) => {
    setDeleteTarget(account);
    setDialogTitle('确认删除');
    setDialogMessage(`确定要删除账户"${account.name}"吗？`);
    setDialogVisible(true);
  };

  return (
    <SafeAreaView style={styles.safeArea} edges={['bottom']}>
      <View style={styles.container}>
        {/* Total Balance */}
        <Surface style={styles.totalCard} elevation={2}>
          <Text style={styles.totalLabel}>总资产</Text>
          <Text style={styles.totalAmount}>{formatCurrency(totalBalance)}</Text>
        </Surface>

        {/* Account List */}
        <FlatList
          data={accounts}
          keyExtractor={(item) => item.id}
          renderItem={({ item }) => (
            <TouchableOpacity onPress={() => handleEdit(item)} onLongPress={() => handleDelete(item)}>
              <Surface style={styles.accountCard} elevation={1}>
                <View style={[styles.iconContainer, { backgroundColor: item.color + '20' }]}>
                  <Text style={styles.accountIcon}>{item.icon}</Text>
                </View>
                <View style={styles.accountInfo}>
                  <Text style={styles.accountName}>{item.name}</Text>
                  <Text style={styles.accountType}>{item.type}</Text>
                </View>
                <Text style={styles.accountBalance}>{formatCurrency(item.balance)}</Text>
              </Surface>
            </TouchableOpacity>
          )}
          contentContainerStyle={styles.list}
        />

        {/* FAB */}
        <FAB
          icon="plus"
          style={styles.fab}
          onPress={handleAdd}
          color="#FFFFFF"
        />

        {/* Add/Edit Modal */}
        <Portal>
          <Modal
            visible={modalVisible}
            onDismiss={() => setModalVisible(false)}
            contentContainerStyle={styles.modal}
          >
            <Text style={styles.modalTitle}>{editingAccount ? '编辑账户' : '新增账户'}</Text>
            
            <TextInput
              label="账户名称"
              value={name}
              onChangeText={setName}
              mode="outlined"
              style={styles.input}
            />

            {editingAccount && (
              <TextInput
                label="余额"
                value={balance}
                onChangeText={setBalance}
                mode="outlined"
                style={styles.input}
                keyboardType="decimal-pad"
                left={<TextInput.Affix text="¥" />}
              />
            )}

            <Text style={styles.label}>选择图标</Text>
            <View style={styles.optionRow}>
              {ICON_OPTIONS.map(i => (
                <TouchableOpacity
                  key={i}
                  style={[styles.iconOption, icon === i && styles.iconOptionSelected]}
                  onPress={() => setIcon(i)}
                >
                  <Text style={styles.iconOptionText}>{i}</Text>
                </TouchableOpacity>
              ))}
            </View>

            <Text style={styles.label}>选择颜色</Text>
            <View style={styles.optionRow}>
              {COLOR_OPTIONS.map(c => (
                <TouchableOpacity
                  key={c}
                  style={[styles.colorOption, { backgroundColor: c }, color === c && styles.colorOptionSelected]}
                  onPress={() => setColor(c)}
                />
              ))}
            </View>

            <View style={styles.modalActions}>
              {editingAccount && (
                <Button
                  mode="outlined"
                  onPress={() => {
                    setModalVisible(false);
                    handleDelete(editingAccount);
                  }}
                  textColor="#F44336"
                  style={styles.deleteBtn}
                >
                  删除
                </Button>
              )}
              <View style={{ flex: 1 }} />
              <Button mode="outlined" onPress={() => setModalVisible(false)} style={styles.cancelBtn}>
                取消
              </Button>
              <Button mode="contained" onPress={handleSave} style={styles.saveBtn}>
                保存
              </Button>
            </View>
          </Modal>
        </Portal>

        <Portal>
          <Dialog visible={dialogVisible} onDismiss={() => setDialogVisible(false)}>
            <Dialog.Title>{dialogTitle}</Dialog.Title>
            <Dialog.Content>
              <Text>{dialogMessage}</Text>
            </Dialog.Content>
            <Dialog.Actions>
              <Button onPress={() => { setDeleteTarget(null); setDialogVisible(false); }}>取消</Button>
              {deleteTarget && (
                <Button onPress={handleConfirmDelete} textColor="#F44336">删除</Button>
              )}
            </Dialog.Actions>
          </Dialog>
        </Portal>
      </View>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  safeArea: {
    flex: 1,
    backgroundColor: '#FFFFFF',
  },
  container: {
    flex: 1,
    backgroundColor: COLORS.surface,
  },
  totalCard: {
    margin: SPACING.lg,
    padding: SPACING.xl,
    borderRadius: BORDER_RADIUS.lg,
    backgroundColor: COLORS.primary,
    alignItems: 'center',
  },
  totalLabel: {
    fontSize: FONT_SIZE.md,
    color: 'rgba(255,255,255,0.8)',
  },
  totalAmount: {
    fontSize: FONT_SIZE.header,
    fontWeight: '700',
    color: '#FFFFFF',
    marginTop: 4,
  },
  list: {
    paddingHorizontal: SPACING.lg,
  },
  accountCard: {
    flexDirection: 'row',
    alignItems: 'center',
    padding: SPACING.lg,
    marginBottom: SPACING.sm,
    borderRadius: BORDER_RADIUS.lg,
    backgroundColor: '#FFFFFF',
  },
  iconContainer: {
    width: 44,
    height: 44,
    borderRadius: BORDER_RADIUS.lg,
    justifyContent: 'center',
    alignItems: 'center',
  },
  accountIcon: {
    fontSize: 22,
  },
  accountInfo: {
    flex: 1,
    marginLeft: SPACING.md,
  },
  accountName: {
    fontSize: FONT_SIZE.lg,
    fontWeight: '600',
    color: COLORS.text,
  },
  accountType: {
    fontSize: FONT_SIZE.sm,
    color: COLORS.textSecondary,
  },
  accountBalance: {
    fontSize: FONT_SIZE.lg,
    fontWeight: '600',
    color: COLORS.text,
  },
  fab: {
    position: 'absolute',
    right: SPACING.lg,
    bottom: SPACING.xl,
    backgroundColor: COLORS.primary,
  },
  modal: {
    backgroundColor: 'white',
    padding: SPACING.xl,
    margin: SPACING.lg,
    borderRadius: BORDER_RADIUS.lg,
  },
  modalTitle: {
    fontSize: FONT_SIZE.xl,
    fontWeight: '700',
    color: COLORS.text,
    marginBottom: SPACING.lg,
  },
  input: {
    marginBottom: SPACING.md,
    backgroundColor: '#FFFFFF',
  },
  label: {
    fontSize: FONT_SIZE.md,
    color: COLORS.text,
    marginBottom: SPACING.sm,
    fontWeight: '500',
  },
  optionRow: {
    flexDirection: 'row',
    gap: SPACING.sm,
    marginBottom: SPACING.lg,
    flexWrap: 'wrap',
  },
  iconOption: {
    width: 44,
    height: 44,
    borderRadius: BORDER_RADIUS.md,
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: COLORS.surface,
    borderWidth: 2,
    borderColor: 'transparent',
  },
  iconOptionSelected: {
    borderColor: COLORS.primary,
    backgroundColor: COLORS.primaryLight,
  },
  iconOptionText: {
    fontSize: 22,
  },
  colorOption: {
    width: 36,
    height: 36,
    borderRadius: BORDER_RADIUS.full,
    borderWidth: 3,
    borderColor: 'transparent',
  },
  colorOptionSelected: {
    borderColor: COLORS.text,
  },
  modalActions: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: SPACING.sm,
    marginTop: SPACING.md,
  },
  deleteBtn: {
    borderColor: '#F44336',
  },
  cancelBtn: {
    borderColor: COLORS.border,
  },
  saveBtn: {
    backgroundColor: COLORS.primary,
  },
});
