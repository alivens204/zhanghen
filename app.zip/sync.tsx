import React, { useState, useEffect } from 'react';
import { View, StyleSheet, ScrollView } from 'react-native';
import { Text, Button, Surface, Dialog, Portal } from 'react-native-paper';
import { SafeAreaView } from 'react-native-safe-area-context';
import { MaterialCommunityIcons } from '@expo/vector-icons';
import { useRouter } from 'expo-router';
import { COLORS, SPACING, FONT_SIZE, BORDER_RADIUS } from '../constants/theme';
import { pushToCloud, pullFromCloud, getServerStatus } from '../sync/cloudSync';
import { useRecordStore } from '../store/useRecordStore';
import { useAccountStore } from '../store/useAccountStore';
import { useBudgetStore } from '../store/useBudgetStore';

export default function SyncScreen() {
  const router = useRouter();
  const [loading, setLoading] = useState(false);
  const [serverConnected, setServerConnected] = useState(false);
  const [lastSync, setLastSync] = useState<string>('');
  const [dialogVisible, setDialogVisible] = useState(false);
  const [dialogTitle, setDialogTitle] = useState('');
  const [dialogMessage, setDialogMessage] = useState('');
  const [confirmAction, setConfirmAction] = useState<(() => void) | null>(null);
  const { fetchAll: fetchRecords } = useRecordStore();
  const { fetchAll: fetchAccounts } = useAccountStore();
  const { fetchAll: fetchBudgets } = useBudgetStore();

  const showAlert = (title: string, message: string) => {
    setDialogTitle(title);
    setDialogMessage(message);
    setConfirmAction(null);
    setDialogVisible(true);
  };

  const showConfirm = (title: string, message: string, onConfirm: () => void) => {
    setDialogTitle(title);
    setDialogMessage(message);
    setConfirmAction(() => onConfirm);
    setDialogVisible(true);
  };

  useEffect(() => {
    checkStatus();
  }, []);

  const checkStatus = async () => {
    const status = await getServerStatus();
    setServerConnected(status.connected);
  };

  const handlePush = async () => {
    showConfirm('上传数据到云端', '将本地所有数据上传到 MySQL 云端，重复数据会自动更新。', async () => {
      setLoading(true);
      try {
        const result = await pushToCloud();
        if (result.success) {
          setLastSync(new Date().toLocaleString());
          showAlert('上传成功', result.message);
        } else {
          showAlert('上传失败', result.message);
        }
      } catch (error: any) {
        showAlert('错误', error.message);
      } finally {
        setLoading(false);
      }
    });
  };

  const handlePull = async () => {
    showConfirm('从云端导入', '将 MySQL 云端的所有数据导入到本地，覆盖本地已有数据。\n\n建议先导出本地数据备份。', async () => {
      setLoading(true);
      try {
        const result = await pullFromCloud();
        if (result.success) {
          setLastSync(new Date().toLocaleString());
          await Promise.all([fetchRecords(), fetchAccounts(), fetchBudgets()]);
          showAlert('导入成功', result.message);
        } else {
          showAlert('导入失败', result.message);
        }
      } catch (error: any) {
        showAlert('错误', error.message);
      } finally {
        setLoading(false);
      }
    });
  };

  return (
    <SafeAreaView style={styles.safeArea} edges={['bottom']}>
      <ScrollView style={styles.container}>
        {/* Connection Status */}
        <Surface style={styles.statusCard} elevation={2}>
          <View style={styles.statusRow}>
            <View style={[styles.statusDot, { backgroundColor: serverConnected ? COLORS.success : COLORS.expense }]} />
            <View>
              <Text style={styles.statusText}>
                {serverConnected ? 'API 服务已连接' : 'API 服务未连接'}
              </Text>
              <Text style={styles.statusHint}>
                {serverConnected ? '可以进行数据同步' : '请先在数据库配置中连接 API 服务器'}
              </Text>
            </View>
          </View>
          {lastSync ? (
            <Text style={styles.lastSync}>上次同步: {lastSync}</Text>
          ) : null}
        </Surface>

        {/* Push to Cloud */}
        <Surface style={styles.actionCard} elevation={2}>
          <View style={styles.actionHeader}>
            <View style={[styles.actionIcon, { backgroundColor: COLORS.primaryLight }]}>
              <MaterialCommunityIcons name="cloud-upload" size={28} color={COLORS.primary} />
            </View>
            <View style={styles.actionInfo}>
              <Text style={styles.actionTitle}>上传到云端</Text>
              <Text style={styles.actionDesc}>将本地数据同步到 MySQL 数据库</Text>
            </View>
          </View>
          <Text style={styles.actionDetail}>
            上传所有账户、分类、交易记录和预算设置到云端。已存在的数据会自动更新，不会产生重复。
          </Text>
          <Button
            mode="contained"
            onPress={handlePush}
            loading={loading}
            disabled={!serverConnected}
            style={styles.actionBtn}
            buttonColor={COLORS.primary}
            icon="cloud-upload"
          >
            上传本地数据
          </Button>
        </Surface>

        {/* Pull from Cloud */}
        <Surface style={styles.actionCard} elevation={2}>
          <View style={styles.actionHeader}>
            <View style={[styles.actionIcon, { backgroundColor: COLORS.incomeLight }]}>
              <MaterialCommunityIcons name="cloud-download" size={28} color={COLORS.income} />
            </View>
            <View style={styles.actionInfo}>
              <Text style={styles.actionTitle}>从云端导入</Text>
              <Text style={styles.actionDesc}>将 MySQL 数据库数据下载到本地</Text>
            </View>
          </View>
          <Text style={styles.actionDetail}>
            从云端数据库拉取所有数据到本地。注意：这会覆盖本地现有数据，建议先上传备份。
          </Text>
          <Button
            mode="contained"
            onPress={handlePull}
            loading={loading}
            disabled={!serverConnected}
            style={styles.actionBtn}
            buttonColor={COLORS.income}
            icon="cloud-download"
          >
            导入云端数据
          </Button>
        </Surface>

        {/* Quick Actions */}
        <Surface style={styles.actionCard} elevation={1}>
          <View style={styles.actionHeader}>
            <View style={[styles.actionIcon, { backgroundColor: COLORS.pendingLight }]}>
              <MaterialCommunityIcons name="database-cog" size={28} color={COLORS.pending} />
            </View>
            <View style={styles.actionInfo}>
              <Text style={styles.actionTitle}>数据库配置</Text>
              <Text style={styles.actionDesc}>配置 API 服务器和 MySQL 连接</Text>
            </View>
          </View>
          <Button
            mode="outlined"
            onPress={() => router.push('/db-config')}
            style={styles.actionBtn}
            icon="cog"
          >
            打开配置
          </Button>
        </Surface>

        {/* Sync Flow */}
        <Surface style={styles.flowCard} elevation={1}>
          <Text style={styles.flowTitle}>🔄 同步流程</Text>
          <View style={styles.flowStep}>
            <Text style={styles.flowNumber}>1</Text>
            <Text style={styles.flowText}>在服务器部署 PHP API（php-api 目录）</Text>
          </View>
          <View style={styles.flowStep}>
            <Text style={styles.flowNumber}>2</Text>
            <Text style={styles.flowText}>填写 API 地址和 MySQL 连接信息</Text>
          </View>
          <View style={styles.flowStep}>
            <Text style={styles.flowNumber}>3</Text>
            <Text style={styles.flowText}>点击「测试连接」验证</Text>
          </View>
          <View style={styles.flowStep}>
            <Text style={styles.flowNumber}>4</Text>
            <Text style={styles.flowText}>点击「初始化数据表」创建表结构</Text>
          </View>
          <View style={styles.flowStep}>
            <Text style={styles.flowNumber}>5</Text>
            <Text style={styles.flowText}>返回此页面进行上传/导入操作</Text>
          </View>
        </Surface>

        <View style={{ height: 100 }} />
      </ScrollView>

      {/* Dialog */}
      <Portal>
        <Dialog visible={dialogVisible} onDismiss={() => { setDialogVisible(false); setConfirmAction(null); }}>
          <Dialog.Title>{dialogTitle}</Dialog.Title>
          <Dialog.Content>
            <Text>{dialogMessage}</Text>
          </Dialog.Content>
          <Dialog.Actions>
            {confirmAction && (
              <Button onPress={() => { setDialogVisible(false); confirmAction(); setConfirmAction(null); }}>确认</Button>
            )}
            <Button onPress={() => { setDialogVisible(false); setConfirmAction(null); }}>{confirmAction ? '取消' : '确定'}</Button>
          </Dialog.Actions>
        </Dialog>
      </Portal>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  safeArea: {
    flex: 1,
    backgroundColor: '#FFFFFF',
  },
  container: {
    flex: 1,
    backgroundColor: COLORS.surface,
    padding: SPACING.lg,
  },
  statusCard: {
    borderRadius: BORDER_RADIUS.lg,
    padding: SPACING.lg,
    backgroundColor: '#FFFFFF',
    marginBottom: SPACING.md,
  },
  statusRow: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: SPACING.md,
  },
  statusDot: {
    width: 12,
    height: 12,
    borderRadius: 6,
  },
  statusText: {
    fontSize: FONT_SIZE.md,
    fontWeight: '600',
    color: COLORS.text,
  },
  statusHint: {
    fontSize: FONT_SIZE.sm,
    color: COLORS.textSecondary,
    marginTop: 2,
  },
  lastSync: {
    fontSize: FONT_SIZE.sm,
    color: COLORS.textLight,
    marginTop: SPACING.sm,
  },
  actionCard: {
    borderRadius: BORDER_RADIUS.lg,
    padding: SPACING.lg,
    backgroundColor: '#FFFFFF',
    marginBottom: SPACING.md,
  },
  actionHeader: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: SPACING.md,
    marginBottom: SPACING.md,
  },
  actionIcon: {
    width: 50,
    height: 50,
    borderRadius: BORDER_RADIUS.lg,
    justifyContent: 'center',
    alignItems: 'center',
  },
  actionInfo: {
    flex: 1,
  },
  actionTitle: {
    fontSize: FONT_SIZE.lg,
    fontWeight: '600',
    color: COLORS.text,
  },
  actionDesc: {
    fontSize: FONT_SIZE.sm,
    color: COLORS.textSecondary,
    marginTop: 2,
  },
  actionDetail: {
    fontSize: FONT_SIZE.sm,
    color: COLORS.textSecondary,
    lineHeight: 20,
    marginBottom: SPACING.md,
  },
  actionBtn: {
    borderRadius: BORDER_RADIUS.md,
  },
  flowCard: {
    borderRadius: BORDER_RADIUS.lg,
    padding: SPACING.lg,
    backgroundColor: '#FFFFFF',
    marginBottom: SPACING.md,
  },
  flowTitle: {
    fontSize: FONT_SIZE.lg,
    fontWeight: '600',
    color: COLORS.text,
    marginBottom: SPACING.md,
  },
  flowStep: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: SPACING.md,
    marginBottom: SPACING.sm,
  },
  flowNumber: {
    width: 24,
    height: 24,
    borderRadius: 12,
    backgroundColor: COLORS.primary,
    color: '#FFFFFF',
    textAlign: 'center',
    lineHeight: 24,
    fontSize: FONT_SIZE.sm,
    fontWeight: '700',
    overflow: 'hidden',
  },
  flowText: {
    fontSize: FONT_SIZE.md,
    color: COLORS.text,
    flex: 1,
  },
});
