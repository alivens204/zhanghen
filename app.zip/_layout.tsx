import { useEffect } from 'react';
import { Stack } from 'expo-router';
import { PaperProvider, MD3LightTheme } from 'react-native-paper';
import { StatusBar } from 'expo-status-bar';
import { GestureHandlerRootView } from 'react-native-gesture-handler';
import { initializeDatabase } from '../database/migration';
import { COLORS } from '../constants/theme';

const theme = {
  ...MD3LightTheme,
  colors: {
    ...MD3LightTheme.colors,
    primary: COLORS.primary,
    background: COLORS.background,
    surface: COLORS.surface,
  },
};

export default function RootLayout() {
  useEffect(() => {
    initializeDatabase();
  }, []);

  return (
    <GestureHandlerRootView style={{ flex: 1 }}>
    <PaperProvider theme={theme}>
      <StatusBar style="dark" />
      <Stack screenOptions={{ headerShown: false }}>
        <Stack.Screen name="(tabs)" />
        <Stack.Screen 
          name="add-record" 
          options={{ 
            presentation: 'modal',
            headerShown: true,
            title: '记一笔',
          }} 
        />
        <Stack.Screen name="budget" options={{ headerShown: true, title: '预算管理' }} />
        <Stack.Screen name="accounts" options={{ headerShown: true, title: '账户管理' }} />
        <Stack.Screen name="reimbursement" options={{ headerShown: true, title: '报销管理' }} />

      </Stack>
    </PaperProvider>
    </GestureHandlerRootView>
  );
}
