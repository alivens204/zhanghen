import React, { useState, useEffect } from 'react';
import { View, StyleSheet, ScrollView, Dimensions } from 'react-native';
import { Text, Surface, SegmentedButtons } from 'react-native-paper';
import { SafeAreaView } from 'react-native-safe-area-context';
import dayjs from 'dayjs';
import { COLORS, SPACING, FONT_SIZE, BORDER_RADIUS } from '../../constants/theme';
import { getYearlyTotal, getYearlyMonthlySummary, getCategoryStats } from '../../database/queries';
import { ALL_CATEGORIES } from '../../constants/categories';
import { formatCurrencyShort } from '../../utils/format';

const screenWidth = Dimensions.get('window').width;

export default function StatsScreen() {
  const [year, setYear] = useState(dayjs().format('YYYY'));
  const [period, setPeriod] = useState<'month' | 'year'>('year');
  
  const [yearTotal, setYearTotal] = useState({ income: 0, expense: 0 });
  const [monthlyData, setMonthlyData] = useState<{ month: string; income: number; expense: number }[]>([]);
  const [categoryStats, setCategoryStats] = useState<{ category_id: string; total: number }[]>([]);

  useEffect(() => {
    loadStats();
  }, [year]);

  const loadStats = async () => {
    try {
      const [total, monthly, catStats] = await Promise.all([
        getYearlyTotal(year),
        getYearlyMonthlySummary(year),
        getCategoryStats(`${year}-01-01`, `${year}-12-31`, 'expense'),
      ]);
      setYearTotal(total);
      setMonthlyData(monthly);
      setCategoryStats(catStats);
    } catch (error) {
      console.error('Load stats error:', error);
    }
  };

  const maxAmount = Math.max(
    ...monthlyData.map(d => Math.max(d.income, d.expense)),
    1
  );

  const totalExpense = categoryStats.reduce((sum, c) => sum + c.total, 0);

  return (
    <SafeAreaView style={styles.safeArea} edges={['top']}>
      <ScrollView style={styles.container}>
              {/* Header */}
              <View style={styles.header}>
                <Text style={styles.title}>统计</Text>
              </View>
        {/* Year Selector */}
        <View style={styles.yearSelector}>
          <SegmentedButtons
            value={year}
            onValueChange={setYear}
            buttons={[
              { value: (parseInt(year) - 1).toString(), label: `${parseInt(year) - 1}` },
              { value: year, label: year },
              { value: (parseInt(year) + 1).toString(), label: `${parseInt(year) + 1}` },
            ]}
          />
        </View>

        {/* Year Summary */}
        <Surface style={styles.summaryCard} elevation={2}>
          <Text style={styles.cardTitle}>{year}年度总览</Text>
          <View style={styles.summaryRow}>
            <View style={styles.summaryItem}>
              <Text style={styles.summaryLabel}>总收入</Text>
              <Text style={styles.incomeAmount}>{formatCurrencyShort(yearTotal.income)}</Text>
            </View>
            <View style={styles.summaryItem}>
              <Text style={styles.summaryLabel}>总支出</Text>
              <Text style={styles.expenseAmount}>{formatCurrencyShort(yearTotal.expense)}</Text>
            </View>
            <View style={styles.summaryItem}>
              <Text style={styles.summaryLabel}>结余</Text>
              <Text style={[styles.netAmount, (yearTotal.income - yearTotal.expense) >= 0 ? styles.positive : styles.negative]}>
                {formatCurrencyShort(yearTotal.income - yearTotal.expense)}
              </Text>
            </View>
          </View>
        </Surface>

        {/* Monthly Trend Bar Chart */}
        <Surface style={styles.chartCard} elevation={2}>
          <Text style={styles.cardTitle}>月度趋势</Text>
          <View style={styles.barChart}>
            {monthlyData.map((item) => {
              const incomeHeight = (item.income / maxAmount) * 100;
              const expenseHeight = (item.expense / maxAmount) * 100;
              return (
                <View key={item.month} style={styles.barGroup}>
                  <View style={styles.bars}>
                    <View style={[styles.bar, styles.incomeBar, { height: Math.max(incomeHeight, 2) }]} />
                    <View style={[styles.bar, styles.expenseBar, { height: Math.max(expenseHeight, 2) }]} />
                  </View>
                  <Text style={styles.barLabel}>{parseInt(item.month)}月</Text>
                </View>
              );
            })}
          </View>
          <View style={styles.legend}>
            <View style={styles.legendItem}>
              <View style={[styles.legendDot, { backgroundColor: COLORS.income }]} />
              <Text style={styles.legendText}>收入</Text>
            </View>
            <View style={styles.legendItem}>
              <View style={[styles.legendDot, { backgroundColor: COLORS.expense }]} />
              <Text style={styles.legendText}>支出</Text>
            </View>
          </View>
        </Surface>

        {/* Category Pie Chart (simplified as list) */}
        <Surface style={styles.chartCard} elevation={2}>
          <Text style={styles.cardTitle}>支出分类</Text>
          {categoryStats.length === 0 ? (
            <Text style={styles.noData}>暂无数据</Text>
          ) : (
            categoryStats.map((item, index) => {
              const category = ALL_CATEGORIES.find(c => c.id === item.category_id);
              const percentage = totalExpense > 0 ? (item.total / totalExpense * 100) : 0;
              return (
                <View key={item.category_id} style={styles.categoryItem}>
                  <View style={styles.categoryLeft}>
                    <Text style={styles.categoryIcon}>{category?.icon || '📦'}</Text>
                    <Text style={styles.categoryName}>{category?.name || '未知'}</Text>
                  </View>
                  <View style={styles.categoryRight}>
                    <View style={styles.progressContainer}>
                      <View style={[styles.progressBar, { width: `${percentage}%`, backgroundColor: category?.color || COLORS.textLight }]} />
                    </View>
                    <Text style={styles.categoryAmount}>{formatCurrencyShort(item.total)}</Text>
                    <Text style={styles.categoryPercent}>{percentage.toFixed(1)}%</Text>
                  </View>
                </View>
              );
            })
          )}
        </Surface>

        <View style={{ height: 100 }} />
      </ScrollView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  safeArea: {
    flex: 1,
    backgroundColor: '#FFFFFF',
  },
  container: {
    flex: 1,
    backgroundColor: COLORS.surface,
  },
  header: {
    paddingHorizontal: SPACING.lg,
    paddingVertical: SPACING.md,
    backgroundColor: '#fff',
  },
  title: {
    fontSize: FONT_SIZE.xxl,
    fontWeight: '700',
    color: COLORS.text,
  },

  yearSelector: {
    paddingHorizontal: SPACING.lg,
    marginBottom: SPACING.md,
  },
  summaryCard: {
    marginHorizontal: SPACING.lg,
    marginBottom: SPACING.md,
    padding: SPACING.lg,
    borderRadius: BORDER_RADIUS.lg,
    backgroundColor: '#FFFFFF',
  },
  chartCard: {
    marginHorizontal: SPACING.lg,
    marginBottom: SPACING.md,
    padding: SPACING.lg,
    borderRadius: BORDER_RADIUS.lg,
    backgroundColor: '#FFFFFF',
  },
  cardTitle: {
    fontSize: FONT_SIZE.lg,
    fontWeight: '600',
    color: COLORS.text,
    marginBottom: SPACING.md,
  },
  summaryRow: {
    flexDirection: 'row',
    justifyContent: 'space-around',
  },
  summaryItem: {
    alignItems: 'center',
  },
  summaryLabel: {
    fontSize: FONT_SIZE.sm,
    color: COLORS.textSecondary,
    marginBottom: 4,
  },
  incomeAmount: {
    fontSize: FONT_SIZE.xl,
    fontWeight: '700',
    color: COLORS.income,
  },
  expenseAmount: {
    fontSize: FONT_SIZE.xl,
    fontWeight: '700',
    color: COLORS.expense,
  },
  netAmount: {
    fontSize: FONT_SIZE.xl,
    fontWeight: '700',
  },
  positive: { color: COLORS.income },
  negative: { color: COLORS.expense },
  barChart: {
    flexDirection: 'row',
    justifyContent: 'space-around',
    alignItems: 'flex-end',
    height: 120,
    marginBottom: SPACING.md,
  },
  barGroup: {
    alignItems: 'center',
    flex: 1,
  },
  bars: {
    flexDirection: 'row',
    alignItems: 'flex-end',
    gap: 2,
    height: 100,
  },
  bar: {
    width: 10,
    borderRadius: 2,
  },
  incomeBar: {
    backgroundColor: COLORS.income,
  },
  expenseBar: {
    backgroundColor: COLORS.expense,
  },
  barLabel: {
    fontSize: FONT_SIZE.xs,
    color: COLORS.textLight,
    marginTop: 4,
  },
  legend: {
    flexDirection: 'row',
    justifyContent: 'center',
    gap: SPACING.lg,
  },
  legendItem: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 4,
  },
  legendDot: {
    width: 10,
    height: 10,
    borderRadius: 5,
  },
  legendText: {
    fontSize: FONT_SIZE.sm,
    color: COLORS.textSecondary,
  },
  categoryItem: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    paddingVertical: SPACING.sm,
    borderBottomWidth: 1,
    borderBottomColor: COLORS.border,
  },
  categoryLeft: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: SPACING.sm,
  },
  categoryIcon: {
    fontSize: 20,
  },
  categoryName: {
    fontSize: FONT_SIZE.md,
    color: COLORS.text,
  },
  categoryRight: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: SPACING.sm,
    flex: 1,
    justifyContent: 'flex-end',
  },
  progressContainer: {
    width: 60,
    height: 6,
    backgroundColor: COLORS.surface,
    borderRadius: 3,
    overflow: 'hidden',
  },
  progressBar: {
    height: '100%',
    borderRadius: 3,
  },
  categoryAmount: {
    fontSize: FONT_SIZE.sm,
    color: COLORS.text,
    fontWeight: '500',
    minWidth: 60,
    textAlign: 'right',
  },
  categoryPercent: {
    fontSize: FONT_SIZE.xs,
    color: COLORS.textLight,
    minWidth: 40,
    textAlign: 'right',
  },
  noData: {
    fontSize: FONT_SIZE.md,
    color: COLORS.textLight,
    textAlign: 'center',
    paddingVertical: SPACING.xl,
  },
});
