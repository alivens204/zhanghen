import React, { useState, useEffect, useCallback } from 'react';
import { View, StyleSheet, FlatList, SectionList, TouchableOpacity, Alert } from 'react-native';
import { Text, Chip, Surface, Dialog, Button, Portal } from 'react-native-paper';
import { useRouter } from 'expo-router';
import { SafeAreaView } from 'react-native-safe-area-context';
import { COLORS, SPACING, FONT_SIZE, BORDER_RADIUS } from '../../constants/theme';
import { TransactionItem } from '../../components/TransactionItem';
import { useRecordStore } from '../../store/useRecordStore';
import { TransactionRow } from '../../database/schema';
import { formatDateChinese, getWeekday, formatCurrencyShort } from '../../utils/format';
import dayjs from 'dayjs';

type FilterType = 'all' | 'pending' | 'reimbursed';

const FILTERS: { value: FilterType; label: string }[] = [
  { value: 'all', label: '全部' },
  { value: 'pending', label: '待报销' },
  { value: 'reimbursed', label: '已报销' },
];

export default function RecordsScreen() {
  const router = useRouter();
  const { transactions, fetchAll, deleteTransaction } = useRecordStore();
  const [filter, setFilter] = useState<FilterType>('all');
  const [deleteDialogVisible, setDeleteDialogVisible] = useState(false);
  const [selectedTx, setSelectedTx] = useState<{ id: string; note: string } | null>(null);

  useEffect(() => {
    fetchAll();
  }, []);

  const filteredTransactions = filter === 'all'
    ? transactions
    : transactions.filter(tx => {
        if (filter === 'reimbursed') {
          return tx.reimbursement_status === 'reimbursed' || tx.reimbursement_status === 'partial';
        }
        return tx.reimbursement_status === filter;
      });

  // Group by date, then by month
  const groupedData = filteredTransactions.reduce((acc, tx) => {
    if (!acc[tx.date]) {
      acc[tx.date] = [];
    }
    acc[tx.date].push(tx);
    return acc;
  }, {} as Record<string, TransactionRow[]>);

  // Build sections with month headers
  interface Section {
    title: string;
    isMonth: boolean;
    data: TransactionRow[];
  }

  const allDates = Object.keys(groupedData).sort((a, b) => b.localeCompare(a));
  const sections: Section[] = [];
  let currentMonth = '';

  for (const date of allDates) {
    const month = date.slice(0, 7); // YYYY-MM
    if (month !== currentMonth) {
      currentMonth = month;
      const monthNum = parseInt(date.slice(5, 7));
      const monthNames = ['', '一月', '二月', '三月', '四月', '五月', '六月', '七月', '八月', '九月', '十月', '十一月', '十二月'];
      sections.push({
        title: monthNames[monthNum],
        isMonth: true,
        data: [],
      });
    }
    sections.push({
      title: date,
      isMonth: false,
      data: groupedData[date],
    });
  }

  const totalIncome = filteredTransactions
    .filter(t => t.type === 'income')
    .reduce((sum, t) => sum + t.amount, 0);
  const totalExpense = filteredTransactions
    .filter(t => t.type === 'expense')
    .reduce((sum, t) => sum + t.amount, 0);

  const handleTransactionPress = (tx: TransactionRow) => {
    router.push({
      pathname: '/add-record',
      params: {
        id: tx.id,
        amount: tx.amount.toString(),
        type: tx.type,
        categoryId: tx.category_id,
        accountId: tx.account_id,
        note: tx.note,
        date: tx.date,
        time: tx.time,
        reimbursementStatus: tx.reimbursement_status,
      },
    });
  };

  const confirmDelete = async () => {
    if (selectedTx) {
      await deleteTransaction(selectedTx.id);
      setDeleteDialogVisible(false);
      setSelectedTx(null);
      fetchAll();
    }
  };

  return (
    <SafeAreaView style={styles.safeArea} edges={['top']}>
      <View style={styles.container}>
              {/* Header */}
              <View style={styles.header}>
                <Text style={styles.title}>全部记录</Text>
              </View>
        {/* Filter Chips */}
        <View style={styles.filterContainer}>
          {FILTERS.map(f => (
            <Chip
              key={f.value}
              selected={filter === f.value}
              onPress={() => setFilter(f.value)}
              style={[styles.chip, filter === f.value && styles.chipSelected]}
              textStyle={[styles.chipText, filter === f.value && styles.chipTextSelected]}
              mode={filter === f.value ? 'flat' : 'outlined'}
            >
              {f.label}
            </Chip>
          ))}
        </View>

        {/* Summary */}
        {filter !== 'all' && (
          <Surface style={styles.summaryCard} elevation={1}>
            <Text style={styles.summaryText}>
              收入 {formatCurrencyShort(totalIncome)} · 支出 {formatCurrencyShort(totalExpense)}
            </Text>
          </Surface>
        )}

        {/* Transaction List */}
        <SectionList
          sections={sections}
          keyExtractor={(item) => item.id}
          renderSectionHeader={({ section }) => {
            if (section.isMonth) {
              return (
                <View style={styles.monthHeader}>
                  <Text style={styles.monthHeaderText}>{section.title}</Text>
                </View>
              );
            }
            const day = dayjs(section.title).format('D');
            const weekday = ['周日', '周一', '周二', '周三', '周四', '周五', '周六'][dayjs(section.title).day()];
            const dayIncome = section.data.filter(t => t.type === 'income').reduce((s, t) => s + t.amount, 0);
            const dayExpense = section.data.filter(t => t.type === 'expense').reduce((s, t) => s + t.amount, 0);
            return (
              <View style={styles.sectionHeader}>
                <Text style={styles.sectionDate}>{day}日 {weekday}</Text>
                <View style={styles.sectionSummary}>
                  {dayIncome > 0 && <Text style={styles.sectionIncome}>+{formatCurrencyShort(dayIncome)}</Text>}
                  {dayExpense > 0 && <Text style={styles.sectionExpense}>-{formatCurrencyShort(dayExpense)}</Text>}
                </View>
              </View>
            );
          }}
          renderItem={({ item }) => (
            <TransactionItem
              id={item.id}
              amount={item.amount}
              type={item.type as 'income' | 'expense'}
              categoryId={item.category_id}
              note={item.note}
              time={item.time}
              reimbursementStatus={item.reimbursement_status}
              onPress={() => handleTransactionPress(item)}
              onDelete={() => {
                setSelectedTx({ id: item.id, note: item.note });
                setDeleteDialogVisible(true);
              }}
            />
          )}
          ListEmptyComponent={
            <View style={styles.emptyContainer}>
              <Text style={styles.emptyText}>暂无记录</Text>
            </View>
          }
          stickySectionHeadersEnabled={false}
        />
      </View>

      {/* Delete Dialog */}
      <Portal>
        <Dialog visible={deleteDialogVisible} onDismiss={() => setDeleteDialogVisible(false)}>
          <Dialog.Title>删除记录</Dialog.Title>
          <Dialog.Content>
            <Text>确定要删除「{selectedTx?.note || '无备注'}」吗？</Text>
          </Dialog.Content>
          <Dialog.Actions>
            <Button onPress={() => setDeleteDialogVisible(false)}>取消</Button>
            <Button onPress={confirmDelete} textColor="#F44336">删除</Button>
          </Dialog.Actions>
        </Dialog>
      </Portal>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  safeArea: {
    flex: 1,
    backgroundColor: '#FFFFFF',
  },
  container: {
    flex: 1,
    backgroundColor: COLORS.surface,
  },
  header: {
    paddingHorizontal: SPACING.lg,
    paddingVertical: SPACING.md,
    backgroundColor: '#fff',
  },
  title: {
    fontSize: FONT_SIZE.xxl,
    fontWeight: '700',
    color: COLORS.text,
  },

  filterContainer: {
    flexDirection: 'row',
    paddingHorizontal: SPACING.lg,
    paddingBottom: SPACING.sm,
    gap: SPACING.sm,
    flexWrap: 'wrap',
  },
  chip: {
    backgroundColor: '#FFFFFF',
  },
  chipSelected: {
    backgroundColor: COLORS.primaryLight,
  },
  chipText: {
    fontSize: FONT_SIZE.sm,
    color: COLORS.textSecondary,
  },
  chipTextSelected: {
    color: COLORS.primary,
    fontWeight: '600',
  },
  summaryCard: {
    marginHorizontal: SPACING.lg,
    marginBottom: SPACING.sm,
    padding: SPACING.md,
    borderRadius: BORDER_RADIUS.md,
    backgroundColor: '#FFFFFF',
  },
  summaryText: {
    fontSize: FONT_SIZE.sm,
    color: COLORS.textSecondary,
    textAlign: 'center',
  },
  monthHeader: {
    paddingHorizontal: SPACING.lg,
    paddingVertical: SPACING.md,
    backgroundColor: COLORS.surface,
  },
  monthHeaderText: {
    fontSize: FONT_SIZE.xl,
    fontWeight: '700',
    color: COLORS.primary,
  },
  sectionHeader: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingHorizontal: SPACING.lg,
    paddingVertical: SPACING.sm,
    backgroundColor: '#FFFFFF',
    borderBottomWidth: StyleSheet.hairlineWidth,
    borderBottomColor: COLORS.border,
  },
  sectionDate: {
    fontSize: FONT_SIZE.md,
    fontWeight: '600',
    color: COLORS.text,
  },
  sectionWeekday: {
    fontSize: FONT_SIZE.sm,
    color: COLORS.textLight,
    marginLeft: SPACING.sm,
  },
  sectionSummary: {
    flex: 1,
    flexDirection: 'row',
    justifyContent: 'flex-end',
    gap: SPACING.sm,
  },
  sectionIncome: {
    fontSize: FONT_SIZE.sm,
    color: COLORS.income,
  },
  sectionExpense: {
    fontSize: FONT_SIZE.sm,
    color: COLORS.expense,
  },
  emptyContainer: {
    padding: SPACING.xxl,
    alignItems: 'center',
  },
  emptyText: {
    fontSize: FONT_SIZE.md,
    color: COLORS.textLight,
  },
});
