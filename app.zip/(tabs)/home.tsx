import React, { useState, useCallback, useRef } from 'react';
import { View, StyleSheet, FlatList, TouchableOpacity, Alert, TextInput, Keyboard, Modal, Dimensions, KeyboardAvoidingView, Platform, TouchableWithoutFeedback } from 'react-native';
import { Text, FAB, Surface, Dialog, Button, Portal, Snackbar } from 'react-native-paper';
import { useRouter, useFocusEffect } from 'expo-router';
import { MaterialCommunityIcons } from '@expo/vector-icons';
import { SafeAreaView } from 'react-native-safe-area-context';
import AsyncStorage from '@react-native-async-storage/async-storage';
import dayjs from 'dayjs';
import { COLORS, SPACING, FONT_SIZE, BORDER_RADIUS, REIMBURSEMENT_STATUS } from '../../constants/theme';
import { formatCurrencyShort } from '../../utils/format';
import { useRecordStore } from '../../store/useRecordStore';
import { getTransactionsByMonth } from '../../database/queries';
import { TransactionRow } from '../../database/schema';
import { parseQuickInputMultiLine, getCurrentTime, getCurrentDate } from '../../utils/quickParse';

interface DaySection {
  date: string;
  day: string;
  weekday: string;
  income: number;
  expense: number;
  transactions: TransactionRow[];
}

export default function HomeScreen() {
  const router = useRouter();
  const { deleteTransaction } = useRecordStore();
  const [currentMonth, setCurrentMonth] = useState(dayjs().format('YYYY-MM'));
  const [monthTotal, setMonthTotal] = useState({ income: 0, expense: 0 });
  const [pendingReimbursement, setPendingReimbursement] = useState({ count: 0, total: 0 });
  const [daySections, setDaySections] = useState<DaySection[]>([]);
  const [deleteDialogVisible, setDeleteDialogVisible] = useState(false);
  const [selectedTx, setSelectedTx] = useState<{ id: string; note: string } | null>(null);
  const [quickMode, setQuickMode] = useState(false);
  const [quickInputVisible, setQuickInputVisible] = useState(false);
  const [quickInput, setQuickInput] = useState('');
  const [quickHint, setQuickHint] = useState('');
  const [quickReimbursement, setQuickReimbursement] = useState<'none' | 'pending' | 'reimbursed'>('none');
  const [snackVisible, setSnackVisible] = useState(false);
  const [snackMsg, setSnackMsg] = useState('');
  const quickInputRef = useRef<TextInput>(null);

  // Load quick mode setting
  useFocusEffect(
    useCallback(() => {
      AsyncStorage.getItem('@accounting_quick_mode').then(v => {
        setQuickMode(v === 'true');
      });
    }, [])
  );

  const loadData = useCallback(async () => {
    try {
      const transactions = await getTransactionsByMonth(currentMonth);
      
      // Calculate month totals
      let income = 0;
      let expense = 0;
      let pendingCount = 0;
      let pendingTotal = 0;
      
      for (const tx of transactions) {
        if (tx.type === 'income') {
          income += tx.amount;
        } else {
          expense += tx.amount;
        }
        if (tx.type === 'expense' && tx.reimbursement_status === 'pending') {
          pendingCount++;
          pendingTotal += tx.amount;
        }
      }
      
      setMonthTotal({ income, expense });
      setPendingReimbursement({ count: pendingCount, total: pendingTotal });
      
      // Group by date
      const txByDate: Record<string, TransactionRow[]> = {};
      for (const tx of transactions) {
        if (!txByDate[tx.date]) txByDate[tx.date] = [];
        txByDate[tx.date].push(tx);
      }
      
      // Build day sections
      const sortedDates = Object.keys(txByDate).sort((a, b) => b.localeCompare(a));
      const sections: DaySection[] = sortedDates.map(date => {
        const dayTxs = txByDate[date];
        const dayIncome = dayTxs.filter(t => t.type === 'income').reduce((s, t) => s + t.amount, 0);
        const dayExpense = dayTxs.filter(t => t.type === 'expense').reduce((s, t) => s + t.amount, 0);
        const dayNum = dayjs(date).format('D');
        const weekday = ['周日', '周一', '周二', '周三', '周四', '周五', '周六'][dayjs(date).day()];
        return {
          date,
          day: `${dayNum}日`,
          weekday,
          income: dayIncome,
          expense: dayExpense,
          transactions: dayTxs,
        };
      });
      
      setDaySections(sections);
    } catch (error) {
      console.error('Load data error:', error);
    }
  }, [currentMonth]);

  useFocusEffect(
    useCallback(() => {
      loadData();
    }, [loadData])
  );

  const handleTransactionPress = (tx: TransactionRow) => {
    router.push({
      pathname: '/add-record',
      params: {
        id: tx.id,
        amount: tx.amount.toString(),
        type: tx.type,
        categoryId: tx.category_id,
        accountId: tx.account_id,
        note: tx.note,
        date: tx.date,
        time: tx.time,
        reimbursementStatus: tx.reimbursement_status,
        reimbursementDate: tx.reimbursement_date,
        reimbursementTime: tx.reimbursement_note,
      },
    });
  };

  const handleTransactionLongPress = (tx: TransactionRow) => {
    setSelectedTx({ id: tx.id, note: tx.note });
    setDeleteDialogVisible(true);
  };

  const confirmDelete = async () => {
    if (selectedTx) {
      await deleteTransaction(selectedTx.id);
      setDeleteDialogVisible(false);
      setSelectedTx(null);
      loadData();
    }
  };

  // Quick input handler (supports multiline)
  const handleQuickSubmit = async () => {
    if (!quickInput.trim()) return;
    const result = parseQuickInputMultiLine(quickInput);
    if (result.errors.length > 0 && result.items.length === 0) {
      setQuickHint(result.errors[0]);
      return;
    }
    const { addTransaction } = useRecordStore.getState();
    const date = getCurrentDate();
    const time = getCurrentTime();
    let count = 0;
    for (const item of result.items) {
      await addTransaction(
        item.amount,
        item.type,
        item.categoryId,
        'account_wechat',
        item.note,
        date,
        time,
        quickReimbursement
      );
      count++;
    }
    setQuickInput('');
    setQuickHint('');
    setQuickReimbursement('none');
    setQuickInputVisible(false);
    Keyboard.dismiss();
    loadData();
    setSnackMsg(`已记录 ${count} 笔`);
    setSnackVisible(true);
  };

  const navigateMonth = (direction: 'prev' | 'next') => {
    const newMonth = direction === 'prev'
      ? dayjs(currentMonth + '-01').subtract(1, 'month').format('YYYY-MM')
      : dayjs(currentMonth + '-01').add(1, 'month').format('YYYY-MM');
    setCurrentMonth(newMonth);
  };

  const monthNet = monthTotal.income - monthTotal.expense;
  const monthNum = parseInt(currentMonth.split('-')[1]);
  const monthNames = ['', '一月', '二月', '三月', '四月', '五月', '六月', '七月', '八月', '九月', '十月', '十一月', '十二月'];

  // Build flat list data
  interface FlatItem {
    type: 'dayHeader' | 'transaction' | 'separator';
    key: string;
    daySection?: DaySection;
    transaction?: TransactionRow;
  }

  const flatData: FlatItem[] = [];
  for (const section of daySections) {
    flatData.push({ type: 'dayHeader', key: `day_${section.date}`, daySection: section });
    for (const tx of section.transactions) {
      flatData.push({ type: 'transaction', key: tx.id, transaction: tx });
    }
  }

  return (
    <SafeAreaView style={styles.safeArea} edges={['top']}>
      <View style={styles.container}>
        {/* Header */}
        <View style={styles.header}>
          <Text style={styles.headerTitle}>账痕</Text>
        </View>

        {/* Month Summary */}
        <Surface style={styles.summaryCard} elevation={2}>
          <View style={styles.summaryRow}>
            <TouchableOpacity onPress={() => navigateMonth('prev')}>
              <MaterialCommunityIcons name="chevron-left" size={28} color={COLORS.textSecondary} />
            </TouchableOpacity>
            <Text style={styles.yearText}>{currentMonth.split('-')[0]}年{monthNames[monthNum]}总览</Text>
            <TouchableOpacity onPress={() => navigateMonth('next')}>
              <MaterialCommunityIcons name="chevron-right" size={28} color={COLORS.textSecondary} />
            </TouchableOpacity>
          </View>
          <View style={styles.summaryAmounts}>
            <View style={styles.summaryItem}>
              <Text style={styles.summaryLabel}>月收入</Text>
              <Text style={styles.summaryIncome}>{formatCurrencyShort(monthTotal.income)}</Text>
            </View>
            <View style={styles.summaryDivider} />
            <View style={styles.summaryItem}>
              <Text style={styles.summaryLabel}>月支出</Text>
              <Text style={styles.summaryExpense}>{formatCurrencyShort(monthTotal.expense)}</Text>
            </View>
            <View style={styles.summaryDivider} />
            <View style={styles.summaryItem}>
              <Text style={styles.summaryLabel}>月结余</Text>
              <Text style={[styles.summaryNet, monthNet >= 0 ? styles.positive : styles.negative]}>
                {formatCurrencyShort(monthNet)}
              </Text>
            </View>
          </View>
          {pendingReimbursement.count > 0 && (
            <View style={styles.pendingReimbursementRow}>
              <MaterialCommunityIcons name="receipt" size={16} color={COLORS.pending} />
              <Text style={styles.pendingReimbursementText}>
                {pendingReimbursement.count}笔待报销 · {formatCurrencyShort(pendingReimbursement.total)}
              </Text>
            </View>
          )}
        </Surface>

        {/* Day Sections + Transactions */}
        <FlatList
          data={flatData}
          keyExtractor={(item) => item.key}
          renderItem={({ item }) => {
            if (item.type === 'dayHeader' && item.daySection) {
              const s = item.daySection;
              return (
                <View style={styles.dayHeader}>
                  <View style={styles.dayHeaderLeft}>
                    <Text style={styles.dayText}>{s.day}</Text>
                    <Text style={styles.weekdayText}>{s.weekday}</Text>
                  </View>
                  <View style={styles.daySummary}>
                    {s.income > 0 && <Text style={styles.dayIncome}>收入 {formatCurrencyShort(s.income)}</Text>}
                    {s.expense > 0 && <Text style={styles.dayExpense}>支出 {formatCurrencyShort(s.expense)}</Text>}
                  </View>
                </View>
              );
            }
            if (item.type === 'transaction' && item.transaction) {
              const tx = item.transaction;
              return (
                <TouchableOpacity
                  style={styles.txRow}
                  onPress={() => handleTransactionPress(tx)}
                  onLongPress={() => handleTransactionLongPress(tx)}
                  delayLongPress={500}
                >
                  <View style={styles.txLeft}>
                    <Text style={styles.txIcon}>{(() => {
                      const cats = require('../../constants/categories');
                      return cats.getCategoryById(tx.category_id)?.icon || '📦';
                    })()}</Text>
                    <View style={styles.txInfo}>
                      <Text style={styles.txNote} numberOfLines={1}>{tx.note || '无备注'}</Text>
                      <Text style={styles.txMeta}>{tx.time} · {(() => {
                        const cats = require('../../constants/categories');
                        return cats.getCategoryById(tx.category_id)?.name || '未知';
                      })()}</Text>
                    </View>
                  </View>
                  <View style={styles.txRight}>
                    <Text style={[styles.txAmount, tx.type === 'income' ? styles.incomeColor : styles.expenseColor]}>
                      {tx.type === 'income' ? '+' : '-'}{formatCurrencyShort(tx.amount)}
                    </Text>
                    {tx.reimbursement_status !== 'none' && tx.reimbursement_status && (
                      <Text style={[styles.reimbursementBadge, { 
                        color: tx.reimbursement_status === 'reimbursed' ? COLORS.success : 
                               tx.reimbursement_status === 'partial' ? '#FF9800' : COLORS.pending 
                      }]}>
                        {tx.reimbursement_status === 'reimbursed' ? '全额报销' : 
                         tx.reimbursement_status === 'partial' ? '部分报销' : '待报销'}
                      </Text>
                    )}
                  </View>
                </TouchableOpacity>
              );
            }
            return null;
          }}
          ListEmptyComponent={
            <View style={styles.emptyContainer}>
              <MaterialCommunityIcons name="chart-timeline-variant" size={48} color={COLORS.textLight} />
              <Text style={styles.emptyText}>暂无记账数据</Text>
              <Text style={styles.emptyHint}>点击右下角「+」开始记账</Text>
            </View>
          }
          contentContainerStyle={styles.listContent}
        />

        {/* FAB */}
        {quickMode ? (
          <FAB
            icon="pencil"
            style={styles.fab}
            onPress={() => setQuickInputVisible(true)}
            color="#FFFFFF"
            size="small"
          />
        ) : (
          <FAB
            icon="plus"
            style={styles.fab}
            onPress={() => router.push('/add-record')}
            color="#FFFFFF"
          />
        )}
      </View>

      {/* Quick Input Panel - No Overlay */}
      {quickMode && quickInputVisible && (
        <View style={styles.quickPanelWrapper} pointerEvents="box-none">
          {/* Tappable area above panel to close */}
          <TouchableOpacity
            style={styles.quickPanelDismissArea}
            activeOpacity={1}
            onPress={() => { setQuickInputVisible(false); setQuickInput(''); setQuickHint(''); setQuickReimbursement('none'); }}
          />
          <KeyboardAvoidingView
            style={styles.quickPanelContainer}
            behavior={'padding'}
            keyboardVerticalOffset={0}
          >
            <TouchableWithoutFeedback onPress={Keyboard.dismiss}>
              <View style={styles.quickPanelContent}>
                {/* Header Row: Title + Record Button */}
                <View style={styles.quickPanelHeader}>
                  <Text style={styles.quickPanelTitle}>快速记账</Text>
                  <TouchableOpacity
                    style={[styles.quickPanelSubmitBtn, !quickInput.trim() && styles.quickPanelSubmitDisabled]}
                    onPress={handleQuickSubmit}
                    disabled={!quickInput.trim()}
                  >
                    <MaterialCommunityIcons name="check" size={16} color={quickInput.trim() ? '#FFFFFF' : '#999999'} />
                    <Text style={[styles.quickPanelSubmitText, !quickInput.trim() && { color: '#999999' }]}>记录</Text>
                  </TouchableOpacity>
                </View>

                {/* Reimbursement Tags */}
                <View style={styles.modalTagRow}>
                  <TouchableOpacity
                    style={[styles.modalTag, quickReimbursement === 'none' && styles.modalTagActive]}
                    onPress={() => setQuickReimbursement('none')}
                  >
                    <Text style={[styles.modalTagText, quickReimbursement === 'none' && styles.modalTagTextActive]}>无需报销</Text>
                  </TouchableOpacity>
                  <TouchableOpacity
                    style={[styles.modalTag, quickReimbursement === 'pending' && styles.modalTagPending]}
                    onPress={() => setQuickReimbursement('pending')}
                  >
                    <Text style={[styles.modalTagText, quickReimbursement === 'pending' && styles.modalTagTextPending]}>待报销</Text>
                  </TouchableOpacity>
                  <TouchableOpacity
                    style={[styles.modalTag, quickReimbursement === 'reimbursed' && styles.modalTagReimbursed]}
                    onPress={() => setQuickReimbursement('reimbursed')}
                  >
                    <Text style={[styles.modalTagText, quickReimbursement === 'reimbursed' && styles.modalTagTextReimbursed]}>已报销</Text>
                  </TouchableOpacity>
                </View>

                {/* Hint */}
                <View style={styles.modalHintContainer}>
                  <MaterialCommunityIcons name="information-outline" size={14} color={COLORS.textLight} />
                  <Text style={styles.modalHint}>每行一条，如：面 12、咖啡 25、打车 15</Text>
                </View>

                {/* Text Input */}
                <TextInput
                  ref={quickInputRef}
                  style={styles.quickPanelInput}
                  placeholder="请输入记账内容..."
                  placeholderTextColor={COLORS.textLight}
                  value={quickInput}
                  onChangeText={(t) => { setQuickInput(t); setQuickHint(''); }}
                  multiline={true}
                  textAlignVertical="top"
                  autoFocus
                />

                {/* Error Hint */}
                {quickHint ? (
                  <View style={styles.modalErrorRow}>
                    <MaterialCommunityIcons name="alert-circle-outline" size={16} color={COLORS.expense || '#F44336'} />
                    <Text style={styles.modalErrorText}>{quickHint}</Text>
                  </View>
                ) : null}
              </View>
            </TouchableWithoutFeedback>
          </KeyboardAvoidingView>
        </View>
      )}

      {/* Delete Dialog */}
      <Portal>
        <Dialog visible={deleteDialogVisible} onDismiss={() => setDeleteDialogVisible(false)}>
          <Dialog.Title>删除记录</Dialog.Title>
          <Dialog.Content>
            <Text>确定要删除「{selectedTx?.note || '无备注'}」吗？</Text>
          </Dialog.Content>
          <Dialog.Actions>
            <Button onPress={() => setDeleteDialogVisible(false)}>取消</Button>
            <Button onPress={confirmDelete} textColor="#F44336">删除</Button>
          </Dialog.Actions>
        </Dialog>
      </Portal>

      {/* Snackbar */}
      <Snackbar
        visible={snackVisible}
        onDismiss={() => setSnackVisible(false)}
        duration={2000}
        style={{ backgroundColor: '#4CAF50' }}
      >
        <Text style={{ color: '#FFF' }}>{snackMsg}</Text>
      </Snackbar>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  safeArea: {
    flex: 1,
    backgroundColor: '#FFFFFF',
  },
  container: {
    flex: 1,
    backgroundColor: COLORS.surface,
  },
  header: {
    paddingHorizontal: SPACING.lg,
    paddingVertical: SPACING.md,
    backgroundColor: '#FFFFFF',
  },
  headerRow: {
    flexDirection: 'row',
    alignItems: 'baseline',
    gap: SPACING.sm,
  },
  headerTitle: {
    fontSize: FONT_SIZE.title,
    fontWeight: '700',
    color: COLORS.text,
  },
  headerSubtitle: {
    fontSize: FONT_SIZE.sm,
    color: COLORS.textSecondary,
    fontWeight: '400',
  },
  // Month summary
  summaryCard: {
    marginHorizontal: SPACING.lg,
    marginBottom: SPACING.md,
    borderRadius: BORDER_RADIUS.lg,
    padding: SPACING.lg,
    backgroundColor: '#FFFFFF',
  },
  summaryRow: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: SPACING.md,
  },
  yearText: {
    fontSize: FONT_SIZE.lg,
    fontWeight: '600',
    color: COLORS.text,
  },
  summaryAmounts: {
    flexDirection: 'row',
    justifyContent: 'space-around',
    alignItems: 'center',
  },
  summaryItem: {
    alignItems: 'center',
    flex: 1,
  },
  summaryLabel: {
    fontSize: FONT_SIZE.sm,
    color: COLORS.textSecondary,
    marginBottom: 4,
  },
  summaryIncome: {
    fontSize: FONT_SIZE.xl,
    fontWeight: '700',
    color: COLORS.income,
  },
  summaryExpense: {
    fontSize: FONT_SIZE.xl,
    fontWeight: '700',
    color: COLORS.expense,
  },
  summaryNet: {
    fontSize: FONT_SIZE.xl,
    fontWeight: '700',
  },
  summaryDivider: {
    width: 1,
    height: 30,
    backgroundColor: COLORS.border,
  },
  positive: { color: COLORS.income },
  negative: { color: COLORS.expense },
  // Day header
  dayHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    paddingHorizontal: SPACING.lg,
    paddingVertical: SPACING.md,
    backgroundColor: '#FFFFFF',
    borderBottomWidth: StyleSheet.hairlineWidth,
    borderBottomColor: COLORS.border,
  },
  dayHeaderLeft: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: SPACING.sm,
  },
  dayText: {
    fontSize: FONT_SIZE.md,
    fontWeight: '700',
    color: COLORS.text,
  },
  weekdayText: {
    fontSize: FONT_SIZE.sm,
    color: COLORS.textLight,
  },
  daySummary: {
    flexDirection: 'row',
    gap: SPACING.md,
  },
  dayIncome: {
    fontSize: FONT_SIZE.sm,
    color: COLORS.income,
    fontWeight: '500',
  },
  dayExpense: {
    fontSize: FONT_SIZE.sm,
    color: COLORS.expense,
    fontWeight: '500',
  },
  // Transaction row
  txRow: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    paddingHorizontal: SPACING.lg,
    paddingVertical: SPACING.md,
    backgroundColor: '#FFFFFF',
    borderBottomWidth: StyleSheet.hairlineWidth,
    borderBottomColor: COLORS.border,
  },
  txLeft: {
    flexDirection: 'row',
    alignItems: 'center',
    flex: 1,
  },
  txIcon: {
    fontSize: 20,
    width: 30,
    textAlign: 'center',
  },
  txInfo: {
    flex: 1,
    marginLeft: SPACING.sm,
  },
  txNote: {
    fontSize: FONT_SIZE.md,
    color: COLORS.text,
  },
  txMeta: {
    fontSize: FONT_SIZE.xs,
    color: COLORS.textLight,
    marginTop: 2,
  },
  txRight: {
    alignItems: 'flex-end',
    marginLeft: SPACING.sm,
  },
  txAmount: {
    fontSize: FONT_SIZE.md,
    fontWeight: '600',
  },
  reimbursementBadge: {
    fontSize: FONT_SIZE.xs,
    fontWeight: '500',
    marginTop: 2,
  },
  incomeColor: { color: COLORS.income },
  expenseColor: { color: COLORS.expense },
  // Empty
  emptyContainer: {
    padding: SPACING.xxl,
    alignItems: 'center',
    gap: SPACING.sm,
  },
  emptyText: {
    fontSize: FONT_SIZE.md,
    color: COLORS.textLight,
  },
  emptyHint: {
    fontSize: FONT_SIZE.sm,
    color: COLORS.textLight,
  },
  pendingReimbursementRow: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    gap: SPACING.xs,
    marginTop: SPACING.md,
    paddingVertical: SPACING.sm,
    backgroundColor: COLORS.pendingLight,
    borderRadius: BORDER_RADIUS.md,
  },
  pendingReimbursementText: {
    fontSize: FONT_SIZE.sm,
    color: COLORS.pending,
    fontWeight: '600',
  },
  listContent: {
    paddingBottom: 80,
  },
  // FAB
  fab: {
    position: 'absolute',
    right: SPACING.lg,
    bottom: SPACING.xxl + 50,
    backgroundColor: COLORS.primary,
    borderRadius: BORDER_RADIUS.full,
  },
  // Quick Input Panel (no overlay)
  quickPanelWrapper: {
    ...StyleSheet.absoluteFill,
    zIndex: 1000,
  },
  quickPanelDismissArea: {
    flex: 1,
    backgroundColor: 'rgba(0, 0, 0, 0.40)',
  },
  quickPanelContainer: {
    backgroundColor: '#fff',
    borderTopLeftRadius: 28,
    borderTopRightRadius: 28,
    
    elevation: 10,
    height: '68%',
  },
  quickPanelContent: {
    flex: 1,
    paddingHorizontal: SPACING.lg,
    paddingTop: SPACING.lg,
    paddingBottom: 34,
  },
  quickPanelHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: SPACING.md,
  },
  quickPanelTitle: {
    fontSize: FONT_SIZE.lg,
    fontWeight: '700',
    color: COLORS.text,
  },
  quickPanelSubmitBtn: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingHorizontal: SPACING.md,
    paddingVertical: 8,
    borderRadius: BORDER_RADIUS.md,
    backgroundColor: COLORS.primary,
    gap: 4,
  },
  quickPanelSubmitDisabled: {
    backgroundColor: '#E0E0E0',
  },
  quickPanelSubmitText: {
    color: '#FFFFFF',
    fontSize: FONT_SIZE.sm,
    fontWeight: '600',
  },
  quickPanelInput: {
    flex: 1,
    borderWidth: 1,
    borderColor: COLORS.border || '#E0E0E0',
    borderRadius: BORDER_RADIUS.md,
    paddingHorizontal: SPACING.md,
    paddingVertical: SPACING.md,
    fontSize: FONT_SIZE.md,
    color: COLORS.text,
    backgroundColor: '#FAFAFA',
    lineHeight: 24,
  },
  modalTagRow: {
    flexDirection: 'row',
    paddingHorizontal: SPACING.lg,
    paddingBottom: SPACING.sm,
    gap: SPACING.sm,
  },
  modalTag: {
    paddingHorizontal: SPACING.md,
    paddingVertical: 6,
    borderRadius: BORDER_RADIUS.md,
    borderWidth: 1,
    borderColor: '#E0E0E0',
    backgroundColor: '#F5F5F5',
  },
  modalTagActive: {
    backgroundColor: '#E8F5E9',
    borderColor: '#4CAF50',
  },
  modalTagTextActive: {
    color: '#4CAF50',
    fontWeight: '600',
  },
  modalTagPending: {
    backgroundColor: '#FFF3E0',
    borderColor: '#FF9800',
  },
  modalTagTextPending: {
    color: '#FF9800',
    fontWeight: '600',
  },
  modalTagReimbursed: {
    backgroundColor: '#E3F2FD',
    borderColor: '#2196F3',
  },
  modalTagText: {
    fontSize: FONT_SIZE.sm,
    color: COLORS.text,
  },
  modalTagTextReimbursed: {
    color: '#2196F3',
    fontWeight: '600',
  },
  modalHintContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingHorizontal: SPACING.lg,
    paddingBottom: SPACING.sm,
    gap: 6,
  },
  modalHint: {
    fontSize: FONT_SIZE.sm,
    color: COLORS.textLight,
  },
  modalErrorRow: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingHorizontal: SPACING.lg,
    paddingTop: SPACING.sm,
    gap: 4,
  },
  modalErrorText: {
    fontSize: FONT_SIZE.sm,
    color: COLORS.expense || '#F44336',
  },
});
