import React, { useState, useEffect } from 'react';
import { View, StyleSheet, ScrollView, TouchableOpacity, Platform, TextInput, Alert, Clipboard } from 'react-native';
import { Text, Surface, Divider, Dialog, Portal, Button, RadioButton } from 'react-native-paper';
import { pickAndReadFile } from '../../utils/nativeFilePicker';
import AsyncStorage from '@react-native-async-storage/async-storage';
import { useRouter } from 'expo-router';
import { MaterialCommunityIcons } from '@expo/vector-icons';
import { SafeAreaView } from 'react-native-safe-area-context';
import { COLORS, SPACING, FONT_SIZE, BORDER_RADIUS } from '../../constants/theme';
import { useAccountStore } from '../../store/useAccountStore';
import { useRecordStore } from '../../store/useRecordStore';
import { getAllTransactions } from '../../database/queries';
import { addTransaction } from '../../database/queries';
import { formatCurrency } from '../../utils/format';
import { exportData, importFile, importFileFromBase64, importTextFile } from '../../utils/exportImport';

interface MenuItem {
  icon: string;
  title: string;
  subtitle?: string;
  onPress: () => void;
  color?: string;
}

export default function ProfileScreen() {
  const router = useRouter();
  const { accounts } = useAccountStore();
  const { fetchAll } = useRecordStore();
  const [dialogVisible, setDialogVisible] = useState(false);
  const [dialogTitle, setDialogTitle] = useState('');
  const [dialogMessage, setDialogMessage] = useState('');
  const [exportDialogVisible, setExportDialogVisible] = useState(false);
  const [exportFormat, setExportFormat] = useState<'xlsx' | 'xls' | 'txt' | 'csv'>('xlsx');
  const [quickMode, setQuickMode] = useState(false);
  const [modeDialogVisible, setModeDialogVisible] = useState(false);
  const [textImportVisible, setTextImportVisible] = useState(false);
  const [textImportValue, setTextImportValue] = useState('');

  useEffect(() => {
    AsyncStorage.getItem('@accounting_quick_mode').then(v => {
      setQuickMode(v === 'true');
    });
  }, []);

  const toggleQuickMode = async (value: string) => {
    const isQuick = value === 'quick';
    setQuickMode(isQuick);
    await AsyncStorage.setItem('@accounting_quick_mode', isQuick.toString());
    setModeDialogVisible(false);
  };

  const showAlert = (title: string, message: string) => {
    if (Platform.OS === 'web') {
      setDialogTitle(title);
      setDialogMessage(message);
      setDialogVisible(true);
    } else {
      const { Alert } = require('react-native');
      Alert.alert(title, message);
    }
  };

  useEffect(() => {
    useAccountStore.getState().fetchAll();
  }, []);

  const totalBalance = accounts.reduce((sum, acc) => sum + acc.balance, 0);

  // 导出数据（带格式选择）
  const handleExport = async () => {
    setExportDialogVisible(true);
  };

  const doExport = async () => {
    setExportDialogVisible(false);
    try {
      const transactions = await getAllTransactions();
      if (transactions.length === 0) {
        showAlert('提示', '暂无数据可导出');
        return;
      }
      const result = await exportData(transactions, exportFormat);
      if (result.success) {
        showAlert('导出成功', result.message + (result.fileName ? `\n文件：${result.fileName}` : ''));
      } else {
        showAlert('导出失败', result.message);
      }
    } catch (error: any) {
      showAlert('导出失败', error.message || '请重试');
    }
  };

  // 导入数据（文件选择）
  const handleImport = async () => {
    if (Platform.OS === 'web') {
      const input = document.createElement('input');
      input.type = 'file';
      input.accept = '.xlsx,.xls,.txt,.csv';
      input.onchange = async (e: any) => {
        const file = e.target.files?.[0];
        if (!file) return;
        try {
          const result = await importFile(URL.createObjectURL(file), file.name);
          if (result.success && result.transactions) {
            await saveImportedTransactions(result.transactions);
          } else {
            showAlert('导入失败', result.message);
          }
        } catch (error: any) {
          showAlert('导入失败', error.message || '文件解析错误');
        }
      };
      input.click();
    } else {
      try {
        const fileData = await pickAndReadFile();
        console.log('File picked:', { fileName: fileData.fileName, base64Length: fileData.base64.length });
        const importResult = await importFileFromBase64(fileData.base64, fileData.fileName);
        if (importResult.success && importResult.transactions) {
          await saveImportedTransactions(importResult.transactions);
        } else {
          showAlert('导入失败', importResult.message);
        }
      } catch (error: any) {
        console.error('Import error:', error);
        if (error.message?.includes('CANCELLED')) {
          return;
        }
        // 文件导入失败，提示用户使用文本粘贴导入
        if (Platform.OS !== 'web') {
          Alert.alert(
            '文件导入失败',
            `${error.message || '无法读取文件'}\n\n您可以尝试使用「文本粘贴导入」功能：\n1. 在电脑上打开Excel文件\n2. 全选数据并复制\n3. 粘贴到应用中的文本框`,
            [
              { text: '取消', style: 'cancel' },
              { text: '文本粘贴导入', onPress: () => setTextImportVisible(true) },
            ]
          );
        } else {
          showAlert('导入失败', error.message || '文件选择错误');
        }
      }
    }
  };

  // 文本粘贴导入
  const handleTextImport = async () => {
    if (!textImportValue.trim()) {
      showAlert('提示', '请先粘贴数据');
      return;
    }
    try {
      const result = await importTextFile(textImportValue.trim());
      if (result.success && result.transactions) {
        await saveImportedTransactions(result.transactions);
        setTextImportVisible(false);
        setTextImportValue('');
      } else {
        showAlert('导入失败', result.message);
      }
    } catch (error: any) {
      showAlert('导入失败', error.message || '数据解析错误');
    }
  };

  // 从剪贴板粘贴
  const handlePasteFromClipboard = async () => {
    try {
      const text = await Clipboard.getString();
      if (text) {
        setTextImportValue(text);
      } else {
        showAlert('提示', '剪贴板中没有数据');
      }
    } catch (error) {
      showAlert('提示', '无法读取剪贴板数据');
    }
  };

  const saveImportedTransactions = async (transactions: any[]) => {
    let imported = 0;
    for (const tx of transactions) {
      await addTransaction(
        tx.amount,
        tx.type,
        tx.category_id,
        tx.account_id,
        tx.note,
        tx.date,
        tx.time,
        tx.reimbursement_status
      );
      imported++;
    }
    fetchAll();
    useAccountStore.getState().fetchAll();
    showAlert('导入成功', `成功导入 ${imported} 条记录`);
  };

  const menuItems: MenuItem[] = [
    {
      icon: 'wallet',
      title: '账户管理',
      subtitle: `共 ${accounts.length} 个账户 · 总余额 ${formatCurrency(totalBalance)}`,
      onPress: () => router.push('/accounts'),
    },
    {
      icon: 'chart-line',
      title: '预算管理',
      subtitle: '设置月度预算',
      onPress: () => router.push('/budget'),
    },
    {
      icon: 'receipt',
      title: '报销管理',
      subtitle: '查看和管理报销记录',
      onPress: () => router.push('/reimbursement'),
    },
    {
      icon: 'cursor-text',
      title: '记账方式',
      subtitle: quickMode ? '快捷模式 — 输入文字快速记账' : '详细模式 — 完整表单录入',
      onPress: () => setModeDialogVisible(true),
    },
    {
      icon: 'file-import',
      title: '导入数据',
      subtitle: '支持 xlsx、xls、txt、csv 文件',
      onPress: handleImport,
    },
    ...(Platform.OS !== 'web' ? [{
      icon: 'content-paste',
      title: '文本粘贴导入',
      subtitle: '复制Excel数据粘贴到文本框',
      onPress: () => setTextImportVisible(true),
    }] : []),
    {
      icon: 'file-export',
      title: '导出数据',
      subtitle: '支持 xlsx、xls、txt、csv 格式',
      onPress: handleExport,
    },
  ];

  return (
    <SafeAreaView style={styles.safeArea} edges={['top']}>
      <ScrollView style={styles.container}>
        {/* Header */}
        <View style={styles.header}>
          <Text style={styles.title}>我的</Text>
        </View>
        {/* Asset Overview */}
        <Surface style={styles.overviewCard} elevation={1}>
          <Text style={styles.overviewTitle}>资产概览</Text>
          <View style={styles.balanceRow}>
            <Text style={styles.balanceLabel}>总余额</Text>
            <Text style={styles.balanceAmount}>{formatCurrency(totalBalance)}</Text>
          </View>
          <ScrollView horizontal showsHorizontalScrollIndicator={false} style={styles.accountsList}>
            {accounts.map(acc => (
              <View key={acc.id} style={styles.accountChip}>
                <Text style={styles.accountIcon}>{acc.icon}</Text>
                <Text style={styles.accountName}>{acc.name}</Text>
                <Text style={styles.accountBalance}>{formatCurrency(acc.balance)}</Text>
              </View>
            ))}
          </ScrollView>
        </Surface>

        {/* Menu Items */}
        <Surface style={styles.menuCard} elevation={1}>
          {menuItems.map((item, index) => (
            <React.Fragment key={item.title}>
              <TouchableOpacity style={styles.menuItem} onPress={item.onPress}>
                <View style={styles.menuLeft}>
                  <MaterialCommunityIcons
                    name={item.icon as any}
                    size={24}
                    color={item.color || COLORS.primary}
                  />
                  <View style={styles.menuText}>
                    <Text style={styles.menuTitle}>{item.title}</Text>
                    {item.subtitle && (
                      <Text style={styles.menuSubtitle}>{item.subtitle}</Text>
                    )}
                  </View>
                </View>
                <MaterialCommunityIcons name="chevron-right" size={20} color={COLORS.textLight} />
              </TouchableOpacity>
              {index < menuItems.length - 1 && <Divider />}
            </React.Fragment>
          ))}
        </Surface>

        {/* App Info */}
        <View style={styles.appInfo}>
          <Text style={styles.appVersion}>账痕 v0.4.0</Text>
          <Text style={styles.appSlogan}>让每一笔账单都有痕迹！</Text>
          <Text style={styles.appCustom}>师父（赵老师）专属定制版</Text>
        </View>

        <View style={{ height: 100 }} />
      </ScrollView>

      {/* Recording Mode Dialog */}
      <Portal>
        <Dialog visible={modeDialogVisible} onDismiss={() => setModeDialogVisible(false)}>
          <Dialog.Title>选择记账方式</Dialog.Title>
          <Dialog.Content>
            <RadioButton.Group onValueChange={toggleQuickMode} value={quickMode ? 'quick' : 'detail'}>
              <TouchableOpacity style={styles.radioItem} onPress={() => toggleQuickMode('detail')}>
                <RadioButton value="detail" color={COLORS.primary} />
                <View style={{ flex: 1 }}>
                  <Text style={styles.radioLabel}>详细模式</Text>
                  <Text style={styles.radioHint}>完整表单录入，选择分类、账户等</Text>
                </View>
              </TouchableOpacity>
              <TouchableOpacity style={styles.radioItem} onPress={() => toggleQuickMode('quick')}>
                <RadioButton value="quick" color={COLORS.primary} />
                <View style={{ flex: 1 }}>
                  <Text style={styles.radioLabel}>快捷模式</Text>
                  <Text style={styles.radioHint}>输入文字快速记账，如「面 12」</Text>
                </View>
              </TouchableOpacity>
            </RadioButton.Group>
          </Dialog.Content>
          <Dialog.Actions>
            <Button onPress={() => setModeDialogVisible(false)}>关闭</Button>
          </Dialog.Actions>
        </Dialog>
      </Portal>

      {/* Export Format Dialog */}
      <Portal>
        <Dialog visible={exportDialogVisible} onDismiss={() => setExportDialogVisible(false)}>
          <Dialog.Title>选择导出格式</Dialog.Title>
          <Dialog.Content>
            <RadioButton.Group onValueChange={(v) => setExportFormat(v as any)} value={exportFormat}>
              <View style={styles.radioItem}>
                <RadioButton value="xlsx" color={COLORS.primary} />
                <Text style={styles.radioLabel}>📊 Excel (.xlsx) — 默认</Text>
              </View>
              <View style={styles.radioItem}>
                <RadioButton value="xls" color={COLORS.primary} />
                <Text style={styles.radioLabel}>📊 Excel 97-2003 (.xls)</Text>
              </View>
              <View style={styles.radioItem}>
                <RadioButton value="txt" color={COLORS.primary} />
                <Text style={styles.radioLabel}>📝 文本文件 (.txt)</Text>
              </View>
              <View style={styles.radioItem}>
                <RadioButton value="csv" color={COLORS.primary} />
                <Text style={styles.radioLabel}>📄 CSV (.csv)</Text>
              </View>
            </RadioButton.Group>
          </Dialog.Content>
          <Dialog.Actions>
            <Button onPress={() => setExportDialogVisible(false)}>取消</Button>
            <Button mode="contained" onPress={doExport} buttonColor={COLORS.primary}>导出</Button>
          </Dialog.Actions>
        </Dialog>
      </Portal>

      {/* Text Import Dialog */}
      <Portal>
        <Dialog visible={textImportVisible} onDismiss={() => setTextImportVisible(false)} style={{ maxHeight: '80%' }}>
          <Dialog.Title>文本粘贴导入</Dialog.Title>
          <Dialog.Content>
            <Text style={{ fontSize: 13, color: '#666', marginBottom: 8 }}>
              请从电脑上复制Excel数据（含表头），粘贴到下方文本框：
            </Text>
            <Text style={{ fontSize: 12, color: '#999', marginBottom: 8 }}>
              支持制表符分隔（从Excel复制）或逗号分隔（CSV格式）
            </Text>
            <TouchableOpacity style={styles.pasteButton} onPress={handlePasteFromClipboard}>
              <Text style={styles.pasteButtonText}>📋 从剪贴板粘贴</Text>
            </TouchableOpacity>
            <TextInput
              style={styles.textImportInput}
              multiline
              numberOfLines={10}
              placeholder="在此粘贴数据..."
              value={textImportValue}
              onChangeText={setTextImportValue}
              textAlignVertical="top"
            />
          </Dialog.Content>
          <Dialog.Actions>
            <Button onPress={() => { setTextImportVisible(false); setTextImportValue(''); }}>取消</Button>
            <Button mode="contained" onPress={handleTextImport} buttonColor="#4CAF50">导入</Button>
          </Dialog.Actions>
        </Dialog>
      </Portal>

      {/* Alert Dialog */}
      <Portal>
        <Dialog visible={dialogVisible} onDismiss={() => setDialogVisible(false)}>
          <Dialog.Title>{dialogTitle}</Dialog.Title>
          <Dialog.Content>
            <Text>{dialogMessage}</Text>
          </Dialog.Content>
          <Dialog.Actions>
            <Button onPress={() => setDialogVisible(false)}>确定</Button>
          </Dialog.Actions>
        </Dialog>
      </Portal>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  safeArea: {
    flex: 1,
    backgroundColor: '#FFFFFF',
  },
  header: {
    paddingHorizontal: SPACING.lg,
    paddingVertical: SPACING.md,
    backgroundColor: '#fff',
  },
  title: {
    fontSize: FONT_SIZE.xxl,
    fontWeight: '700',
    color: COLORS.text,
  },
  container: {
    flex: 1,
    backgroundColor: COLORS.surface,
  },

  overviewCard: {
    marginHorizontal: SPACING.lg,
    marginBottom: SPACING.md,
    padding: SPACING.lg,
    borderRadius: BORDER_RADIUS.lg,
    backgroundColor: '#FFFFFF',
  },
  overviewTitle: {
    fontSize: FONT_SIZE.md,
    fontWeight: '600',
    color: COLORS.text,
    marginBottom: SPACING.sm,
  },
  balanceRow: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: SPACING.md,
  },
  balanceLabel: {
    fontSize: FONT_SIZE.md,
    color: COLORS.textSecondary,
  },
  balanceAmount: {
    fontSize: FONT_SIZE.xxl,
    fontWeight: '700',
    color: COLORS.primary,
  },
  accountsList: {
    flexDirection: 'row',
  },
  accountChip: {
    alignItems: 'center',
    paddingVertical: SPACING.sm,
    paddingHorizontal: SPACING.md,
    backgroundColor: COLORS.surface,
    borderRadius: BORDER_RADIUS.md,
    marginRight: SPACING.sm,
    minWidth: 80,
  },
  accountIcon: {
    fontSize: 20,
    marginBottom: 4,
  },
  accountName: {
    fontSize: FONT_SIZE.xs,
    color: COLORS.textSecondary,
  },
  accountBalance: {
    fontSize: FONT_SIZE.sm,
    fontWeight: '600',
    color: COLORS.text,
    marginTop: 2,
  },
  menuCard: {
    marginHorizontal: SPACING.lg,
    marginBottom: SPACING.md,
    borderRadius: BORDER_RADIUS.lg,
    backgroundColor: '#FFFFFF',
    overflow: 'hidden',
  },
  menuItem: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    paddingVertical: SPACING.lg,
    paddingHorizontal: SPACING.lg,
  },
  menuLeft: {
    flexDirection: 'row',
    alignItems: 'center',
    flex: 1,
  },
  menuText: {
    marginLeft: SPACING.md,
    flex: 1,
  },
  menuTitle: {
    fontSize: FONT_SIZE.md,
    color: COLORS.text,
  },
  menuSubtitle: {
    fontSize: FONT_SIZE.sm,
    color: COLORS.textSecondary,
    marginTop: 2,
  },
  radioItem: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingVertical: 4,
  },
  radioLabel: {
    fontSize: FONT_SIZE.md,
    color: COLORS.text,
  },
  radioHint: {
    fontSize: FONT_SIZE.sm,
    color: COLORS.textSecondary,
    marginTop: 2,
  },
  pasteButton: {
    backgroundColor: '#E3F2FD',
    padding: 10,
    borderRadius: 8,
    alignItems: 'center',
    marginBottom: 8,
  },
  pasteButtonText: {
    fontSize: 14,
    color: '#1976D2',
    fontWeight: '600',
  },
  textImportInput: {
    borderWidth: 1,
    borderColor: '#DDD',
    borderRadius: 8,
    padding: 10,
    fontSize: 12,
    minHeight: 150,
    maxHeight: 300,
    fontFamily: Platform.OS === 'ios' ? 'Menlo' : 'monospace',
    backgroundColor: '#FAFAFA',
    lineHeight: 18,
  },
  appInfo: {
    alignItems: 'center',
    paddingVertical: SPACING.lg,
  },
  appVersion: {
    fontSize: FONT_SIZE.sm,
    color: COLORS.textLight,
  },
  appSlogan: {
    fontSize: FONT_SIZE.xs,
    color: COLORS.textLight,
    fontStyle: 'italic',
    marginTop: 4,
  },
  appCustom: {
    fontSize: FONT_SIZE.xs,
    color: '#FFD700',
    fontWeight: '700',
    marginTop: 4,
    textShadowColor: 'rgba(255, 215, 0, 0.4)',
    textShadowOffset: { width: 0, height: 1 },
    textShadowRadius: 3,
  },
});
