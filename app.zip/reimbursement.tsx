import React, { useState, useEffect } from 'react';
import { View, StyleSheet, FlatList, TouchableOpacity, Alert } from 'react-native';
import { Text, Surface, Chip, Button, Portal, Modal, TextInput } from 'react-native-paper';
import { SafeAreaView } from 'react-native-safe-area-context';
import { COLORS, SPACING, FONT_SIZE, BORDER_RADIUS, REIMBURSEMENT_STATUS } from '../constants/theme';
import { useRecordStore } from '../store/useRecordStore';
import { TransactionRow } from '../database/schema';
import { getCategoryById } from '../constants/categories';
import { formatCurrency, formatDateChinese } from '../utils/format';

type TabType = 'pending' | 'history';

export default function ReimbursementScreen() {
  const { transactions, fetchAll, updateReimbursement } = useRecordStore();
  const [tab, setTab] = useState<TabType>('pending');
  const [modalVisible, setModalVisible] = useState(false);
  const [selectedTx, setSelectedTx] = useState<TransactionRow | null>(null);
  const [note, setNote] = useState('');

  useEffect(() => {
    fetchAll();
  }, []);

  const pendingTransactions = transactions.filter(
    tx => tx.reimbursement_status === 'pending' || tx.reimbursement_status === 'reimbursing'
  );

  const historyTransactions = transactions.filter(
    tx => tx.reimbursement_status === 'reimbursed' || tx.reimbursement_status === 'rejected'
  );

  const pendingTotal = pendingTransactions
    .filter(tx => tx.type === 'expense')
    .reduce((sum, tx) => sum + tx.amount, 0);

  const handleStatusChange = (tx: TransactionRow, newStatus: string) => {
    setSelectedTx(tx);
    setNote('');
    setModalVisible(true);
  };

  const confirmStatusChange = async () => {
    if (!selectedTx) return;

    const newStatus = selectedTx.reimbursement_status === 'pending' ? 'reimbursing' : 
                      selectedTx.reimbursement_status === 'reimbursing' ? 'reimbursed' : 'none';

    if (newStatus === 'reimbursed') {
      Alert.alert(
        '确认报销完成',
        `确定将"${selectedTx.note || '未备注'}"标记为已报销吗？\n将自动生成一笔等额收入记录。`,
        [
          { text: '取消', style: 'cancel' },
          {
            text: '确认',
            onPress: async () => {
              await updateReimbursement(selectedTx.id, 'reimbursed', note);
              setModalVisible(false);
              fetchAll();
            },
          },
        ]
      );
    } else {
      await updateReimbursement(selectedTx.id, newStatus, note);
      setModalVisible(false);
      fetchAll();
    }
  };

  const handleReject = async () => {
    if (!selectedTx) return;
    Alert.alert(
      '确认驳回',
      `确定要驳回"${selectedTx.note || '未备注'}"的报销申请吗？`,
      [
        { text: '取消', style: 'cancel' },
        {
          text: '驳回',
          style: 'destructive',
          onPress: async () => {
            await updateReimbursement(selectedTx.id, 'rejected', note);
            setModalVisible(false);
            fetchAll();
          },
        },
      ]
    );
  };

  const renderTransaction = (tx: TransactionRow) => {
    const category = getCategoryById(tx.category_id);
    const statusInfo = REIMBURSEMENT_STATUS[tx.reimbursement_status as keyof typeof REIMBURSEMENT_STATUS];

    return (
      <Surface key={tx.id} style={styles.txCard} elevation={1}>
        <View style={styles.txHeader}>
          <Text style={styles.txIcon}>{category?.icon || '📦'}</Text>
          <View style={styles.txInfo}>
            <Text style={styles.txNote}>{tx.note || '无备注'}</Text>
            <Text style={styles.txDate}>{formatDateChinese(tx.date)}</Text>
          </View>
          <Text style={styles.txAmount}>{formatCurrency(tx.amount)}</Text>
        </View>

        <View style={styles.txFooter}>
          <View style={[styles.statusBadge, { backgroundColor: statusInfo.color + '20' }]}>
            <Text style={[styles.statusText, { color: statusInfo.color }]}>
              {statusInfo.label}
            </Text>
          </View>

          {tx.reimbursement_status === 'pending' && (
            <Button
              mode="contained"
              compact
              onPress={() => handleStatusChange(tx, 'reimbursing')}
              style={styles.actionBtn}
              buttonColor={COLORS.primary}
            >
              提交报销
            </Button>
          )}

          {tx.reimbursement_status === 'reimbursing' && (
            <View style={styles.actionRow}>
              <Button
                mode="contained"
                compact
                onPress={() => handleStatusChange(tx, 'reimbursed')}
                style={styles.actionBtn}
                buttonColor={COLORS.success}
              >
                已报销
              </Button>
              <Button
                mode="outlined"
                compact
                onPress={() => {
                  setSelectedTx(tx);
                  setNote('');
                  setModalVisible(true);
                }}
                style={styles.rejectBtn}
                textColor={COLORS.rejected}
              >
                驳回
              </Button>
            </View>
          )}
        </View>
      </Surface>
    );
  };

  return (
    <SafeAreaView style={styles.safeArea} edges={['bottom']}>
      <View style={styles.container}>
        {/* Tabs */}
        <View style={styles.tabBar}>
          <TouchableOpacity
            style={[styles.tab, tab === 'pending' && styles.tabActive]}
            onPress={() => setTab('pending')}
          >
            <Text style={[styles.tabText, tab === 'pending' && styles.tabTextActive]}>
              待处理 ({pendingTransactions.length})
            </Text>
          </TouchableOpacity>
          <TouchableOpacity
            style={[styles.tab, tab === 'history' && styles.tabActive]}
            onPress={() => setTab('history')}
          >
            <Text style={[styles.tabText, tab === 'history' && styles.tabTextActive]}>
              历史记录 ({historyTransactions.length})
            </Text>
          </TouchableOpacity>
        </View>

        {/* Pending Total */}
        {tab === 'pending' && pendingTransactions.length > 0 && (
          <Surface style={styles.totalCard} elevation={1}>
            <Text style={styles.totalLabel}>待报销总额</Text>
            <Text style={styles.totalAmount}>{formatCurrency(pendingTotal)}</Text>
          </Surface>
        )}

        {/* Transaction List */}
        <FlatList
          data={tab === 'pending' ? pendingTransactions : historyTransactions}
          keyExtractor={(item) => item.id}
          renderItem={({ item }) => renderTransaction(item)}
          contentContainerStyle={styles.list}
          ListEmptyComponent={
            <View style={styles.emptyContainer}>
              <Text style={styles.emptyText}>
                {tab === 'pending' ? '暂无待报销记录' : '暂无报销历史'}
              </Text>
            </View>
          }
        />

        {/* Status Change Modal */}
        <Portal>
          <Modal
            visible={modalVisible}
            onDismiss={() => setModalVisible(false)}
            contentContainerStyle={styles.modal}
          >
            <Text style={styles.modalTitle}>报销备注</Text>
            <TextInput
              value={note}
              onChangeText={setNote}
              placeholder="添加备注..."
              mode="outlined"
              style={styles.input}
            />
            <View style={styles.modalActions}>
              <Button mode="outlined" onPress={() => setModalVisible(false)}>
                取消
              </Button>
              {selectedTx?.reimbursement_status === 'reimbursing' && (
                <Button mode="outlined" onPress={handleReject} textColor={COLORS.expense}>
                  驳回
                </Button>
              )}
              <Button mode="contained" onPress={confirmStatusChange} buttonColor={COLORS.primary}>
                确认
              </Button>
            </View>
          </Modal>
        </Portal>
      </View>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  safeArea: {
    flex: 1,
    backgroundColor: '#FFFFFF',
  },
  container: {
    flex: 1,
    backgroundColor: COLORS.surface,
  },
  tabBar: {
    flexDirection: 'row',
    backgroundColor: '#FFFFFF',
    borderBottomWidth: 1,
    borderBottomColor: COLORS.border,
  },
  tab: {
    flex: 1,
    paddingVertical: SPACING.md,
    alignItems: 'center',
  },
  tabActive: {
    borderBottomWidth: 2,
    borderBottomColor: COLORS.primary,
  },
  tabText: {
    fontSize: FONT_SIZE.md,
    color: COLORS.textSecondary,
  },
  tabTextActive: {
    color: COLORS.primary,
    fontWeight: '600',
  },
  totalCard: {
    margin: SPACING.lg,
    padding: SPACING.lg,
    borderRadius: BORDER_RADIUS.lg,
    backgroundColor: COLORS.pendingLight,
    alignItems: 'center',
  },
  totalLabel: {
    fontSize: FONT_SIZE.sm,
    color: COLORS.pending,
  },
  totalAmount: {
    fontSize: FONT_SIZE.xxl,
    fontWeight: '700',
    color: COLORS.pending,
    marginTop: 4,
  },
  list: {
    paddingHorizontal: SPACING.lg,
    paddingBottom: SPACING.xxl,
  },
  txCard: {
    padding: SPACING.lg,
    marginBottom: SPACING.sm,
    borderRadius: BORDER_RADIUS.lg,
    backgroundColor: '#FFFFFF',
  },
  txHeader: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: SPACING.md,
  },
  txIcon: {
    fontSize: 28,
  },
  txInfo: {
    flex: 1,
    marginLeft: SPACING.md,
  },
  txNote: {
    fontSize: FONT_SIZE.md,
    fontWeight: '500',
    color: COLORS.text,
  },
  txDate: {
    fontSize: FONT_SIZE.sm,
    color: COLORS.textSecondary,
    marginTop: 2,
  },
  txAmount: {
    fontSize: FONT_SIZE.lg,
    fontWeight: '700',
    color: COLORS.expense,
  },
  txFooter: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
  },
  statusBadge: {
    paddingHorizontal: 8,
    paddingVertical: 4,
    borderRadius: BORDER_RADIUS.sm,
  },
  statusText: {
    fontSize: FONT_SIZE.xs,
    fontWeight: '600',
  },
  actionRow: {
    flexDirection: 'row',
    gap: SPACING.sm,
  },
  actionBtn: {
    borderRadius: BORDER_RADIUS.sm,
  },
  rejectBtn: {
    borderColor: COLORS.rejected,
    borderRadius: BORDER_RADIUS.sm,
  },
  emptyContainer: {
    padding: SPACING.xxl,
    alignItems: 'center',
  },
  emptyText: {
    fontSize: FONT_SIZE.md,
    color: COLORS.textLight,
  },
  modal: {
    backgroundColor: 'white',
    padding: SPACING.xl,
    margin: SPACING.lg,
    borderRadius: BORDER_RADIUS.lg,
  },
  modalTitle: {
    fontSize: FONT_SIZE.xl,
    fontWeight: '700',
    color: COLORS.text,
    marginBottom: SPACING.lg,
  },
  input: {
    marginBottom: SPACING.lg,
    backgroundColor: '#FFFFFF',
  },
  modalActions: {
    flexDirection: 'row',
    justifyContent: 'flex-end',
    gap: SPACING.md,
  },
});
