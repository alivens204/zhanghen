import React, { useState, useEffect } from 'react';
import { View, StyleSheet, ScrollView, TouchableOpacity } from 'react-native';
import { Text, Surface, TextInput, Button, Portal, Modal, Dialog } from 'react-native-paper';
import { SafeAreaView } from 'react-native-safe-area-context';
import dayjs from 'dayjs';
import { COLORS, SPACING, FONT_SIZE, BORDER_RADIUS } from '../constants/theme';
import { useBudgetStore } from '../store/useBudgetStore';
import { BudgetRow } from '../database/schema';
import { EXPENSE_CATEGORIES, getCategoryById } from '../constants/categories';
import { formatCurrency } from '../utils/format';
import { getTransactionsByMonth } from '../database/queries';

export default function BudgetScreen() {
  const { budgets, fetchAll, setBudget, deleteBudget } = useBudgetStore();
  const [modalVisible, setModalVisible] = useState(false);
  const [editingBudget, setEditingBudget] = useState<BudgetRow | null>(null);
  const [amount, setAmount] = useState('');
  const [selectedCategoryId, setSelectedCategoryId] = useState<string | null>(null);
  const [currentMonthSpent, setCurrentMonthSpent] = useState(0);
  const [deleteDialogVisible, setDeleteDialogVisible] = useState(false);
  const [budgetToDelete, setBudgetToDelete] = useState<BudgetRow | null>(null);

  const currentYearMonth = dayjs().format('YYYY-MM');

  useEffect(() => {
    fetchAll();
    loadMonthlySpent();
  }, []);

  const loadMonthlySpent = async () => {
    const transactions = await getTransactionsByMonth(currentYearMonth);
    // Only count expenses that are NOT reimbursed
    const totalSpent = transactions
      .filter(tx => tx.type === 'expense' && tx.reimbursement_status !== 'reimbursed')
      .reduce((sum, tx) => sum + tx.amount, 0);
    setCurrentMonthSpent(totalSpent);
  };

  const categoryBudgets = budgets.filter(b => b.id !== 'budget_total');
  const totalBudgetAmount = categoryBudgets.reduce((sum, b) => sum + b.amount, 0);

  const handleAddCategoryBudget = () => {
    setEditingBudget(null);
    setAmount('');
    setSelectedCategoryId(null);
    setModalVisible(true);
  };

  const handleSave = async () => {
    const parsedAmount = parseFloat(amount);
    if (isNaN(parsedAmount) || parsedAmount <= 0) {
      return;
    }

    await setBudget(parsedAmount, 'monthly', selectedCategoryId);
    setModalVisible(false);
    loadMonthlySpent();
  };

  const handleDeleteBudget = (budget: BudgetRow) => {
    setBudgetToDelete(budget);
    setDeleteDialogVisible(true);
  };

  const confirmDeleteBudget = async () => {
    if (budgetToDelete) {
      await deleteBudget(budgetToDelete.id);
      setDeleteDialogVisible(false);
      setBudgetToDelete(null);
      loadMonthlySpent();
    }
  };

  const progress = totalBudgetAmount > 0 ? Math.min((currentMonthSpent / totalBudgetAmount) * 100, 100) : 0;
  const isOverBudget = totalBudgetAmount > 0 && currentMonthSpent > totalBudgetAmount;

  return (
    <SafeAreaView style={styles.safeArea} edges={['bottom']}>
      <ScrollView style={styles.container}>
        {/* Total Budget Card */}
        <Surface style={styles.totalCard} elevation={2}>
          <Text style={styles.cardTitle}>本月总预算</Text>
          {totalBudgetAmount > 0 ? (
            <>
              <View style={styles.budgetInfo}>
                <Text style={styles.spentAmount}>{formatCurrency(currentMonthSpent)}</Text>
                <Text style={styles.budgetLabel}> / {formatCurrency(totalBudgetAmount)}</Text>
              </View>
              <View style={styles.progressBar}>
                <View
                  style={[
                    styles.progressFill,
                    { width: `${progress}%` },
                    isOverBudget ? styles.progressOver : styles.progressNormal,
                  ]}
                />
              </View>
              <View style={styles.budgetFooter}>
                <Text style={[styles.remainingText, isOverBudget ? styles.overBudgetText : styles.underBudgetText]}>
                  {isOverBudget ? `超支 ${formatCurrency(currentMonthSpent - totalBudgetAmount)}` : `剩余 ${formatCurrency(totalBudgetAmount - currentMonthSpent)}`}
                </Text>
                <Text style={styles.totalHint}>= 分类预算之和</Text>
              </View>
            </>
          ) : (
            <View style={styles.emptyTotal}>
              <Text style={styles.emptyTotalText}>请先添加分类预算</Text>
            </View>
          )}
        </Surface>

        {/* Category Budgets */}
        <View style={styles.sectionHeader}>
          <Text style={styles.sectionTitle}>分类预算</Text>
          <TouchableOpacity onPress={handleAddCategoryBudget}>
            <Text style={styles.addButton}>+ 新增</Text>
          </TouchableOpacity>
        </View>

        {categoryBudgets.length === 0 ? (
          <Surface style={styles.emptyCard} elevation={1}>
            <Text style={styles.emptyText}>暂无分类预算</Text>
          </Surface>
        ) : (
          categoryBudgets.map(budget => {
            const category = getCategoryById(budget.category_id);
            return (
              <TouchableOpacity key={budget.id} onPress={() => handleDeleteBudget(budget)}>
                <Surface style={styles.categoryCard} elevation={1}>
                  <View style={styles.categoryHeader}>
                    <Text style={styles.categoryIcon}>{category?.icon || '📦'}</Text>
                    <Text style={styles.categoryName}>{category?.name || '未知'}</Text>
                    <Text style={styles.categoryBudget}>{formatCurrency(budget.amount)}</Text>
                    <Text style={styles.deleteIcon}>✕</Text>
                  </View>
                </Surface>
              </TouchableOpacity>
            );
          })
        )}

        <View style={{ height: 100 }} />
      </ScrollView>

      {/* Add/Edit Modal */}
      <Portal>
        <Modal
          visible={modalVisible}
          onDismiss={() => setModalVisible(false)}
          contentContainerStyle={styles.modal}
        >
          <Text style={styles.modalTitle}>
            {editingBudget ? '编辑预算' : selectedCategoryId ? '设置分类预算' : '设置总预算'}
          </Text>

          <TextInput
            label="预算金额"
            value={amount}
            onChangeText={setAmount}
            keyboardType="decimal-pad"
            mode="outlined"
            style={styles.input}
            left={<TextInput.Affix text="¥" />}
          />

          <Text style={styles.label}>选择分类（留空为总预算）</Text>
          <View style={styles.categoryGrid}>
            {EXPENSE_CATEGORIES.map(cat => (
              <TouchableOpacity
                key={cat.id}
                style={[
                  styles.categoryOption,
                  selectedCategoryId === cat.id && styles.categoryOptionSelected,
                ]}
                onPress={() => setSelectedCategoryId(selectedCategoryId === cat.id ? null : cat.id)}
              >
                <Text style={styles.categoryOptionIcon}>{cat.icon}</Text>
                <Text style={styles.categoryOptionText}>{cat.name}</Text>
              </TouchableOpacity>
            ))}
          </View>

          <View style={styles.modalActions}>
            <Button mode="outlined" onPress={() => setModalVisible(false)}>
              取消
            </Button>
            <Button mode="contained" onPress={handleSave} style={{ backgroundColor: COLORS.primary }}>
              保存
            </Button>
          </View>
        </Modal>
      </Portal>

      {/* Delete Confirmation Dialog */}
      <Portal>
        <Dialog visible={deleteDialogVisible} onDismiss={() => setDeleteDialogVisible(false)}>
          <Dialog.Title>确认删除</Dialog.Title>
          <Dialog.Content>
            <Text>确定要删除「{budgetToDelete?.category_id ? getCategoryById(budgetToDelete.category_id)?.name : '总预算'}」预算吗？</Text>
          </Dialog.Content>
          <Dialog.Actions>
            <Button onPress={() => setDeleteDialogVisible(false)}>取消</Button>
            <Button onPress={confirmDeleteBudget} textColor="#F44336">删除</Button>
          </Dialog.Actions>
        </Dialog>
      </Portal>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  safeArea: {
    flex: 1,
    backgroundColor: '#FFFFFF',
  },
  container: {
    flex: 1,
    backgroundColor: COLORS.surface,
    padding: SPACING.lg,
  },
  totalCard: {
    padding: SPACING.xl,
    borderRadius: BORDER_RADIUS.lg,
    backgroundColor: '#FFFFFF',
    marginBottom: SPACING.xl,
  },
  cardTitle: {
    fontSize: FONT_SIZE.lg,
    fontWeight: '600',
    color: COLORS.text,
    marginBottom: SPACING.md,
  },
  budgetInfo: {
    flexDirection: 'row',
    alignItems: 'baseline',
    marginBottom: SPACING.md,
  },
  spentAmount: {
    fontSize: FONT_SIZE.title,
    fontWeight: '700',
    color: COLORS.expense,
  },
  budgetLabel: {
    fontSize: FONT_SIZE.md,
    color: COLORS.textSecondary,
  },
  progressBar: {
    height: 8,
    backgroundColor: COLORS.surface,
    borderRadius: 4,
    overflow: 'hidden',
    marginBottom: SPACING.sm,
  },
  progressFill: {
    height: '100%',
    borderRadius: 4,
  },
  progressNormal: {
    backgroundColor: COLORS.primary,
  },
  progressOver: {
    backgroundColor: COLORS.expense,
  },
  budgetFooter: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
  },
  remainingText: {
    fontSize: FONT_SIZE.sm,
    fontWeight: '500',
  },
  overBudgetText: {
    color: COLORS.expense,
  },
  underBudgetText: {
    color: COLORS.income,
  },
  totalHint: {
    fontSize: FONT_SIZE.xs,
    color: COLORS.textLight,
  },
  emptyTotal: {
    padding: SPACING.md,
    alignItems: 'center',
  },
  emptyTotalText: {
    fontSize: FONT_SIZE.sm,
    color: COLORS.textLight,
  },
  addBudgetBtn: {
    padding: SPACING.md,
    alignItems: 'center',
    borderWidth: 1,
    borderColor: COLORS.border,
    borderRadius: BORDER_RADIUS.md,
    borderStyle: 'dashed',
  },
  addBudgetText: {
    fontSize: FONT_SIZE.md,
    color: COLORS.primary,
    fontWeight: '500',
  },
  sectionHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: SPACING.md,
  },
  sectionTitle: {
    fontSize: FONT_SIZE.lg,
    fontWeight: '600',
    color: COLORS.text,
  },
  addButton: {
    fontSize: FONT_SIZE.md,
    color: COLORS.primary,
    fontWeight: '500',
  },
  emptyCard: {
    padding: SPACING.xl,
    borderRadius: BORDER_RADIUS.lg,
    backgroundColor: '#FFFFFF',
    alignItems: 'center',
  },
  emptyText: {
    fontSize: FONT_SIZE.md,
    color: COLORS.textLight,
  },
  categoryCard: {
    padding: SPACING.lg,
    borderRadius: BORDER_RADIUS.lg,
    backgroundColor: '#FFFFFF',
    marginBottom: SPACING.sm,
  },
  categoryHeader: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: SPACING.sm,
  },
  categoryIcon: {
    fontSize: 22,
  },
  categoryName: {
    flex: 1,
    fontSize: FONT_SIZE.md,
    color: COLORS.text,
  },
  categoryBudget: {
    fontSize: FONT_SIZE.md,
    fontWeight: '600',
    color: COLORS.primary,
    flex: 1,
    textAlign: 'right',
  },
  deleteIcon: {
    fontSize: FONT_SIZE.md,
    color: COLORS.textLight,
    marginLeft: SPACING.sm,
  },
  modal: {
    backgroundColor: 'white',
    padding: SPACING.xl,
    margin: SPACING.lg,
    borderRadius: BORDER_RADIUS.lg,
  },
  modalTitle: {
    fontSize: FONT_SIZE.xl,
    fontWeight: '700',
    color: COLORS.text,
    marginBottom: SPACING.lg,
  },
  input: {
    marginBottom: SPACING.md,
    backgroundColor: '#FFFFFF',
  },
  label: {
    fontSize: FONT_SIZE.md,
    color: COLORS.text,
    marginBottom: SPACING.sm,
    fontWeight: '500',
  },
  categoryGrid: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    gap: SPACING.sm,
    marginBottom: SPACING.lg,
  },
  categoryOption: {
    alignItems: 'center',
    paddingVertical: SPACING.sm,
    paddingHorizontal: SPACING.md,
    borderRadius: BORDER_RADIUS.md,
    backgroundColor: COLORS.surface,
    borderWidth: 2,
    borderColor: 'transparent',
    minWidth: 70,
  },
  categoryOptionSelected: {
    borderColor: COLORS.primary,
    backgroundColor: COLORS.primaryLight,
  },
  categoryOptionIcon: {
    fontSize: 20,
    marginBottom: 2,
  },
  categoryOptionText: {
    fontSize: FONT_SIZE.xs,
    color: COLORS.textSecondary,
  },
  modalActions: {
    flexDirection: 'row',
    justifyContent: 'flex-end',
    gap: SPACING.md,
  },
});
