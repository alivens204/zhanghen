import React, { useState, useEffect } from 'react';
import { View, StyleSheet, ScrollView, TouchableOpacity, KeyboardAvoidingView, Platform } from 'react-native';
import { Text, TextInput, Button, SegmentedButtons, Dialog, Portal } from 'react-native-paper';
import { useRouter, useLocalSearchParams } from 'expo-router';
import { SafeAreaView } from 'react-native-safe-area-context';
import dayjs from 'dayjs';
import { COLORS, SPACING, FONT_SIZE, BORDER_RADIUS } from '../constants/theme';
import { EXPENSE_CATEGORIES, INCOME_CATEGORIES, ALL_CATEGORIES, getCategoryById } from '../constants/categories';
import { CategoryPicker } from '../components/CategoryPicker';
import { AccountPicker } from '../components/AccountPicker';
import { useAccountStore } from '../store/useAccountStore';
import { useRecordStore } from '../store/useRecordStore';
import { getAllAccounts } from '../database/queries';
import { AccountRow } from '../database/schema';
import { getToday, getCurrentTime } from '../utils/format';

export default function AddRecordScreen() {
  const router = useRouter();
  const params = useLocalSearchParams<{
    id?: string;
    amount?: string;
    type?: string;
    categoryId?: string;
    accountId?: string;
    note?: string;
    date?: string;
    time?: string;
    reimbursementStatus?: string;
    reimbursementDate?: string;
    reimbursementTime?: string;
  }>();

  const isEditing = !!params.id;
  
  const [type, setType] = useState<'income' | 'expense'>((params.type as 'income' | 'expense') || 'expense');
  const [amount, setAmount] = useState(params.amount || '');
  const [categoryId, setCategoryId] = useState(params.categoryId || '');
  const [accountId, setAccountId] = useState(params.accountId || 'account_wechat');
  const [note, setNote] = useState(params.note || '');
  const [date, setDate] = useState(params.date || getToday());
  const [time, setTime] = useState(params.time || getCurrentTime());
  const [reimbursementStatus, setReimbursementStatus] = useState(params.reimbursementStatus || 'none');
  const [reimbursementDate, setReimbursementDate] = useState(params.reimbursementDate || getToday());
  const [reimbursementTime, setReimbursementTime] = useState(params.reimbursementTime || getCurrentTime());
  const [reimbursementAmount, setReimbursementAmount] = useState('');
  const [alertVisible, setAlertVisible] = useState(false);
  const [alertTitle, setAlertTitle] = useState('');
  const [alertMessage, setAlertMessage] = useState('');
  
  const [accounts, setAccounts] = useState<AccountRow[]>([]);
  const { addTransaction, updateTransaction, deleteTransaction } = useRecordStore();

  useEffect(() => {
    loadAccounts();
  }, []);

  const loadAccounts = async () => {
    const accs = await getAllAccounts();
    setAccounts(accs);
    if (!params.accountId && accs.length > 0) {
      // 优先选择微信账户，如果没有则选择第一个账户
      const wechatAccount = accs.find(a => a.id === 'account_wechat');
      setAccountId(wechatAccount ? wechatAccount.id : accs[0].id);
    }
  };

  const categories = type === 'income' ? INCOME_CATEGORIES : EXPENSE_CATEGORIES;

  const showAlert = (title: string, message: string) => {
    setAlertTitle(title);
    setAlertMessage(message);
    setAlertVisible(true);
  };

  const handleSave = async () => {
    if (!amount || parseFloat(amount) <= 0) {
      showAlert('提示', '请输入有效金额');
      return;
    }
    if (!categoryId) {
      showAlert('提示', '请选择分类');
      return;
    }

    try {
      const wasReimbursedBefore = params.reimbursementStatus === 'reimbursed' || params.reimbursementStatus === 'partial';
      const isNowReimbursed = reimbursementStatus === 'reimbursed';
      const isNowPartial = reimbursementStatus === 'partial';
      const shouldAutoReimburseFull = isEditing && isNowReimbursed && !wasReimbursedBefore;
      const shouldAutoReimbursePartial = isEditing && isNowPartial && !wasReimbursedBefore;

      // Save the expense record
      if (isEditing && params.id) {
        await updateTransaction(
          params.id,
          parseFloat(amount),
          type,
          categoryId,
          accountId,
          note,
          date,
          time,
          reimbursementStatus,
          reimbursementStatus === 'reimbursed' ? reimbursementDate : '',
          reimbursementStatus === 'reimbursed' ? reimbursementTime : '',
          reimbursementStatus === 'partial' ? reimbursementAmount : ''
        );
      } else {
        await addTransaction(
          parseFloat(amount),
          type,
          categoryId,
          accountId,
          note,
          date,
          time,
          reimbursementStatus,
          reimbursementStatus === 'reimbursed' ? reimbursementDate : '',
          reimbursementStatus === 'reimbursed' ? reimbursementTime : '',
          reimbursementStatus === 'partial' ? reimbursementAmount : ''
        );
      }

      // Auto-generate reimbursement income when changing from pending to reimbursed/partial
      if (shouldAutoReimburseFull) {
        const now = new Date();
        const today = now.toISOString().split('T')[0];
        const currentTime = now.toTimeString().slice(0, 5);
        const originalDate = params.date || date;
        const originalTime = params.time || time;
        const originalNote = note || '无备注';

        // Full reimbursement: generate income with original amount
        await addTransaction(
          Math.abs(parseFloat(amount)),
          'income',
          'income_reimbursement',
          accountId,
          `报销：${originalDate} ${originalTime} ${originalNote}`,
          today,
          currentTime,
          'reimbursed'
        );
      }

      if (shouldAutoReimbursePartial && reimbursementAmount) {
        const now = new Date();
        const today = now.toISOString().split('T')[0];
        const currentTime = now.toTimeString().slice(0, 5);
        const originalDate = params.date || date;
        const originalTime = params.time || time;
        const originalNote = note || '无备注';
        const reimbursedAmt = parseFloat(reimbursementAmount);

        // Partial reimbursement: generate income with reimbursed amount
        await addTransaction(
          reimbursedAmt,
          'income',
          'income_reimbursement',
          accountId,
          `报销：${originalDate} ${originalTime} ${originalNote}`,
          today,
          currentTime,
          'partial'
        );
      }

      router.replace('/');
    } catch (error) {
      showAlert('错误', '保存失败，请重试');
    }
  };

  const [deleteDialogVisible, setDeleteDialogVisible] = useState(false);

  const handleDelete = () => {
    if (!params.id) return;
    setDeleteDialogVisible(true);
  };

  const confirmDelete = async () => {
    if (params.id) {
      await deleteTransaction(params.id);
      setDeleteDialogVisible(false);
      router.replace('/');
    }
  };

  return (
    <SafeAreaView style={styles.safeArea} edges={['bottom']}>
      <KeyboardAvoidingView
        style={{ flex: 1 }}
        behavior={Platform.OS === 'ios' ? 'padding' : 'height'}
        keyboardVerticalOffset={0}
      >
      <ScrollView
        style={styles.container}
        keyboardDismissMode="on-drag"
        keyboardShouldPersistTaps="handled"
        contentContainerStyle={{ flexGrow: 1 }}
      >
        {/* Type Toggle */}
        <SegmentedButtons
          value={type}
          onValueChange={(v) => {
            setType(v as 'income' | 'expense');
            setCategoryId('');
          }}
          buttons={[
            { value: 'expense', label: '支出' },
            { value: 'income', label: '收入' },
          ]}
          style={styles.segment}
        />

        {/* Amount Input */}
        <View style={styles.amountContainer}>
          <Text style={styles.currencySign}>¥</Text>
          <TextInput
            value={amount}
            onChangeText={setAmount}
            keyboardType="decimal-pad"
            placeholder="0.00"
            style={styles.amountInput}
            underlineColor="transparent"
            mode="flat"
          />
        </View>

        {/* Category Selection */}
        <View style={styles.section}>
          <Text style={styles.sectionTitle}>选择分类</Text>
          <CategoryPicker
            categories={categories}
            selectedId={categoryId}
            onSelect={setCategoryId}
          />
        </View>

        {/* Account Selection */}
        <View style={styles.section}>
          <Text style={styles.sectionTitle}>选择账户</Text>
          <AccountPicker
            accounts={accounts}
            selectedId={accountId}
            onSelect={setAccountId}
          />
        </View>

        {/* Note Input */}
        <View style={styles.section}>
          <Text style={styles.sectionTitle}>备注</Text>
          <TextInput
            value={note}
            onChangeText={setNote}
            placeholder="添加备注..."
            mode="outlined"
            style={styles.noteInput}
          />
        </View>

        {/* Date and Time */}
        <View style={styles.section}>
          <Text style={styles.sectionTitle}>日期和时间</Text>
          <View style={styles.dateTimeRow}>
            <TextInput
              value={date}
              onChangeText={setDate}
              placeholder="YYYY-MM-DD"
              mode="outlined"
              style={styles.dateInput}
              label="日期"
            />
            <TextInput
              value={time}
              onChangeText={setTime}
              placeholder="HH:mm"
              mode="outlined"
              style={styles.timeInput}
              label="时间"
            />
          </View>
        </View>

        {/* Reimbursement Toggle */}
        {type === 'expense' && (
          <View style={styles.section}>
            <Text style={styles.sectionTitle}>报销状态</Text>
            <View style={styles.reimbursementRow}>
              {[
                { value: 'none', label: '无需报销' },
                { value: 'pending', label: '待报销' },
                { value: 'reimbursed', label: '全额报销' },
                { value: 'partial', label: '部分报销' },
              ].map((option) => (
                <TouchableOpacity
                  key={option.value}
                  style={[
                    styles.reimbursementOption,
                    reimbursementStatus === option.value && styles.reimbursementOptionActive,
                    option.value === 'partial' && styles.reimbursementOptionPartial,
                    option.value === 'partial' && reimbursementStatus === 'partial' && styles.reimbursementOptionPartialActive,
                  ]}
                  onPress={() => setReimbursementStatus(option.value)}
                >
                  <Text
                    style={[
                      styles.reimbursementOptionText,
                      reimbursementStatus === option.value && styles.reimbursementOptionTextActive,
                      option.value === 'partial' && reimbursementStatus === 'partial' && styles.reimbursementOptionPartialTextActive,
                    ]}
                  >
                    {option.label}
                  </Text>
                </TouchableOpacity>
              ))}
            </View>
            {reimbursementStatus === 'reimbursed' && (
              <View style={styles.reimbursementDateTime}>
                <Text style={styles.reimbursementDateTimeLabel}>报销时间</Text>
                <View style={styles.dateTimeRow}>
                  <TextInput
                    value={reimbursementDate}
                    onChangeText={setReimbursementDate}
                    placeholder="YYYY-MM-DD"
                    mode="outlined"
                    style={styles.dateInput}
                    label="日期"
                  />
                  <TextInput
                    value={reimbursementTime}
                    onChangeText={setReimbursementTime}
                    placeholder="HH:mm"
                    mode="outlined"
                    style={styles.timeInput}
                    label="时间"
                  />
                </View>
              </View>
            )}
            {reimbursementStatus === 'partial' && (
              <View style={styles.reimbursementDateTime}>
                <Text style={styles.reimbursementDateTimeLabel}>请输入报销金额</Text>
                <View style={styles.amountContainer}>
                  <Text style={styles.currencySign}>¥</Text>
                  <TextInput
                    value={reimbursementAmount}
                    onChangeText={setReimbursementAmount}
                    keyboardType="decimal-pad"
                    placeholder="0.00"
                    style={styles.amountInput}
                    underlineColor="transparent"
                    mode="flat"
                  />
                </View>
                {reimbursementAmount && (
                  <Text style={styles.reimbursementPreview}>
                    原消费金额：-{parseFloat(amount).toFixed(2)}，报销：¥{reimbursementAmount}，剩余未报销：{(parseFloat(amount) - parseFloat(reimbursementAmount)).toFixed(2)}
                  </Text>
                )}
              </View>
            )}
          </View>
        )}

        {/* Action Buttons */}
        <View style={styles.actions}>
          <Button
            mode="contained"
            onPress={handleSave}
            style={styles.saveButton}
            labelStyle={styles.saveButtonText}
          >
            {isEditing ? '保存修改' : '保存'}
          </Button>
          {isEditing && (
            <Button
              mode="outlined"
              onPress={handleDelete}
              style={styles.deleteButton}
              labelStyle={styles.deleteButtonText}
              textColor={COLORS.expense}
            >
              删除记录
            </Button>
          )}
        </View>

        {/* 键盘安全区域 - 防止输入法覆盖底部内容 */}
        <View style={styles.keyboardSafeArea} />
      </ScrollView>
      </KeyboardAvoidingView>

      {/* Alert Dialog */}
      <Portal>
        <Dialog visible={alertVisible} onDismiss={() => setAlertVisible(false)}>
          <Dialog.Title>{alertTitle}</Dialog.Title>
          <Dialog.Content>
            <Text>{alertMessage}</Text>
          </Dialog.Content>
          <Dialog.Actions>
            <Button onPress={() => setAlertVisible(false)}>确定</Button>
          </Dialog.Actions>
        </Dialog>
      </Portal>

      {/* Delete Dialog */}
      <Portal>
        <Dialog visible={deleteDialogVisible} onDismiss={() => setDeleteDialogVisible(false)}>
          <Dialog.Title>确认删除</Dialog.Title>
          <Dialog.Content>
            <Text>确定要删除这条记录吗？</Text>
          </Dialog.Content>
          <Dialog.Actions>
            <Button onPress={() => setDeleteDialogVisible(false)}>取消</Button>
            <Button onPress={confirmDelete} textColor="#F44336">删除</Button>
          </Dialog.Actions>
        </Dialog>
      </Portal>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  safeArea: {
    flex: 1,
    backgroundColor: '#FFFFFF',
  },
  container: {
    flex: 1,
    backgroundColor: '#FFFFFF',
    padding: SPACING.lg,
  },
  segment: {
    marginBottom: SPACING.lg,
  },
  amountContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: COLORS.surface,
    borderRadius: BORDER_RADIUS.lg,
    paddingHorizontal: SPACING.lg,
    marginBottom: SPACING.xl,
  },
  currencySign: {
    fontSize: FONT_SIZE.title,
    fontWeight: '700',
    color: COLORS.primary,
  },
  amountInput: {
    flex: 1,
    fontSize: FONT_SIZE.header,
    fontWeight: '700',
    backgroundColor: 'transparent',
  },
  section: {
    marginBottom: SPACING.lg,
  },
  sectionTitle: {
    fontSize: FONT_SIZE.md,
    fontWeight: '600',
    color: COLORS.text,
    marginBottom: SPACING.sm,
  },
  noteInput: {
    backgroundColor: '#FFFFFF',
  },
  dateTimeRow: {
    flexDirection: 'row',
    gap: SPACING.md,
  },
  dateInput: {
    flex: 2,
    backgroundColor: '#FFFFFF',
  },
  timeInput: {
    flex: 1,
    backgroundColor: '#FFFFFF',
  },
  reimbursementRow: {
    flexDirection: 'row',
    gap: SPACING.sm,
  },
  reimbursementOption: {
    paddingVertical: SPACING.sm,
    paddingHorizontal: SPACING.lg,
    borderRadius: BORDER_RADIUS.md,
    borderWidth: 1,
    borderColor: COLORS.border,
  },
  reimbursementOptionActive: {
    backgroundColor: COLORS.pendingLight,
    borderColor: COLORS.pending,
  },
  reimbursementOptionText: {
    fontSize: FONT_SIZE.sm,
    color: COLORS.textSecondary,
  },
  reimbursementOptionTextActive: {
    color: COLORS.pending,
    fontWeight: '600',
  },
  reimbursementOptionPartial: {
    borderColor: '#FF9800',
  },
  reimbursementOptionPartialActive: {
    backgroundColor: '#FFF3E0',
    borderColor: '#FF9800',
  },
  reimbursementOptionPartialTextActive: {
    color: '#FF9800',
    fontWeight: '600',
  },
  reimbursementPreview: {
    fontSize: FONT_SIZE.sm,
    color: COLORS.textSecondary,
    marginTop: SPACING.sm,
    lineHeight: 20,
  },
  reimbursementDateTime: {
    marginTop: SPACING.md,
  },
  reimbursementDateTimeLabel: {
    fontSize: FONT_SIZE.sm,
    color: COLORS.textSecondary,
    marginBottom: SPACING.sm,
  },
  actions: {
    marginTop: SPACING.xl,
    gap: SPACING.md,
    paddingBottom: SPACING.md,
  },
  keyboardSafeArea: {
    height: 400,
  },
  saveButton: {
    backgroundColor: COLORS.primary,
    borderRadius: BORDER_RADIUS.md,
    paddingVertical: 4,
  },
  saveButtonText: {
    fontSize: FONT_SIZE.lg,
    fontWeight: '600',
  },
  deleteButton: {
    borderColor: COLORS.expense,
    borderRadius: BORDER_RADIUS.md,
  },
  deleteButtonText: {
    fontSize: FONT_SIZE.md,
  },
});
