import React, { useState, useEffect } from 'react';
import { View, StyleSheet, ScrollView, Linking } from 'react-native';
import { Text, TextInput, Button, Surface, Divider, Dialog, Portal } from 'react-native-paper';
import { SafeAreaView } from 'react-native-safe-area-context';
import { MaterialCommunityIcons } from '@expo/vector-icons';
import { COLORS, SPACING, FONT_SIZE, BORDER_RADIUS } from '../constants/theme';
import {
  saveDbConfig,
  getDbConfig,
  saveApiUrl,
  getApiUrl,
  testConnection,
  initTables,
  DbConfig,
} from '../sync/cloudSync';

export default function DbConfigScreen() {
  const [apiUrl, setApiUrl] = useState('');
  const [config, setConfig] = useState<DbConfig>({
    host: 'localhost',
    port: '3306',
    user: 'root',
    password: '',
    database: 'jz',
  });
  const [connected, setConnected] = useState(false);
  const [loading, setLoading] = useState(false);
  const [dialogVisible, setDialogVisible] = useState(false);
  const [dialogTitle, setDialogTitle] = useState('');
  const [dialogMessage, setDialogMessage] = useState('');
  const [confirmAction, setConfirmAction] = useState<(() => void) | null>(null);

  const showAlert = (title: string, message: string) => {
    setDialogTitle(title);
    setDialogMessage(message);
    setConfirmAction(null);
    setDialogVisible(true);
  };

  const showConfirm = (title: string, message: string, onConfirm: () => void) => {
    setDialogTitle(title);
    setDialogMessage(message);
    setConfirmAction(() => onConfirm);
    setDialogVisible(true);
  };

  useEffect(() => {
    loadConfig();
  }, []);

  const loadConfig = async () => {
    const savedConfig = await getDbConfig();
    if (savedConfig) setConfig(savedConfig);
    const savedApiUrl = await getApiUrl();
    setApiUrl(savedApiUrl);
  };

  const handleConnect = async () => {
    if (!apiUrl) {
      showAlert('提示', '请填写 API 地址');
      return;
    }

    setLoading(true);
    try {
      await saveApiUrl(apiUrl);
      await saveDbConfig(config);

      const result = await testConnection(config);
      if (result.success) {
        setConnected(true);
        showAlert('连接成功', result.message);
      } else {
        showAlert('连接失败', result.message);
      }
    } catch (error: any) {
      showAlert('错误', error.message);
    } finally {
      setLoading(false);
    }
  };

  const handleInitTables = async () => {
    showConfirm('确认初始化', '将在云端数据库创建数据表并插入默认分类和账户数据。\n\n如果表已存在，数据不会重复。', async () => {
      setLoading(true);
      try {
        const result = await initTables();
        if (result.success) {
          showAlert('初始化成功', result.message);
        } else {
          showAlert('初始化失败', result.message);
        }
      } catch (error: any) {
        showAlert('错误', error.message);
      } finally {
        setLoading(false);
      }
    });
  };

  return (
    <SafeAreaView style={styles.safeArea} edges={['bottom']}>
      <ScrollView style={styles.container}>
        {/* API Server Config */}
        <Surface style={styles.card} elevation={2}>
          <View style={styles.cardHeader}>
            <MaterialCommunityIcons name="server" size={22} color={COLORS.primary} />
            <Text style={styles.cardTitle}>API 服务器</Text>
          </View>

          <Text style={styles.hint}>
            填写 PHP 后端 API 的地址。{'\n'}
            格式：http://服务器IP/php-api
          </Text>

          <TextInput
            label="API 地址"
            value={apiUrl}
            onChangeText={setApiUrl}
            mode="outlined"
            style={styles.input}
            placeholder="http://120.24.26.15/php-api"
            autoCapitalize="none"
            autoCorrect={false}
          />
        </Surface>

        {/* Database Config */}
        <Surface style={styles.card} elevation={2}>
          <View style={styles.cardHeader}>
            <MaterialCommunityIcons name="database" size={22} color={COLORS.primary} />
            <Text style={styles.cardTitle}>MySQL 数据库</Text>
          </View>

          <Text style={styles.hint}>
            填写 PHP 后端所在服务器的 MySQL 连接信息。
          </Text>

          <View style={styles.formRow}>
            <TextInput
              label="主机地址"
              value={config.host}
              onChangeText={(v) => setConfig({ ...config, host: v })}
              mode="outlined"
              style={[styles.input, styles.halfInput]}
              placeholder="localhost"
            />
            <TextInput
              label="端口"
              value={config.port}
              onChangeText={(v) => setConfig({ ...config, port: v })}
              mode="outlined"
              style={[styles.input, styles.quarterInput]}
              keyboardType="number-pad"
              placeholder="3306"
            />
          </View>

          <TextInput
            label="数据库名"
            value={config.database}
            onChangeText={(v) => setConfig({ ...config, database: v })}
            mode="outlined"
            style={styles.input}
            placeholder="jz"
          />

          <TextInput
            label="用户名"
            value={config.user}
            onChangeText={(v) => setConfig({ ...config, user: v })}
            mode="outlined"
            style={styles.input}
            placeholder="root"
          />

          <TextInput
            label="密码"
            value={config.password}
            onChangeText={(v) => setConfig({ ...config, password: v })}
            mode="outlined"
            style={styles.input}
            secureTextEntry
            placeholder="输入密码"
          />

          <Button
            mode="contained"
            onPress={handleConnect}
            loading={loading}
            style={styles.connectBtn}
            buttonColor={COLORS.primary}
          >
            测试连接
          </Button>
        </Surface>

        {/* Actions */}
        <Surface style={styles.card} elevation={2}>
          <View style={styles.cardHeader}>
            <MaterialCommunityIcons name="cog" size={22} color={COLORS.primary} />
            <Text style={styles.cardTitle}>数据库操作</Text>
          </View>

          <Text style={styles.hint}>
            首次连接请先「测试连接」，然后点击「初始化数据表」自动创建表结构和默认数据。
          </Text>

          <Button
            mode="contained"
            onPress={handleInitTables}
            loading={loading}
            disabled={!connected}
            style={styles.actionBtn}
            buttonColor={COLORS.success}
            icon="database-plus"
          >
            初始化数据表
          </Button>
        </Surface>

        {/* Setup Guide */}
        <Surface style={styles.infoCard} elevation={1}>
          <Text style={styles.infoTitle}>📋 前后端分离架构</Text>
          <Text style={styles.infoText}>架构：手机App → PHP API → MySQL</Text>
          <Divider style={styles.divider} />
          <Text style={styles.infoText}>1. 在服务器部署 PHP API（php-api 目录）</Text>
          <Text style={styles.infoText}>2. 确保服务器已安装 PHP + MySQL</Text>
          <Text style={styles.infoText}>3. 填写 API 地址：http://服务器IP/php-api</Text>
          <Text style={styles.infoText}>4. 填写 MySQL 连接信息</Text>
          <Text style={styles.infoText}>5. 点击「测试连接」验证</Text>
          <Text style={styles.infoText}>6. 点击「初始化数据表」创建表结构</Text>
        </Surface>

        <View style={{ height: 100 }} />
      </ScrollView>

      <Portal>
        <Dialog visible={dialogVisible} onDismiss={() => { setDialogVisible(false); setConfirmAction(null); }}>
          <Dialog.Title>{dialogTitle}</Dialog.Title>
          <Dialog.Content>
            <Text>{dialogMessage}</Text>
          </Dialog.Content>
          <Dialog.Actions>
            {confirmAction && (
              <Button onPress={() => { setDialogVisible(false); confirmAction(); setConfirmAction(null); }}>确认</Button>
            )}
            <Button onPress={() => { setDialogVisible(false); setConfirmAction(null); }}>{confirmAction ? '取消' : '确定'}</Button>
          </Dialog.Actions>
        </Dialog>
      </Portal>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  safeArea: {
    flex: 1,
    backgroundColor: '#FFFFFF',
  },
  container: {
    flex: 1,
    backgroundColor: COLORS.surface,
    padding: SPACING.lg,
  },
  card: {
    borderRadius: BORDER_RADIUS.lg,
    padding: SPACING.lg,
    backgroundColor: '#FFFFFF',
    marginBottom: SPACING.md,
  },
  cardHeader: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: SPACING.sm,
    marginBottom: SPACING.md,
  },
  cardTitle: {
    fontSize: FONT_SIZE.lg,
    fontWeight: '600',
    color: COLORS.text,
  },
  input: {
    marginBottom: SPACING.md,
    backgroundColor: '#FFFFFF',
  },
  formRow: {
    flexDirection: 'row',
    gap: SPACING.sm,
  },
  halfInput: {
    flex: 2,
  },
  quarterInput: {
    flex: 1,
  },
  connectBtn: {
    marginTop: SPACING.sm,
  },
  actionBtn: {
    marginTop: SPACING.sm,
  },
  hint: {
    fontSize: FONT_SIZE.sm,
    color: COLORS.textSecondary,
    marginBottom: SPACING.md,
    lineHeight: 20,
  },
  infoCard: {
    borderRadius: BORDER_RADIUS.lg,
    padding: SPACING.lg,
    backgroundColor: '#FFFFFF',
    marginBottom: SPACING.md,
  },
  infoTitle: {
    fontSize: FONT_SIZE.md,
    fontWeight: '600',
    color: COLORS.text,
    marginBottom: SPACING.sm,
  },
  infoText: {
    fontSize: FONT_SIZE.sm,
    color: COLORS.textSecondary,
    lineHeight: 22,
  },
  divider: {
    marginVertical: SPACING.sm,
  },
});
