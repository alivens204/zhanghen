import { create } from 'zustand';
import { TransactionRow } from '../database/schema';
import * as queries from '../database/queries';

interface RecordState {
  transactions: TransactionRow[];
  loading: boolean;
  fetchAll: () => Promise<void>;
  fetchByDate: (date: string) => Promise<TransactionRow[]>;
  fetchByMonth: (yearMonth: string) => Promise<TransactionRow[]>;
  addTransaction: (
    amount: number,
    type: 'income' | 'expense',
    categoryId: string,
    accountId: string,
    note: string,
    date: string,
    time: string,
    reimbursementStatus?: string,
    reimbursementDate?: string,
    reimbursementTime?: string,
    reimbursementAmount?: string
  ) => Promise<TransactionRow>;
  updateTransaction: (
    id: string,
    amount: number,
    type: 'income' | 'expense',
    categoryId: string,
    accountId: string,
    note: string,
    date: string,
    time: string,
    reimbursementStatus: string,
    reimbursementDate?: string,
    reimbursementTime?: string,
    reimbursementAmount?: string
  ) => Promise<void>;
  deleteTransaction: (id: string) => Promise<void>;
  updateReimbursement: (id: string, status: string, note?: string) => Promise<void>;
}

export const useRecordStore = create<RecordState>((set) => ({
  transactions: [],
  loading: false,

  fetchAll: async () => {
    set({ loading: true });
    const transactions = await queries.getAllTransactions();
    set({ transactions, loading: false });
  },

  fetchByDate: async (date: string) => {
    return await queries.getTransactionsByDate(date);
  },

  fetchByMonth: async (yearMonth: string) => {
    return await queries.getTransactionsByMonth(yearMonth);
  },

  addTransaction: async (amount, type, categoryId, accountId, note, date, time, reimbursementStatus = 'none', reimbursementDate = '', reimbursementTime = '', reimbursementAmount = '') => {
    const tx = await queries.addTransaction(amount, type, categoryId, accountId, note, date, time, reimbursementStatus, reimbursementDate, reimbursementTime);
    set((state) => ({ transactions: [tx, ...state.transactions] }));
    return tx;
  },

  updateTransaction: async (id, amount, type, categoryId, accountId, note, date, time, reimbursementStatus, reimbursementDate = '', reimbursementTime = '', reimbursementAmount = '') => {
    await queries.updateTransaction(id, amount, type, categoryId, accountId, note, date, time, reimbursementStatus, reimbursementDate, reimbursementTime);
    set((state) => ({
      transactions: state.transactions.map((tx) =>
        tx.id === id ? { ...tx, amount, type, category_id: categoryId, account_id: accountId, note, date, time, reimbursement_status: reimbursementStatus, reimbursement_date: reimbursementStatus === 'reimbursed' ? reimbursementDate : reimbursementStatus === 'partial' ? reimbursementAmount : '', reimbursement_note: reimbursementStatus === 'reimbursed' ? reimbursementTime : reimbursementStatus === 'partial' ? reimbursementTime : '' } : tx
      ),
    }));
  },

  deleteTransaction: async (id: string) => {
    await queries.deleteTransaction(id);
    set((state) => ({
      transactions: state.transactions.filter((tx) => tx.id !== id),
    }));
  },

  updateReimbursement: async (id: string, status: string, note: string = '') => {
    await queries.updateReimbursementStatus(id, status, note);
    if (status === 'reimbursed') {
      const tx = await queries.getAllTransactions();
      const reimbursedTx = tx.find(t => t.id === id);
      if (reimbursedTx) {
        await queries.addTransaction(
          reimbursedTx.amount,
          'income',
          'income_reimbursement',
          reimbursedTx.account_id,
          `报销: ${reimbursedTx.note || '未备注'}`,
          new Date().toISOString().split('T')[0],
          new Date().toTimeString().slice(0, 5),
          'none'
        );
      }
    }
    set((state) => ({
      transactions: state.transactions.map((tx) =>
        tx.id === id ? { ...tx, reimbursement_status: status, reimbursement_note: note } : tx
      ),
    }));
  },
}));
