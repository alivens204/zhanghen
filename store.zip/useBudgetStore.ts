import { create } from 'zustand';
import { BudgetRow } from '../database/schema';
import * as queries from '../database/queries';

interface BudgetState {
  budgets: BudgetRow[];
  loading: boolean;
  fetchAll: () => Promise<void>;
  setBudget: (amount: number, period: string, categoryId: string | null) => Promise<BudgetRow>;
  deleteBudget: (id: string) => Promise<void>;
}

export const useBudgetStore = create<BudgetState>((set) => ({
  budgets: [],
  loading: false,

  fetchAll: async () => {
    set({ loading: true });
    const budgets = await queries.getAllBudgets();
    set({ budgets, loading: false });
  },

  setBudget: async (amount, period, categoryId) => {
    const budget = await queries.upsertBudget(amount, period, categoryId);
    set((state) => {
      const existing = state.budgets.find(b => b.id === budget.id);
      if (existing) {
        return { budgets: state.budgets.map(b => b.id === budget.id ? budget : b) };
      }
      return { budgets: [...state.budgets, budget] };
    });
    return budget;
  },

  deleteBudget: async (id: string) => {
    await queries.deleteBudget(id);
    set((state) => ({
      budgets: state.budgets.filter((b) => b.id !== id),
    }));
  },
}));
