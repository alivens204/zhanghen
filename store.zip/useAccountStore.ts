import { create } from 'zustand';
import { AccountRow } from '../database/schema';
import * as queries from '../database/queries';

interface AccountState {
  accounts: AccountRow[];
  loading: boolean;
  fetchAll: () => Promise<void>;
  addAccount: (name: string, type: string, icon: string, color: string) => Promise<AccountRow>;
  updateAccount: (id: string, name: string, type: string, icon: string, color: string, balance?: number) => Promise<void>;
  deleteAccount: (id: string) => Promise<void>;
}

export const useAccountStore = create<AccountState>((set) => ({
  accounts: [],
  loading: false,

  fetchAll: async () => {
    set({ loading: true });
    const accounts = await queries.getAllAccounts();
    set({ accounts, loading: false });
  },

  addAccount: async (name, type, icon, color) => {
    const account = await queries.addAccount(name, type, icon, color);
    set((state) => ({ accounts: [...state.accounts, account] }));
    return account;
  },

  updateAccount: async (id, name, type, icon, color, balance?) => {
    await queries.updateAccount(id, name, type, icon, color, balance);
    set((state) => ({
      accounts: state.accounts.map((a) =>
        a.id === id ? { ...a, name, type, icon, color, ...(balance !== undefined ? { balance } : {}) } : a
      ),
    }));
  },

  deleteAccount: async (id: string) => {
    await queries.deleteAccount(id);
    set((state) => ({
      accounts: state.accounts.filter((a) => a.id !== id),
    }));
  },
}));
