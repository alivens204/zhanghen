export const CREATE_TABLES_SQL = `
  CREATE TABLE IF NOT EXISTS accounts (
    id TEXT PRIMARY KEY,
    name TEXT NOT NULL,
    type TEXT NOT NULL,
    balance REAL DEFAULT 0,
    icon TEXT,
    color TEXT
  );

  CREATE TABLE IF NOT EXISTS categories (
    id TEXT PRIMARY KEY,
    name TEXT NOT NULL,
    type TEXT NOT NULL,
    icon TEXT,
    color TEXT
  );

  CREATE TABLE IF NOT EXISTS transactions (
    id TEXT PRIMARY KEY,
    amount REAL NOT NULL,
    type TEXT NOT NULL,
    category_id TEXT,
    account_id TEXT,
    note TEXT,
    date TEXT NOT NULL,
    time TEXT,
    created_at TEXT,
    reimbursement_status TEXT DEFAULT 'none',
    reimbursement_date TEXT,
    reimbursement_note TEXT
  );

  CREATE TABLE IF NOT EXISTS budgets (
    id TEXT PRIMARY KEY,
    amount REAL NOT NULL,
    period TEXT NOT NULL,
    category_id TEXT
  );
`;

export interface AccountRow {
  id: string;
  name: string;
  type: string;
  balance: number;
  icon: string;
  color: string;
}

export interface CategoryRow {
  id: string;
  name: string;
  type: string;
  icon: string;
  color: string;
}

export interface TransactionRow {
  id: string;
  amount: number;
  type: string;
  category_id: string;
  account_id: string;
  note: string;
  date: string;
  time: string;
  created_at: string;
  reimbursement_status: string;
  reimbursement_date: string;
  reimbursement_note: string;
}

export interface BudgetRow {
  id: string;
  amount: number;
  period: string;
  category_id: string;
}

export interface MonthlySummary {
  month: string;
  income: number;
  expense: number;
}

export interface DailySummary {
  date: string;
  income: number;
  expense: number;
}
