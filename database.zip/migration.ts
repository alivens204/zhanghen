import { initializeStorage } from './storage';

export const initializeDatabase = async (): Promise<void> => {
  await initializeStorage();
  console.log('Storage initialized successfully');
};
