// Crypto polyfill for uuid v4 on Android (must be before uuid import)
if (typeof globalThis.crypto === 'undefined') {
  (globalThis as any).crypto = {
    getRandomValues: (arr: Uint8Array) => {
      for (let i = 0; i < arr.length; i++) {
        arr[i] = Math.floor(Math.random() * 256);
      }
      return arr;
    },
    subtle: {
      digest: async () => new ArrayBuffer(0),
    },
  };
}

import { Platform } from 'react-native';
import AsyncStorage from '@react-native-async-storage/async-storage';
import { v4 as uuidv4 } from 'uuid';

// ==================== Types ====================

export interface AccountRow {
  id: string;
  name: string;
  type: string;
  balance: number;
  icon: string;
  color: string;
}

export interface CategoryRow {
  id: string;
  name: string;
  type: string;
  icon: string;
  color: string;
}

export interface TransactionRow {
  id: string;
  amount: number;
  type: string;
  category_id: string;
  account_id: string;
  note: string;
  date: string;
  time: string;
  created_at: string;
  reimbursement_status: string;
  reimbursement_date: string;
  reimbursement_note: string;
}

export interface BudgetRow {
  id: string;
  amount: number;
  period: string;
  category_id: string;
}

// ==================== AsyncStorage Helper ====================

const STORE_KEYS = {
  accounts: '@accounting_accounts',
  categories: '@accounting_categories',
  transactions: '@accounting_transactions',
  budgets: '@accounting_budgets',
};

async function getStoreData<T>(key: string): Promise<T[]> {
  try {
    const json = await AsyncStorage.getItem(key);
    return json ? JSON.parse(json) : [];
  } catch {
    return [];
  }
}

async function setStoreData<T>(key: string, data: T[]): Promise<void> {
  await AsyncStorage.setItem(key, JSON.stringify(data));
}

// ==================== Default Data ====================

const DEFAULT_CATEGORIES: CategoryRow[] = [
  { id: 'expense_food', name: '餐饮', type: 'expense', icon: '🍜', color: '#FF6B6B' },
  { id: 'expense_transport', name: '交通', type: 'expense', icon: '🚗', color: '#4ECDC4' },
  { id: 'expense_daily', name: '日用', type: 'expense', icon: '🛒', color: '#45B7D1' },
  { id: 'expense_clothing', name: '服饰', type: 'expense', icon: '👔', color: '#96CEB4' },
  { id: 'expense_entertainment', name: '娱乐', type: 'expense', icon: '🎮', color: '#FFEAA7' },
  { id: 'expense_housing', name: '住房', type: 'expense', icon: '🏠', color: '#DDA0DD' },
  { id: 'expense_medical', name: '医疗', type: 'expense', icon: '💊', color: '#98D8C8' },
  { id: 'expense_education', name: '教育', type: 'expense', icon: '📚', color: '#F7DC6F' },
  { id: 'expense_communication', name: '通讯', type: 'expense', icon: '📱', color: '#BB8FCE' },
  { id: 'expense_finance', name: '金融', type: 'expense', icon: '💳', color: '#85C1E9' },
  { id: 'expense_other', name: '其他支出', type: 'expense', icon: '📦', color: '#AEB6BF' },
  { id: 'income_salary', name: '工资', type: 'income', icon: '💼', color: '#2ECC71' },
  { id: 'income_bonus', name: '奖金', type: 'income', icon: '🎁', color: '#E74C3C' },
  { id: 'income_investment', name: '投资', type: 'income', icon: '📈', color: '#3498DB' },
  { id: 'income_parttime', name: '兼职', type: 'income', icon: '💻', color: '#9B59B6' },
  { id: 'income_redpacket', name: '红包', type: 'income', icon: '🧧', color: '#E74C3C' },
  { id: 'income_reimbursement', name: '报销', type: 'income', icon: '💰', color: '#F39C12' },
  { id: 'income_other', name: '其他收入', type: 'income', icon: '💰', color: '#27AE60' },
];

const DEFAULT_ACCOUNTS: AccountRow[] = [
  { id: 'account_cash', name: '现金', type: 'cash', balance: 0, icon: '💵', color: '#27AE60' },
  { id: 'account_bank', name: '银行卡', type: 'bank', balance: 0, icon: '🏦', color: '#3498DB' },
  { id: 'account_credit', name: '信用卡', type: 'credit', balance: 0, icon: '💳', color: '#E74C3C' },
  { id: 'account_alipay', name: '支付宝', type: 'alipay', balance: 0, icon: '📱', color: '#1677FF' },
  { id: 'account_wechat', name: '微信', type: 'wechat', balance: 0, icon: '💬', color: '#07C160' },
];

// ==================== Seed ====================

export async function initializeStorage(): Promise<void> {
  const cats = await getStoreData<CategoryRow>(STORE_KEYS.categories);
  if (cats.length === 0) {
    await setStoreData(STORE_KEYS.categories, DEFAULT_CATEGORIES);
  }
  const accs = await getStoreData<AccountRow>(STORE_KEYS.accounts);
  if (accs.length === 0) {
    await setStoreData(STORE_KEYS.accounts, DEFAULT_ACCOUNTS);
  }
}

// ==================== TRANSACTIONS ====================

export async function getAllTransactions(): Promise<TransactionRow[]> {
  const all = await getStoreData<TransactionRow>(STORE_KEYS.transactions);
  return all.sort((a, b) => b.date.localeCompare(a.date) || b.time.localeCompare(a.time));
}

export async function getTransactionsByDate(date: string): Promise<TransactionRow[]> {
  const all = await getStoreData<TransactionRow>(STORE_KEYS.transactions);
  return all.filter(tx => tx.date === date).sort((a, b) => b.time.localeCompare(a.time));
}

export async function getTransactionsByMonth(yearMonth: string): Promise<TransactionRow[]> {
  const all = await getStoreData<TransactionRow>(STORE_KEYS.transactions);
  return all
    .filter(tx => tx.date.startsWith(yearMonth))
    .sort((a, b) => b.date.localeCompare(a.date) || b.time.localeCompare(a.time));
}

export async function addTransaction(
  amount: number,
  type: 'income' | 'expense',
  categoryId: string,
  accountId: string,
  note: string,
  date: string,
  time: string,
  reimbursementStatus: string = 'none',
  reimbursementDate: string = '',
  reimbursementTime: string = ''
): Promise<TransactionRow> {
  const all = await getStoreData<TransactionRow>(STORE_KEYS.transactions);
  const tx: TransactionRow = {
    id: uuidv4(),
    amount,
    type,
    category_id: categoryId,
    account_id: accountId,
    note,
    date,
    time,
    created_at: new Date().toISOString(),
    reimbursement_status: reimbursementStatus,
    reimbursement_date: reimbursementStatus === 'reimbursed' ? reimbursementDate : reimbursementStatus === 'partial' ? reimbursementDate : '',
    reimbursement_note: reimbursementStatus === 'reimbursed' ? reimbursementTime : reimbursementStatus === 'partial' ? reimbursementTime : '',
  };
  all.push(tx);
  await setStoreData(STORE_KEYS.transactions, all);

  // Update account balance
  const accounts = await getStoreData<AccountRow>(STORE_KEYS.accounts);
  const idx = accounts.findIndex(a => a.id === accountId);
  if (idx >= 0) {
    accounts[idx].balance += type === 'income' ? amount : -amount;
    await setStoreData(STORE_KEYS.accounts, accounts);
  }

  return tx;
}

export async function updateTransaction(
  id: string,
  amount: number,
  type: 'income' | 'expense',
  categoryId: string,
  accountId: string,
  note: string,
  date: string,
  time: string,
  reimbursementStatus: string,
  reimbursementDate: string = '',
  reimbursementTime: string = '',
  reimbursementAmount: string = ''
): Promise<void> {
  const all = await getStoreData<TransactionRow>(STORE_KEYS.transactions);
  const idx = all.findIndex(tx => tx.id === id);
  if (idx < 0) return;

  const oldTx = all[idx];

  // Reverse old balance
  const accounts = await getStoreData<AccountRow>(STORE_KEYS.accounts);
  const oldAccIdx = accounts.findIndex(a => a.id === oldTx.account_id);
  if (oldAccIdx >= 0) {
    accounts[oldAccIdx].balance += oldTx.type === 'income' ? -oldTx.amount : oldTx.amount;
  }

  // Apply new balance
  const newAccIdx = accounts.findIndex(a => a.id === accountId);
  if (newAccIdx >= 0) {
    accounts[newAccIdx].balance += type === 'income' ? amount : -amount;
  }
  await setStoreData(STORE_KEYS.accounts, accounts);

  all[idx] = {
    ...all[idx],
    amount, type, category_id: categoryId, account_id: accountId,
    note, date, time,
    reimbursement_status: reimbursementStatus,
    reimbursement_date: reimbursementStatus === 'reimbursed' ? reimbursementDate : reimbursementStatus === 'partial' ? reimbursementAmount : '',
    reimbursement_note: reimbursementStatus === 'reimbursed' ? reimbursementTime : reimbursementStatus === 'partial' ? reimbursementTime : '',
  };
  await setStoreData(STORE_KEYS.transactions, all);
}

export async function deleteTransaction(id: string): Promise<void> {
  const all = await getStoreData<TransactionRow>(STORE_KEYS.transactions);
  const tx = all.find(t => t.id === id);
  if (tx) {
    const accounts = await getStoreData<AccountRow>(STORE_KEYS.accounts);
    const idx = accounts.findIndex(a => a.id === tx.account_id);
    if (idx >= 0) {
      accounts[idx].balance += tx.type === 'income' ? -tx.amount : tx.amount;
      await setStoreData(STORE_KEYS.accounts, accounts);
    }
  }
  await setStoreData(STORE_KEYS.transactions, all.filter(t => t.id !== id));
}

export async function updateReimbursementStatus(
  id: string,
  status: string,
  note: string = ''
): Promise<void> {
  const all = await getStoreData<TransactionRow>(STORE_KEYS.transactions);
  const idx = all.findIndex(tx => tx.id === id);
  if (idx < 0) return;
  all[idx].reimbursement_status = status;
  all[idx].reimbursement_date = status === 'reimbursed' ? new Date().toISOString().split('T')[0] : '';
  all[idx].reimbursement_note = note;
  await setStoreData(STORE_KEYS.transactions, all);
}

// ==================== HIERARCHICAL QUERIES ====================

export async function getYearlyMonthlySummary(year: string): Promise<{ month: string; income: number; expense: number }[]> {
  const all = await getStoreData<TransactionRow>(STORE_KEYS.transactions);
  const filtered = all.filter(tx => tx.date.startsWith(year));
  const map: Record<string, { income: number; expense: number }> = {};
  for (const tx of filtered) {
    const month = tx.date.slice(5, 7);
    if (!map[month]) map[month] = { income: 0, expense: 0 };
    if (tx.type === 'income') map[month].income += tx.amount;
    else map[month].expense += tx.amount;
  }
  return Object.entries(map)
    .map(([month, data]) => ({ month, ...data }))
    .sort((a, b) => a.month.localeCompare(b.month));
}

export async function getMonthlyDailySummary(yearMonth: string): Promise<{ date: string; income: number; expense: number }[]> {
  const all = await getStoreData<TransactionRow>(STORE_KEYS.transactions);
  const filtered = all.filter(tx => tx.date.startsWith(yearMonth));
  const map: Record<string, { income: number; expense: number }> = {};
  for (const tx of filtered) {
    if (!map[tx.date]) map[tx.date] = { income: 0, expense: 0 };
    if (tx.type === 'income') map[tx.date].income += tx.amount;
    else map[tx.date].expense += tx.amount;
  }
  return Object.entries(map)
    .map(([date, data]) => ({ date, ...data }))
    .sort((a, b) => b.date.localeCompare(a.date));
}

export async function getYearlyTotal(year: string): Promise<{ income: number; expense: number }> {
  const all = await getStoreData<TransactionRow>(STORE_KEYS.transactions);
  const filtered = all.filter(tx => tx.date.startsWith(year));
  return filtered.reduce(
    (acc, tx) => {
      if (tx.type === 'income') acc.income += tx.amount;
      else acc.expense += tx.amount;
      return acc;
    },
    { income: 0, expense: 0 }
  );
}

export async function getCategoryStats(
  startDate: string,
  endDate: string,
  type: 'income' | 'expense'
): Promise<{ category_id: string; total: number }[]> {
  const all = await getStoreData<TransactionRow>(STORE_KEYS.transactions);
  const filtered = all.filter(tx => tx.date >= startDate && tx.date <= endDate && tx.type === type && tx.reimbursement_status !== 'reimbursed');
  const map: Record<string, number> = {};
  for (const tx of filtered) {
    map[tx.category_id] = (map[tx.category_id] || 0) + tx.amount;
  }
  return Object.entries(map)
    .map(([category_id, total]) => ({ category_id, total }))
    .sort((a, b) => b.total - a.total);
}

// ==================== ACCOUNTS ====================

export async function getAllAccounts(): Promise<AccountRow[]> {
  return getStoreData<AccountRow>(STORE_KEYS.accounts);
}

export async function addAccount(name: string, type: string, icon: string, color: string): Promise<AccountRow> {
  const all = await getStoreData<AccountRow>(STORE_KEYS.accounts);
  const acc: AccountRow = { id: uuidv4(), name, type, balance: 0, icon, color };
  all.push(acc);
  await setStoreData(STORE_KEYS.accounts, all);
  return acc;
}

export async function updateAccount(id: string, name: string, type: string, icon: string, color: string, balance?: number): Promise<void> {
  const all = await getStoreData<AccountRow>(STORE_KEYS.accounts);
  const idx = all.findIndex(a => a.id === id);
  if (idx >= 0) {
    all[idx] = { ...all[idx], name, type, icon, color, ...(balance !== undefined ? { balance } : {}) };
    await setStoreData(STORE_KEYS.accounts, all);
  }
}

export async function deleteAccount(id: string): Promise<void> {
  const all = await getStoreData<AccountRow>(STORE_KEYS.accounts);
  await setStoreData(STORE_KEYS.accounts, all.filter(a => a.id !== id));
}

// ==================== CATEGORIES ====================

export async function getAllCategories(): Promise<CategoryRow[]> {
  return getStoreData<CategoryRow>(STORE_KEYS.categories);
}

export async function addCategory(name: string, type: string, icon: string, color: string): Promise<CategoryRow> {
  const all = await getStoreData<CategoryRow>(STORE_KEYS.categories);
  const cat: CategoryRow = { id: uuidv4(), name, type, icon, color };
  all.push(cat);
  await setStoreData(STORE_KEYS.categories, all);
  return cat;
}

export async function deleteCategory(id: string): Promise<void> {
  const all = await getStoreData<CategoryRow>(STORE_KEYS.categories);
  await setStoreData(STORE_KEYS.categories, all.filter(c => c.id !== id));
}

// ==================== BUDGETS ====================

export async function getAllBudgets(): Promise<BudgetRow[]> {
  return getStoreData<BudgetRow>(STORE_KEYS.budgets);
}

export async function upsertBudget(amount: number, period: string, categoryId: string | null): Promise<BudgetRow> {
  const all = await getStoreData<BudgetRow>(STORE_KEYS.budgets);
  const id = categoryId ? `budget_${categoryId}` : 'budget_total';
  const idx = all.findIndex(b => b.id === id);
  const budget: BudgetRow = { id, amount, period, category_id: categoryId || '' };
  if (idx >= 0) {
    all[idx] = budget;
  } else {
    all.push(budget);
  }
  await setStoreData(STORE_KEYS.budgets, all);
  return budget;
}

export async function deleteBudget(id: string): Promise<void> {
  const all = await getStoreData<BudgetRow>(STORE_KEYS.budgets);
  await setStoreData(STORE_KEYS.budgets, all.filter(b => b.id !== id));
}
