import React, { useRef } from 'react';
import { View, StyleSheet, TouchableOpacity } from 'react-native';
import { Text } from 'react-native-paper';
import { Swipeable } from 'react-native-gesture-handler';
import { COLORS, SPACING, FONT_SIZE, BORDER_RADIUS } from '../constants/theme';
import { getCategoryById } from '../constants/categories';
import { REIMBURSEMENT_STATUS } from '../constants/theme';
import { formatCurrency } from '../utils/format';

interface TransactionItemProps {
  id: string;
  amount: number;
  type: 'income' | 'expense';
  categoryId: string;
  note: string;
  time: string;
  reimbursementStatus: string;
  onPress: () => void;
  onDelete?: () => void;
}

export const TransactionItem: React.FC<TransactionItemProps> = ({
  id,
  amount,
  type,
  categoryId,
  note,
  time,
  reimbursementStatus,
  onPress,
  onDelete,
}) => {
  const swipeableRef = useRef<Swipeable>(null);
  const category = getCategoryById(categoryId);
  const reimbursementInfo = REIMBURSEMENT_STATUS[reimbursementStatus as keyof typeof REIMBURSEMENT_STATUS];

  const renderRightActions = () => {
    if (!onDelete) return null;
    return (
      <TouchableOpacity
        style={styles.deleteButton}
        onPress={() => {
          swipeableRef.current?.close();
          onDelete();
        }}
        activeOpacity={0.8}
      >
        <Text style={styles.deleteIcon}>🗑</Text>
        <Text style={styles.deleteText}>删除</Text>
      </TouchableOpacity>
    );
  };

  return (
    <Swipeable
      ref={swipeableRef}
      renderRightActions={renderRightActions}
      rightThreshold={60}
      overshootRight={false}
      friction={2}
    >
      <TouchableOpacity
        style={styles.container}
        onPress={onPress}
        activeOpacity={0.7}
      >
        <View style={styles.iconContainer}>
          <Text style={styles.icon}>{category?.icon || '📦'}</Text>
        </View>
        <View style={styles.infoContainer}>
          {type === 'income' && categoryId === 'income_reimbursement' ? (
            <>
              <Text style={styles.categoryName}>{category?.name || '报销'}</Text>
              <Text style={styles.note} numberOfLines={1}>{note || '报销'}</Text>
            </>
          ) : (
            <>
              <Text style={styles.categoryName}>{category?.name || '未知'}</Text>
              <Text style={styles.note} numberOfLines={1}>{note || '无备注'}</Text>
            </>
          )}
        </View>
        <View style={styles.rightContainer}>
          <Text style={[styles.amount, type === 'income' ? styles.income : styles.expense]}>
            {type === 'income' ? '+' : '-'}{formatCurrency(amount)}
          </Text>
          <View style={styles.bottomRow}>
            <Text style={styles.time}>{time}</Text>
            {reimbursementStatus !== 'none' && reimbursementInfo && (
              <Text style={[styles.badgeText, { color: reimbursementInfo.color, marginLeft: SPACING.xs }]}>
                {reimbursementInfo.label}
              </Text>
            )}
          </View>
        </View>
      </TouchableOpacity>
    </Swipeable>
  );
};

const styles = StyleSheet.create({
  container: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingVertical: SPACING.md,
    paddingHorizontal: SPACING.lg,
    backgroundColor: '#FFFFFF',
  },
  iconContainer: {
    width: 40,
    height: 40,
    borderRadius: BORDER_RADIUS.lg,
    backgroundColor: COLORS.surface,
    justifyContent: 'center',
    alignItems: 'center',
  },
  icon: {
    fontSize: 20,
  },
  infoContainer: {
    flex: 1,
    marginLeft: SPACING.md,
  },
  categoryName: {
    fontSize: FONT_SIZE.md,
    fontWeight: '500',
    color: COLORS.text,
  },
  note: {
    fontSize: FONT_SIZE.sm,
    color: COLORS.textSecondary,
    marginTop: 2,
  },
  rightContainer: {
    alignItems: 'flex-end',
  },
  amount: {
    fontSize: FONT_SIZE.lg,
    fontWeight: '600',
  },
  income: {
    color: COLORS.income,
  },
  expense: {
    color: COLORS.expense,
  },
  bottomRow: {
    flexDirection: 'row',
    alignItems: 'center',
    marginTop: 2,
  },
  time: {
    fontSize: FONT_SIZE.xs,
    color: COLORS.textLight,
  },
  badge: {
    marginLeft: SPACING.xs,
    paddingHorizontal: 6,
    paddingVertical: 2,
    borderRadius: BORDER_RADIUS.sm,
  },
  badgeText: {
    fontSize: FONT_SIZE.xs,
    fontWeight: '500',
  },
  deleteButton: {
    width: 80,
    backgroundColor: '#FF4444',
    justifyContent: 'center',
    alignItems: 'center',
  },
  deleteIcon: {
    fontSize: 20,
  },
  deleteText: {
    color: '#FFFFFF',
    fontSize: FONT_SIZE.sm,
    fontWeight: '600',
    marginTop: 4,
  },
});
