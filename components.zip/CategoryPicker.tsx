import React from 'react';
import { View, StyleSheet, TouchableOpacity, ScrollView } from 'react-native';
import { Text } from 'react-native-paper';
import { COLORS, SPACING, FONT_SIZE, BORDER_RADIUS } from '../constants/theme';
import { Category } from '../constants/categories';

interface CategoryPickerProps {
  categories: Category[];
  selectedId: string;
  onSelect: (id: string) => void;
}

export const CategoryPicker: React.FC<CategoryPickerProps> = ({
  categories,
  selectedId,
  onSelect,
}) => {
  return (
    <ScrollView style={styles.container} contentContainerStyle={styles.content} nestedScrollEnabled={true}>
      {categories.map((category) => (
        <TouchableOpacity
          key={category.id}
          style={[
            styles.item,
            selectedId === category.id && styles.itemSelected,
          ]}
          onPress={() => onSelect(category.id)}
        >
          <View style={[styles.iconContainer, { backgroundColor: category.color + '20' }]}>
            <Text style={styles.icon}>{category.icon}</Text>
          </View>
          <Text
            style={[
              styles.name,
              selectedId === category.id && styles.nameSelected,
            ]}
            numberOfLines={1}
          >
            {category.name}
          </Text>
        </TouchableOpacity>
      ))}
    </ScrollView>
  );
};

const styles = StyleSheet.create({
  container: {
    maxHeight: 200,
  },
  content: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    padding: SPACING.sm,
  },
  item: {
    width: '20%',
    alignItems: 'center',
    paddingVertical: SPACING.sm,
    borderRadius: BORDER_RADIUS.md,
  },
  itemSelected: {
    backgroundColor: COLORS.primaryLight,
  },
  iconContainer: {
    width: 44,
    height: 44,
    borderRadius: BORDER_RADIUS.lg,
    justifyContent: 'center',
    alignItems: 'center',
  },
  icon: {
    fontSize: 22,
  },
  name: {
    fontSize: FONT_SIZE.xs,
    color: COLORS.textSecondary,
    marginTop: 4,
  },
  nameSelected: {
    color: COLORS.primary,
    fontWeight: '600',
  },
});
