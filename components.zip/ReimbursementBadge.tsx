import React from 'react';
import { View, StyleSheet, Text } from 'react-native';
import { COLORS, BORDER_RADIUS, FONT_SIZE } from '../constants/theme';
import { REIMBURSEMENT_STATUS } from '../constants/theme';

interface ReimbursementBadgeProps {
  status: string;
}

export const ReimbursementBadge: React.FC<ReimbursementBadgeProps> = ({ status }) => {
  const info = REIMBURSEMENT_STATUS[status as keyof typeof REIMBURSEMENT_STATUS];
  if (!info || status === 'none') return null;

  return (
    <View style={[styles.badge, { backgroundColor: info.color + '20' }]}>
      <Text style={[styles.text, { color: info.color }]}>{info.label}</Text>
    </View>
  );
};

const styles = StyleSheet.create({
  badge: {
    paddingHorizontal: 8,
    paddingVertical: 3,
    borderRadius: BORDER_RADIUS.sm,
    alignSelf: 'flex-start',
  },
  text: {
    fontSize: FONT_SIZE.xs,
    fontWeight: '600',
  },
});
