import React from 'react';
import { View, StyleSheet, TouchableOpacity } from 'react-native';
import { Text } from 'react-native-paper';
import { COLORS, SPACING, FONT_SIZE, BORDER_RADIUS } from '../constants/theme';
import { getMonthName, formatCurrencyShort } from '../utils/format';

interface MonthlyCardProps {
  month: string;
  income: number;
  expense: number;
  onPress: () => void;
}

export const MonthlyCard: React.FC<MonthlyCardProps> = ({
  month,
  income,
  expense,
  onPress,
}) => {
  const net = income - expense;
  const hasData = income > 0 || expense > 0;

  return (
    <TouchableOpacity 
      style={[styles.container, !hasData && styles.containerEmpty]} 
      onPress={onPress}
    >
      <View style={styles.header}>
        <Text style={styles.month}>{getMonthName(month)}</Text>
        {hasData && <Text style={styles.arrow}>›</Text>}
      </View>
      {hasData ? (
        <View style={styles.summary}>
          <View style={styles.row}>
            <Text style={styles.label}>收入</Text>
            <Text style={styles.income}>{formatCurrencyShort(income)}</Text>
          </View>
          <View style={styles.row}>
            <Text style={styles.label}>支出</Text>
            <Text style={styles.expense}>{formatCurrencyShort(expense)}</Text>
          </View>
          <View style={styles.divider} />
          <View style={styles.row}>
            <Text style={styles.label}>结余</Text>
            <Text style={[styles.net, net >= 0 ? styles.netPositive : styles.netNegative]}>
              {formatCurrencyShort(net)}
            </Text>
          </View>
        </View>
      ) : (
        <Text style={styles.noData}>暂无数据</Text>
      )}
    </TouchableOpacity>
  );
};

const styles = StyleSheet.create({
  container: {
    backgroundColor: '#FFFFFF',
    borderRadius: BORDER_RADIUS.lg,
    padding: SPACING.lg,
    marginBottom: SPACING.md,
    borderWidth: 1,
    borderColor: COLORS.border,
  },
  containerEmpty: {
    opacity: 0.6,
  },
  header: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: SPACING.sm,
  },
  month: {
    fontSize: FONT_SIZE.lg,
    fontWeight: '700',
    color: COLORS.primary,
  },
  arrow: {
    fontSize: FONT_SIZE.xl,
    color: COLORS.textLight,
  },
  summary: {
    gap: 4,
  },
  row: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
  },
  label: {
    fontSize: FONT_SIZE.sm,
    color: COLORS.textSecondary,
  },
  income: {
    fontSize: FONT_SIZE.md,
    color: COLORS.income,
    fontWeight: '500',
  },
  expense: {
    fontSize: FONT_SIZE.md,
    color: COLORS.expense,
    fontWeight: '500',
  },
  divider: {
    height: 1,
    backgroundColor: COLORS.border,
    marginVertical: 4,
  },
  net: {
    fontSize: FONT_SIZE.md,
    fontWeight: '600',
  },
  netPositive: {
    color: COLORS.income,
  },
  netNegative: {
    color: COLORS.expense,
  },
  noData: {
    fontSize: FONT_SIZE.sm,
    color: COLORS.textLight,
    textAlign: 'center',
    paddingVertical: SPACING.sm,
  },
});
