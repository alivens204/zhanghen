import React from 'react';
import { View, StyleSheet, TouchableOpacity, ScrollView } from 'react-native';
import { Text } from 'react-native-paper';
import { COLORS, SPACING, FONT_SIZE, BORDER_RADIUS } from '../constants/theme';
import { AccountRow } from '../database/schema';

interface AccountPickerProps {
  accounts: AccountRow[];
  selectedId: string;
  onSelect: (id: string) => void;
}

export const AccountPicker: React.FC<AccountPickerProps> = ({
  accounts,
  selectedId,
  onSelect,
}) => {
  return (
    <ScrollView 
      horizontal 
      showsHorizontalScrollIndicator={false}
      contentContainerStyle={styles.container}
    >
      {accounts.map((account) => (
        <TouchableOpacity
          key={account.id}
          style={[
            styles.item,
            selectedId === account.id && styles.itemSelected,
          ]}
          onPress={() => onSelect(account.id)}
        >
          <Text style={styles.icon}>{account.icon}</Text>
          <Text
            style={[
              styles.name,
              selectedId === account.id && styles.nameSelected,
            ]}
          >
            {account.name}
          </Text>
        </TouchableOpacity>
      ))}
    </ScrollView>
  );
};

const styles = StyleSheet.create({
  container: {
    paddingVertical: SPACING.sm,
    gap: SPACING.sm,
  },
  item: {
    alignItems: 'center',
    paddingVertical: SPACING.sm,
    paddingHorizontal: SPACING.md,
    borderRadius: BORDER_RADIUS.md,
    backgroundColor: COLORS.surface,
    minWidth: 70,
  },
  itemSelected: {
    backgroundColor: COLORS.primaryLight,
    borderWidth: 1,
    borderColor: COLORS.primary,
  },
  icon: {
    fontSize: 20,
    marginBottom: 4,
  },
  name: {
    fontSize: FONT_SIZE.xs,
    color: COLORS.textSecondary,
  },
  nameSelected: {
    color: COLORS.primary,
    fontWeight: '600',
  },
});
