import React from 'react';
import { View, StyleSheet, TouchableOpacity } from 'react-native';
import { Text } from 'react-native-paper';
import { COLORS, SPACING, FONT_SIZE, BORDER_RADIUS } from '../constants/theme';
import { formatDateChinese, getWeekday, formatCurrencyShort } from '../utils/format';

interface DailySummaryProps {
  date: string;
  income: number;
  expense: number;
  onPress: () => void;
}

export const DailySummary: React.FC<DailySummaryProps> = ({
  date,
  income,
  expense,
  onPress,
}) => {
  const net = income - expense;

  return (
    <TouchableOpacity style={styles.container} onPress={onPress}>
      <View style={styles.dateContainer}>
        <Text style={styles.date}>{formatDateChinese(date)}</Text>
        <Text style={styles.weekday}>{getWeekday(date)}</Text>
      </View>
      <View style={styles.amountsContainer}>
        {income > 0 && (
          <Text style={styles.income}>收 {formatCurrencyShort(income)}</Text>
        )}
        {expense > 0 && (
          <Text style={styles.expense}>支 {formatCurrencyShort(expense)}</Text>
        )}
        <Text style={[styles.net, net >= 0 ? styles.netPositive : styles.netNegative]}>
          净 {formatCurrencyShort(net)}
        </Text>
      </View>
    </TouchableOpacity>
  );
};

const styles = StyleSheet.create({
  container: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    paddingVertical: SPACING.md,
    paddingHorizontal: SPACING.lg,
    backgroundColor: '#FFFFFF',
    borderBottomWidth: 1,
    borderBottomColor: COLORS.border,
  },
  dateContainer: {
    alignItems: 'center',
    width: 50,
  },
  date: {
    fontSize: FONT_SIZE.lg,
    fontWeight: '600',
    color: COLORS.text,
  },
  weekday: {
    fontSize: FONT_SIZE.xs,
    color: COLORS.textLight,
    marginTop: 2,
  },
  amountsContainer: {
    flex: 1,
    alignItems: 'flex-end',
  },
  income: {
    fontSize: FONT_SIZE.sm,
    color: COLORS.income,
    marginBottom: 2,
  },
  expense: {
    fontSize: FONT_SIZE.sm,
    color: COLORS.expense,
    marginBottom: 2,
  },
  net: {
    fontSize: FONT_SIZE.md,
    fontWeight: '600',
  },
  netPositive: {
    color: COLORS.income,
  },
  netNegative: {
    color: COLORS.expense,
  },
});
