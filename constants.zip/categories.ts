export interface Category {
  id: string;
  name: string;
  type: 'income' | 'expense';
  icon: string;
  color: string;
}

export const EXPENSE_CATEGORIES: Category[] = [
  { id: 'expense_food', name: '餐饮', type: 'expense', icon: '🍜', color: '#FF6B6B' },
  { id: 'expense_transport', name: '交通', type: 'expense', icon: '🚗', color: '#4ECDC4' },
  { id: 'expense_daily', name: '日用', type: 'expense', icon: '🛒', color: '#45B7D1' },
  { id: 'expense_clothing', name: '服饰', type: 'expense', icon: '👔', color: '#96CEB4' },
  { id: 'expense_entertainment', name: '娱乐', type: 'expense', icon: '🎮', color: '#FFEAA7' },
  { id: 'expense_housing', name: '住房', type: 'expense', icon: '🏠', color: '#DDA0DD' },
  { id: 'expense_medical', name: '医疗', type: 'expense', icon: '💊', color: '#98D8C8' },
  { id: 'expense_education', name: '教育', type: 'expense', icon: '📚', color: '#F7DC6F' },
  { id: 'expense_communication', name: '通讯', type: 'expense', icon: '📱', color: '#BB8FCE' },
  { id: 'expense_finance', name: '金融', type: 'expense', icon: '💳', color: '#85C1E9' },
  { id: 'expense_other', name: '其他支出', type: 'expense', icon: '📦', color: '#AEB6BF' },
];

export const INCOME_CATEGORIES: Category[] = [
  { id: 'income_salary', name: '工资', type: 'income', icon: '💼', color: '#2ECC71' },
  { id: 'income_bonus', name: '奖金', type: 'income', icon: '🎁', color: '#E74C3C' },
  { id: 'income_investment', name: '投资', type: 'income', icon: '📈', color: '#3498DB' },
  { id: 'income_parttime', name: '兼职', type: 'income', icon: '💻', color: '#9B59B6' },
  { id: 'income_redpacket', name: '红包', type: 'income', icon: '🧧', color: '#E74C3C' },
  { id: 'income_reimbursement', name: '报销', type: 'income', icon: '💰', color: '#F39C12' },
  { id: 'income_other', name: '其他收入', type: 'income', icon: '💰', color: '#27AE60' },
];

export const ALL_CATEGORIES = [...EXPENSE_CATEGORIES, ...INCOME_CATEGORIES];

export const getCategoryById = (id: string): Category | undefined => {
  return ALL_CATEGORIES.find(c => c.id === id);
};
