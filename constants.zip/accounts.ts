export interface Account {
  id: string;
  name: string;
  type: 'cash' | 'bank' | 'credit' | 'alipay' | 'wechat' | 'other';
  balance: number;
  icon: string;
  color: string;
}

export const DEFAULT_ACCOUNTS: Account[] = [
  { id: 'account_cash', name: '现金', type: 'cash', balance: 0, icon: '💵', color: '#27AE60' },
  { id: 'account_bank', name: '银行卡', type: 'bank', balance: 0, icon: '🏦', color: '#3498DB' },
  { id: 'account_credit', name: '信用卡', type: 'credit', balance: 0, icon: '💳', color: '#E74C3C' },
  { id: 'account_alipay', name: '支付宝', type: 'alipay', balance: 0, icon: '📱', color: '#1677FF' },
  { id: 'account_wechat', name: '微信', type: 'wechat', balance: 0, icon: '💬', color: '#07C160' },
];

export const getAccountById = (id: string): Account | undefined => {
  return DEFAULT_ACCOUNTS.find(a => a.id === id);
};
