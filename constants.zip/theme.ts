export const COLORS = {
  primary: '#4A90D9',
  primaryLight: '#E3F2FD',
  background: '#FFFFFF',
  surface: '#F8F9FA',
  text: '#333333',
  textSecondary: '#666666',
  textLight: '#999999',
  border: '#E8E8E8',
  
  income: '#4CAF50',
  incomeLight: '#E8F5E9',
  expense: '#F44336',
  expenseLight: '#FFEBEE',
  pending: '#FF9800',
  pendingLight: '#FFF3E0',
  success: '#4CAF50',
  rejected: '#9E9E9E',
};

export const SPACING = {
  xs: 4,
  sm: 8,
  md: 12,
  lg: 16,
  xl: 24,
  xxl: 32,
};

export const FONT_SIZE = {
  xs: 10,
  sm: 12,
  md: 14,
  lg: 16,
  xl: 18,
  xxl: 22,
  title: 28,
  header: 34,
};

export const BORDER_RADIUS = {
  sm: 4,
  md: 8,
  lg: 12,
  xl: 16,
  full: 999,
};

export const REIMBURSEMENT_STATUS = {
  none: { label: '', color: 'transparent' },
  pending: { label: '待报销', color: COLORS.pending },
  reimbursing: { label: '报销中', color: COLORS.primary },
  reimbursed: { label: '全额报销', color: COLORS.success },
  partial: { label: '部分报销', color: '#FF9800' },
  rejected: { label: '已驳回', color: COLORS.rejected },
} as const;
