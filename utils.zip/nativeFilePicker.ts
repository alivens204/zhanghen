import { NativeModules, Platform } from 'react-native';

const { NativeFilePicker } = NativeModules;

export interface PickFileResult {
  base64: string;
  fileName: string;
  uri: string;
}

/**
 * 使用自定义原生模块选择文件并读取内容
 * 完全在原生层完成：文件选择 + 文件读取 + base64编码
 * 不依赖 JS 层的 fetch/FileSystem（这些无法处理 content:// URI）
 */
export async function pickAndReadFile(): Promise<PickFileResult> {
  if (Platform.OS !== 'android') {
    throw new Error('此功能仅支持 Android');
  }

  if (!NativeFilePicker) {
    throw new Error('NativeFilePicker 模块未加载，请重新构建应用');
  }

  try {
    const result = await NativeFilePicker.pickAndReadFile();
    console.log('NativeFilePicker result:', {
      fileName: result.fileName,
      base64Length: result.base64?.length || 0,
      uri: result.uri,
    });
    return result;
  } catch (error: any) {
    // 转换原生错误为 JS 错误
    const message = error.message || error.toString() || '未知错误';
    if (message.includes('CANCELLED') || message.includes('取消')) {
      throw new Error('CANCELLED');
    }
    throw new Error(message);
  }
}
