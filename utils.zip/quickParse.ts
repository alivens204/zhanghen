/**
 * 快捷输入解析引擎（完整版）
 * 支持格式：分类名 金额，如 "面 12"、"咖啡 25 打车 15"
 * 300+ 关键词覆盖日常生活场景
 */

// ==================== 收入关键词（优先识别）====================
const INCOME_KEYWORDS: Record<string, string> = {
  // 工资
  '工资': 'income_salary', '薪资': 'income_salary', '薪水': 'income_salary',
  '月薪': 'income_salary', '底薪': 'income_salary', '时薪': 'income_salary',
  '发工资': 'income_salary', '开工资': 'income_salary',

  // 奖金
  '奖金': 'income_bonus', '年终奖': 'income_bonus', '提成': 'income_bonus',
  '绩效奖': 'income_bonus', '全勤奖': 'income_bonus', '季度奖': 'income_bonus',
  '项目奖': 'income_bonus', '提成款': 'income_bonus',

  // 投资
  '投资': 'income_investment', '理财收益': 'income_investment', '分红': 'income_investment',
  '股息': 'income_investment', '利息': 'income_investment', '回报': 'income_investment',
  '收益': 'income_investment', '红利': 'income_investment', '债券': 'income_investment',
  '基金收益': 'income_investment',

  // 兼职
  '兼职': 'income_parttime', '副业': 'income_parttime', '外快': 'income_parttime',
  '兼职费': 'income_parttime', '零工': 'income_parttime', '接单': 'income_parttime',
  '自由职业': 'income_parttime', '稿费': 'income_parttime',

  // 红包
  '红包': 'income_redpacket', '收红包': 'income_redpacket', '压岁钱': 'income_redpacket',
  '礼金': 'income_redpacket', '随礼收入': 'income_redpacket', '份子钱收入': 'income_redpacket',

  // 报销
  '报销': 'income_reimbursement', '报销款': 'income_reimbursement', '退费': 'income_reimbursement',
  '返现': 'income_reimbursement', '报销到账': 'income_reimbursement',

  // 其他收入
  '其他收入': 'income_other', '收入': 'income_other', '中奖': 'income_other',
  '退款': 'income_other', '赔偿': 'income_other', '返利': 'income_other',
  '佣金': 'income_other', '提现金': 'income_other',
};

// ==================== 支出关键词 ====================

// 🍜 餐饮
const FOOD_KEYWORDS: Record<string, string> = {
  // 主食
  '面': 'expense_food', '面条': 'expense_food', '炒面': 'expense_food', '拉面': 'expense_food',
  '刀削面': 'expense_food', '手擀面': 'expense_food', '担担面': 'expense_food', '油泼面': 'expense_food',
  '热干面': 'expense_food', '重庆小面': 'expense_food', '牛肉面': 'expense_food', '炸酱面': 'expense_food',
  '面皮': 'expense_food', '凉面': 'expense_food', '拌面': 'expense_food', '汤面': 'expense_food',
  '泡面': 'expense_food', '方便面': 'expense_food', '挂面': 'expense_food', '米粉': 'expense_food',
  '米线': 'expense_food', '螺蛳粉': 'expense_food', '酸辣粉': 'expense_food', '过桥米线': 'expense_food',
  '河粉': 'expense_food', '肠粉': 'expense_food',  '炒河粉': 'expense_food', '炒粉': 'expense_food', '炒米粉': 'expense_food',
  '炒粿条': 'expense_food', '粿条': 'expense_food', '凉皮': 'expense_food', '炒细面': 'expense_food', '炒方便面': 'expense_food',

  // 米饭类
  '饭': 'expense_food', '米饭': 'expense_food', '炒饭': 'expense_food', '盖饭': 'expense_food',
  '盖浇饭': 'expense_food', '蛋炒饭': 'expense_food', '扬州炒饭': 'expense_food', '煲仔饭': 'expense_food',
  '黄焖鸡米饭': 'expense_food', '快餐饭': 'expense_food',

  // 面食
  '包子': 'expense_food', '馒头': 'expense_food', '花卷': 'expense_food', '烧饼': 'expense_food',
  '煎饼': 'expense_food', '煎饼果子': 'expense_food', '手抓饼': 'expense_food', '葱油饼': 'expense_food',
  '饼': 'expense_food', '馅饼': 'expense_food', '肉夹馍': 'expense_food', '白吉饼': 'expense_food',
  '锅盔': 'expense_food', '馕': 'expense_food', '馕饼': 'expense_food', '烤饼': 'expense_food',

  // 饺子/馄饨
  '饺子': 'expense_food', '水饺': 'expense_food', '煎饺': 'expense_food', '蒸饺': 'expense_food',
  '馄饨': 'expense_food', '抄手': 'expense_food', '云吞': 'expense_food',

  // 粥/汤
  '粥': 'expense_food', '稀饭': 'expense_food', '豆浆': 'expense_food', '豆腐脑': 'expense_food',
  '胡辣汤': 'expense_food', '汤': 'expense_food',

  // 小吃
  '串串': 'expense_food', '烧烤': 'expense_food', '烤串': 'expense_food', '铁板烧': 'expense_food',
  '炸鸡': 'expense_food', '鸡排': 'expense_food', '鸡腿': 'expense_food', '鸡翅': 'expense_food',
  '薯条': 'expense_food', '汉堡': 'expense_food', '热狗': 'expense_food', '三明治': 'expense_food',
  '披萨': 'expense_food', '寿司': 'expense_food', '刺身': 'expense_food', '日料': 'expense_food',
  '韩餐': 'expense_food', '韩式拌饭': 'expense_food', '烤肉': 'expense_food', '火锅': 'expense_food',
  '麻辣烫': 'expense_food', '麻辣香锅': 'expense_food', '冒菜': 'expense_food', '关东煮': 'expense_food',
  '臭豆腐': 'expense_food', '炸串': 'expense_food', '卤味': 'expense_food', '卤肉': 'expense_food',
  '鸭脖': 'expense_food', '鸭架': 'expense_food', '鸭血粉丝': 'expense_food', '烧鹅': 'expense_food',
  '叉烧': 'expense_food', '烤鸭': 'expense_food',

  // 甜品/饮品
  '奶茶': 'expense_food', '咖啡': 'expense_food', '拿铁': 'expense_food', '美式': 'expense_food',
  '卡布奇诺': 'expense_food', '摩卡': 'expense_food', '果汁': 'expense_food', '柠檬水': 'expense_food',
  '饮料': 'expense_food', '可乐': 'expense_food', '雪碧': 'expense_food', '苏打水': 'expense_food',
  '茶': 'expense_food', '茶饮': 'expense_food', '奶茶店': 'expense_food', '瑞幸': 'expense_food',
  '星巴克': 'expense_food', '蜜雪冰城': 'expense_food', '喜茶': 'expense_food', '奈雪': 'expense_food',
  '蛋糕': 'expense_food', '面包': 'expense_food', '甜品': 'expense_food', '甜点': 'expense_food',
  '冰淇淋': 'expense_food', '雪糕': 'expense_food', '酸奶': 'expense_food', '牛奶': 'expense_food',
  '布丁': 'expense_food', '慕斯': 'expense_food', '蛋挞': 'expense_food', '泡芙': 'expense_food',
  '甜甜圈': 'expense_food', '华夫饼': 'expense_food', '松饼': 'expense_food',

  // 零食
  '零食': 'expense_food', '小吃': 'expense_food', '膨化食品': 'expense_food', '薯片': 'expense_food',
  '坚果': 'expense_food', '瓜子': 'expense_food', '花生': 'expense_food', '糖果': 'expense_food',
  '巧克力': 'expense_food', '饼干': 'expense_food', '辣条': 'expense_food', '肉干': 'expense_food',
  '牛肉干': 'expense_food', '果脯': 'expense_food', '蜜饯': 'expense_food',

  // 水果
  '水果': 'expense_food', '苹果': 'expense_food', '香蕉': 'expense_food', '橙子': 'expense_food',
  '葡萄': 'expense_food', '西瓜': 'expense_food', '草莓': 'expense_food', '蓝莓': 'expense_food',
  '芒果': 'expense_food', '荔枝': 'expense_food', '樱桃': 'expense_food', '桃': 'expense_food',
  '梨': 'expense_food', '柚子': 'expense_food', '猕猴桃': 'expense_food', '榴莲': 'expense_food',
  '山竹': 'expense_food', '火龙果': 'expense_food', '菠萝': 'expense_food', '车厘子': 'expense_food',
  '水果捞': 'expense_food', '果切': 'expense_food', '鲜果': 'expense_food',

  // 餐饮场景
  '早餐': 'expense_food', '午餐': 'expense_food', '晚餐': 'expense_food', '宵夜': 'expense_food',
  '吃饭': 'expense_food', '外卖': 'expense_food', '点餐': 'expense_food', '订餐': 'expense_food',
  '食堂': 'expense_food', '快餐': 'expense_food', '小吃街': 'expense_food', '夜市': 'expense_food',
  '下馆子': 'expense_food', '聚餐': 'expense_food', '请客': 'expense_food', '团建餐': 'expense_food',
  '自助餐': 'expense_food', '自助': 'expense_food', '便当': 'expense_food', '盒饭': 'expense_food',
  '麻辣拌': 'expense_food',

  // 食材
  '买菜': 'expense_food', '菜': 'expense_food', '肉': 'expense_food', '鸡蛋': 'expense_food',
  '豆腐': 'expense_food', '蔬菜': 'expense_food', '海鲜': 'expense_food', '鱼': 'expense_food',
  '虾': 'expense_food', '牛排': 'expense_food', '五花肉': 'expense_food', '排骨': 'expense_food',
  '鸡胸肉': 'expense_food', '培根': 'expense_food', '火腿': 'expense_food', '香肠': 'expense_food',
  '超市': 'expense_food', '菜市场': 'expense_food', '生鲜': 'expense_food',
  '调味品': 'expense_food', '酱油': 'expense_food', '醋': 'expense_food', '盐': 'expense_food',
  '米': 'expense_food', '油': 'expense_food', '面粉': 'expense_food',
};

// 🚗 交通
const TRANSPORT_KEYWORDS: Record<string, string> = {
  '打车': 'expense_transport', '出租车': 'expense_transport', '滴滴': 'expense_transport',
  '快车': 'expense_transport', '专车': 'expense_transport', '顺风车': 'expense_transport',
  '拼车': 'expense_transport', '代驾': 'expense_transport', '首汽': 'expense_transport',
  '高德打车': 'expense_transport', 'T3出行': 'expense_transport',
  '公交': 'expense_transport', '公交车': 'expense_transport', '地铁': 'expense_transport',
  '轻轨': 'expense_transport', '磁悬浮': 'expense_transport', '有轨电车': 'expense_transport',
  '高铁': 'expense_transport', '动车': 'expense_transport', '火车': 'expense_transport',
  '卧铺': 'expense_transport', '硬座': 'expense_transport', '软座': 'expense_transport',
  '飞机': 'expense_transport', '机票': 'expense_transport', '航班': 'expense_transport',
  '机场大巴': 'expense_transport', '经济舱': 'expense_transport', '商务舱': 'expense_transport',
  '船票': 'expense_transport', '轮渡': 'expense_transport',
  '加油': 'expense_transport', '油费': 'expense_transport', '汽油': 'expense_transport', '柴油': 'expense_transport',
  '充电费': 'expense_transport', '充电': 'expense_transport', // 电车充电
  '停车': 'expense_transport', '停车费': 'expense_transport', '车位': 'expense_transport',
  '过路费': 'expense_transport', '高速费': 'expense_transport', '高速通行费': 'expense_transport',
  'ETC': 'expense_transport', '桥梁费': 'expense_transport',
  '骑行': 'expense_transport', '共享单车': 'expense_transport', '哈啰': 'expense_transport',
  '美团单车': 'expense_transport', '青桔': 'expense_transport', '共享单车费': 'expense_transport',
  '电动车': 'expense_transport', '摩托车': 'expense_transport', '骑行费': 'expense_transport',
  '车险': 'expense_transport', '交强险': 'expense_transport', '车辆保险': 'expense_transport',
  '保养': 'expense_transport', '修车': 'expense_transport', '洗车': 'expense_transport',
  '年检': 'expense_transport', '违章': 'expense_transport', '罚单': 'expense_transport',
  '驾照': 'expense_transport', '学车': 'expense_transport', '驾校': 'expense_transport',
  '车船税': 'expense_transport', '停车月卡': 'expense_transport',
};

// 🛒 日用
const DAILY_KEYWORDS: Record<string, string> = {
  '纸巾': 'expense_daily', '卫生纸': 'expense_daily', '抽纸': 'expense_daily',
  '湿巾': 'expense_daily', '厨房纸': 'expense_daily',
  '洗衣液': 'expense_daily', '洗衣粉': 'expense_daily', '洗衣凝珠': 'expense_daily',
  '柔顺剂': 'expense_daily', '消毒液': 'expense_daily',
  '牙膏': 'expense_daily', '牙刷': 'expense_daily', '牙线': 'expense_daily',
  '漱口水': 'expense_daily',
  '洗发水': 'expense_daily', '沐浴露': 'expense_daily', '香皂': 'expense_daily',
  '护发素': 'expense_daily', '发膜': 'expense_daily',
  '毛巾': 'expense_daily', '浴巾': 'expense_daily', '牙杯': 'expense_daily',
  '拖把': 'expense_daily', '扫帚': 'expense_daily', '抹布': 'expense_daily',
  '扫把': 'expense_daily', '簸箕': 'expense_daily', '拖布': 'expense_daily',
  '垃圾桶': 'expense_daily', '垃圾袋': 'expense_daily', '保鲜膜': 'expense_daily',
  '保鲜袋': 'expense_daily', '锡纸': 'expense_daily', '铝箔纸': 'expense_daily',
  '洗洁精': 'expense_daily', '洗碗液': 'expense_daily', '海绵': 'expense_daily',
  '百洁布': 'expense_daily', '钢丝球': 'expense_daily',
  '电池': 'expense_daily', '充电线': 'expense_daily', '数据线': 'expense_daily',
  '插排': 'expense_daily', '转换器': 'expense_daily', '收纳盒': 'expense_daily',
  '衣架': 'expense_daily', '晾衣架': 'expense_daily', '夹子': 'expense_daily',
  '指甲剪': 'expense_daily', '剪刀': 'expense_daily', '针线': 'expense_daily',
  '蜡烛': 'expense_daily', '打火机': 'expense_daily',
  '日用品': 'expense_daily', '生活用品': 'expense_daily', '家居': 'expense_daily',
  '快递': 'expense_daily', '寄件': 'expense_daily', '邮寄': 'expense_daily',
  '理发': 'expense_daily', '剪发': 'expense_daily', '美发': 'expense_daily',
  '理发店': 'expense_daily', '发型': 'expense_daily',
  '洗衣': 'expense_daily', '干洗': 'expense_daily', '洗衣店': 'expense_daily',
  '清洁': 'expense_daily', '保洁': 'expense_daily', '家政': 'expense_daily',
  '洗护': 'expense_daily', '护肤品': 'expense_daily', '化妆品': 'expense_daily',
  '防晒': 'expense_daily', '面膜': 'expense_daily', '卸妆': 'expense_daily',
  '口红': 'expense_daily', '粉底': 'expense_daily', '香水': 'expense_daily',
};

// 👔 服饰
const CLOTHING_KEYWORDS: Record<string, string> = {
  '衣服': 'expense_clothing', '上衣': 'expense_clothing', '外套': 'expense_clothing',
  '夹克': 'expense_clothing', '卫衣': 'expense_clothing', '毛衣': 'expense_clothing',
  '衬衫': 'expense_clothing', 'T恤': 'expense_clothing', '短袖': 'expense_clothing',
  '长袖': 'expense_clothing', '羽绒服': 'expense_clothing', '棉服': 'expense_clothing',
  '风衣': 'expense_clothing', '大衣': 'expense_clothing', '皮衣': 'expense_clothing',
  '马甲': 'expense_clothing', '背心': 'expense_clothing',
  '裤子': 'expense_clothing', '牛仔裤': 'expense_clothing', '休闲裤': 'expense_clothing',
  '西裤': 'expense_clothing', '短裤': 'expense_clothing', '运动裤': 'expense_clothing',
  '阔腿裤': 'expense_clothing', '打底裤': 'expense_clothing', '工装裤': 'expense_clothing',
  '裙': 'expense_clothing', '裙子': 'expense_clothing', '连衣裙': 'expense_clothing',
  '半身裙': 'expense_clothing', '短裙': 'expense_clothing', '长裙': 'expense_clothing',
  '鞋': 'expense_clothing', '鞋子': 'expense_clothing', '运动鞋': 'expense_clothing',
  '跑鞋': 'expense_clothing', '板鞋': 'expense_clothing', '帆布鞋': 'expense_clothing',
  '皮鞋': 'expense_clothing', '高跟鞋': 'expense_clothing', '凉鞋': 'expense_clothing',
  '拖鞋': 'expense_clothing', '靴子': 'expense_clothing', '雪地靴': 'expense_clothing',
  '休闲鞋': 'expense_clothing', '篮球鞋': 'expense_clothing',
  '袜子': 'expense_clothing', '棉袜': 'expense_clothing',
  '帽子': 'expense_clothing', '棒球帽': 'expense_clothing', '渔夫帽': 'expense_clothing',
  '围巾': 'expense_clothing', '手套': 'expense_clothing', '耳罩': 'expense_clothing',
  '内裤': 'expense_clothing', '内衣': 'expense_clothing', '文胸': 'expense_clothing',
  '睡衣': 'expense_clothing', '家居服': 'expense_clothing',
  '皮带': 'expense_clothing', '领带': 'expense_clothing', '袖扣': 'expense_clothing',
  '配饰': 'expense_clothing', '首饰': 'expense_clothing', '项链': 'expense_clothing',
  '手链': 'expense_clothing', '耳环': 'expense_clothing', '戒指': 'expense_clothing',
  '手表': 'expense_clothing', '眼镜': 'expense_clothing', '墨镜': 'expense_clothing',
  '背包': 'expense_clothing', '手提包': 'expense_clothing', '钱包': 'expense_clothing',
  '斜挎包': 'expense_clothing', '行李箱': 'expense_clothing',
  '服装': 'expense_clothing', '穿搭': 'expense_clothing', '买衣服': 'expense_clothing',
};

// 🎮 娱乐
const ENTERTAINMENT_KEYWORDS: Record<string, string> = {
  '电影': 'expense_entertainment', '电影票': 'expense_entertainment', '看電影': 'expense_entertainment',
  '游戏': 'expense_entertainment', '充值游戏': 'expense_entertainment', '游戏皮肤': 'expense_entertainment',
  '旅游': 'expense_entertainment', '旅行': 'expense_entertainment', '出游': 'expense_entertainment',
  '景区': 'expense_entertainment', '景点': 'expense_entertainment', '门票': 'expense_entertainment',
  '唱歌': 'expense_entertainment', 'KTV': 'expense_entertainment', '卡拉OK': 'expense_entertainment',
  '演出': 'expense_entertainment', '演唱会': 'expense_entertainment', '音乐会': 'expense_entertainment',
  '话剧': 'expense_entertainment', '相声': 'expense_entertainment', '脱口秀': 'expense_entertainment',
  '音乐节': 'expense_entertainment', '展览': 'expense_entertainment', '博物馆': 'expense_entertainment',
  '会员': 'expense_entertainment', '视频会员': 'expense_entertainment', '音乐会员': 'expense_entertainment',
  '爱奇艺': 'expense_entertainment', '优酷': 'expense_entertainment', '腾讯视频': 'expense_entertainment',
  'B站': 'expense_entertainment', 'bilibili': 'expense_entertainment', '网易云音乐': 'expense_entertainment',
  'QQ音乐': 'expense_entertainment', '酷狗': 'expense_entertainment', 'Spotify': 'expense_entertainment',
  '健身房': 'expense_entertainment', '健身': 'expense_entertainment', '瑜伽': 'expense_entertainment',
  '游泳': 'expense_entertainment', '打球': 'expense_entertainment', '篮球': 'expense_entertainment',
  '足球': 'expense_entertainment', '羽毛球': 'expense_entertainment', '乒乓球': 'expense_entertainment',
  '保龄球': 'expense_entertainment', '射箭': 'expense_entertainment', '攀岩': 'expense_entertainment',
  '密室逃脱': 'expense_entertainment', '剧本杀': 'expense_entertainment', '桌游': 'expense_entertainment',
  '电玩': 'expense_entertainment', '游乐场': 'expense_entertainment', 'KTV包厢': 'expense_entertainment',
  '足浴': 'expense_entertainment', '按摩': 'expense_entertainment', 'SPA': 'expense_entertainment',
  '温泉': 'expense_entertainment', '钓鱼': 'expense_entertainment', '露营': 'expense_entertainment',
};

// 🏠 住房
const HOUSING_KEYWORDS: Record<string, string> = {
  '房租': 'expense_housing', '月租': 'expense_housing', '租金': 'expense_housing',
  '水费': 'expense_housing', '电费': 'expense_housing', '燃气': 'expense_housing',
  '燃气费': 'expense_housing', '天然气': 'expense_housing', '煤气': 'expense_housing',
  '物业': 'expense_housing', '物业费': 'expense_housing', '管理费': 'expense_housing',
  '网费': 'expense_housing', '宽带': 'expense_housing', 'WiFi': 'expense_housing',
  '维修': 'expense_housing', '修缮': 'expense_housing', '水管维修': 'expense_housing',
  '家电维修': 'expense_housing', '上门维修': 'expense_housing',
  '家具': 'expense_housing', '家电': 'expense_housing', '电器': 'expense_housing',
  '装修': 'expense_housing', '装饰': 'expense_housing', '软装': 'expense_housing',
  '窗帘': 'expense_housing', '灯': 'expense_housing', '灯具': 'expense_housing',
  '床垫': 'expense_housing', '枕头': 'expense_housing', '被子': 'expense_housing',
  '四件套': 'expense_housing', '床单': 'expense_housing',
  '搬家': 'expense_housing', '搬家费': 'expense_housing', '搬家公司': 'expense_housing',
  '押金': 'expense_housing', '中介费': 'expense_housing',
  '房贷': 'expense_housing', '按揭': 'expense_housing', '月供': 'expense_housing',
};

// 💊 医疗
const MEDICAL_KEYWORDS: Record<string, string> = {
  '药': 'expense_medical', '药品': 'expense_medical', '买药': 'expense_medical',
  '中药': 'expense_medical', '西药': 'expense_medical', '处方药': 'expense_medical',
  '感冒药': 'expense_medical', '止痛药': 'expense_medical', '消炎药': 'expense_medical',
  '创可贴': 'expense_medical',
  '看病': 'expense_medical', '就医': 'expense_medical', '门诊': 'expense_medical',
  '挂号': 'expense_medical', '挂号费': 'expense_medical', '诊费': 'expense_medical',
  '体检': 'expense_medical', '健康检查': 'expense_medical', '年度体检': 'expense_medical',
  '医院': 'expense_medical', '诊所': 'expense_medical', '药店': 'expense_medical',
  '牙科': 'expense_medical', '拔牙': 'expense_medical', '补牙': 'expense_medical',
  '洗牙': 'expense_medical', '牙齿矫正': 'expense_medical', '正畸': 'expense_medical',
  '眼科': 'expense_medical', '配眼镜': 'expense_medical', '验光': 'expense_medical',
  '眼镜': 'expense_medical', '隐形眼镜': 'expense_medical', '美瞳': 'expense_medical',
  '保健品': 'expense_medical', '维生素': 'expense_medical', '钙片': 'expense_medical',
  '鱼油': 'expense_medical', '益生菌': 'expense_medical',
  '口罩': 'expense_medical', '体温计': 'expense_medical', '血压计': 'expense_medical',
  '保险': 'expense_medical', '医疗保险': 'expense_medical', '商业保险': 'expense_medical',
  '手术': 'expense_medical', '住院': 'expense_medical', '化疗': 'expense_medical',
};

// 📚 教育
const EDUCATION_KEYWORDS: Record<string, string> = {
  '书': 'expense_education', '书籍': 'expense_education', '买书': 'expense_education',
  '教材': 'expense_education', '课本': 'expense_education', '参考书': 'expense_education',
  '课外书': 'expense_education', '小说': 'expense_education',
  '课程': 'expense_education', '网课': 'expense_education', '线上课程': 'expense_education',
  '培训': 'expense_education', '培训班': 'expense_education', '辅导班': 'expense_education',
  '补习': 'expense_education', '家教': 'expense_education',
  '学费': 'expense_education', '学杂费': 'expense_education', '书本费': 'expense_education',
  '考试': 'expense_education', '考证': 'expense_education', '报名费': 'expense_education',
  '考试费': 'expense_education', '培训费': 'expense_education',
  '文具': 'expense_education', '笔': 'expense_education', '本子': 'expense_education',
  '笔记本': 'expense_education', '打印': 'expense_education', '复印': 'expense_education',
  '文具店': 'expense_education',
  '学习': 'expense_education', '教育': 'expense_education', '知识付费': 'expense_education',
};

// 📱 通讯
const COMMUNICATION_KEYWORDS: Record<string, string> = {
  '话费': 'expense_communication', '手机费': 'expense_communication', '电话费': 'expense_communication',
  '流量': 'expense_communication', '流量包': 'expense_communication', '套餐': 'expense_communication',
  '充值': 'expense_communication', '充话费': 'expense_communication',
  '宽带': 'expense_communication', '宽带费': 'expense_communication',
  '手机': 'expense_communication', '手机壳': 'expense_communication', '手机膜': 'expense_communication',
  '配件': 'expense_communication', '耳机': 'expense_communication', '蓝牙耳机': 'expense_communication',
  '充电宝': 'expense_communication', '充电器': 'expense_communication', '充电线': 'expense_communication',
  '数据线': 'expense_communication', '手机支架': 'expense_communication',
  'SIM卡': 'expense_communication', '携号转网': 'expense_communication',
};

// 💳 金融
const FINANCE_KEYWORDS: Record<string, string> = {
  '理财': 'expense_finance', '理财产品': 'expense_finance',
  '股票': 'expense_finance', '炒股': 'expense_finance', '基金': 'expense_finance',
  '基金定投': 'expense_finance', 'ETF': 'expense_finance',
  '贷款': 'expense_finance', '借款': 'expense_finance', '借呗': 'expense_finance',
  '花呗': 'expense_finance', '白条': 'expense_finance', '京东白条': 'expense_finance',
  '还款': 'expense_finance', '还贷': 'expense_finance', '信用卡还款': 'expense_finance',
  '信用卡年费': 'expense_finance', '手续费': 'expense_finance', '转账费': 'expense_finance',
  '比特币': 'expense_finance', '加密货币': 'expense_finance',
};

// 📦 其他支出
const OTHER_EXPENSE_KEYWORDS: Record<string, string> = {
  '礼物': 'expense_other', '送礼': 'expense_other', '生日礼物': 'expense_other',
  '节日礼物': 'expense_other', '伴手礼': 'expense_other',
  '红包': 'expense_other', '随礼': 'expense_other', '份子钱': 'expense_other',
  '结婚红包': 'expense_other', '满月红包': 'expense_other',
  '捐赠': 'expense_other', '捐款': 'expense_other', '公益': 'expense_other', '慈善': 'expense_other',
  '罚款': 'expense_other', '罚金': 'expense_other', '违章罚款': 'expense_other',
  '维修': 'expense_other', '修理': 'expense_other',
  '宠物': 'expense_other', '猫粮': 'expense_other', '狗粮': 'expense_other',
  '宠物医院': 'expense_other', '宠物用品': 'expense_other', '猫砂': 'expense_other',
  '美容': 'expense_other', '美甲': 'expense_other', '美睫': 'expense_other',
  '化妆': 'expense_other', '化妆品': 'expense_other', '护肤品': 'expense_other',
  '香水': 'expense_other',
  '照片': 'expense_other', '打印照片': 'expense_other', '证件照': 'expense_other',
  '结婚': 'expense_other', '婚礼': 'expense_other', '婚庆': 'expense_other',
  '丧葬': 'expense_other', '白事': 'expense_other',
  '法律': 'expense_other', '律师': 'expense_other', '律师费': 'expense_other',
  '咨询': 'expense_other', '顾问费': 'expense_other',
  '其他': 'expense_other', '其他支出': 'expense_other', '杂项': 'expense_other',
  '其他费用': 'expense_other', '零散支出': 'expense_other',
};

// ==================== 合并所有支出关键词 ====================
const EXPENSE_KEYWORDS: Record<string, string> = {
  ...FOOD_KEYWORDS,
  ...TRANSPORT_KEYWORDS,
  ...DAILY_KEYWORDS,
  ...CLOTHING_KEYWORDS,
  ...ENTERTAINMENT_KEYWORDS,
  ...HOUSING_KEYWORDS,
  ...MEDICAL_KEYWORDS,
  ...EDUCATION_KEYWORDS,
  ...COMMUNICATION_KEYWORDS,
  ...FINANCE_KEYWORDS,
  ...OTHER_EXPENSE_KEYWORDS,
};

export interface QuickParseResult {
  items: {
    categoryId: string;
    type: 'income' | 'expense';
    amount: number;
    note: string;
  }[];
  errors: string[];
}

/**
 * 解析快捷输入文本
 * 支持格式：
 * - "面 12" → 1条记录
 * - "咖啡 25 打车 15" → 2条记录
 * - "面 12.5" → 支持小数
 */
export const parseQuickInput = (text: string): QuickParseResult => {
  const result: QuickParseResult = { items: [], errors: [] };
  const trimmed = text.trim();
  if (!trimmed) {
    result.errors.push('请输入内容');
    return result;
  }

  // 匹配模式：中文字符 + 空格 + 数字（支持小数和负数）
  const pattern = /([\u4e00-\u9fa5a-zA-Z\u4e00-\u9fa5]+)\s+(-?\d+(?:\.\d+)?)/g;
  let match;
  const matches: { keyword: string; amount: string }[] = [];

  while ((match = pattern.exec(trimmed)) !== null) {
    matches.push({ keyword: match[1], amount: match[2] });
  }

  if (matches.length === 0) {
    // 尝试反向匹配：数字在前，中文在后
    const reversePattern = /(-?\d+(?:\.\d+)?)\s+([\u4e00-\u9fa5a-zA-Z\u4e00-\u9fa5]+)/g;
    while ((match = reversePattern.exec(trimmed)) !== null) {
      matches.push({ keyword: match[2], amount: match[1] });
    }
  }

  if (matches.length === 0) {
    result.errors.push('格式：分类 金额，如"面 12"');
    return result;
  }

  for (const m of matches) {
    const amount = Math.abs(parseFloat(m.amount));
    if (isNaN(amount) || amount === 0) {
      result.errors.push(`"${m.amount}" 不是有效金额`);
      continue;
    }

    const keyword = m.keyword;
    let categoryId = '';
    let type: 'income' | 'expense' = 'expense';

    // 先查收入关键词
    if (INCOME_KEYWORDS[keyword]) {
      categoryId = INCOME_KEYWORDS[keyword];
      type = 'income';
    }
    // 再查支出关键词
    else if (EXPENSE_KEYWORDS[keyword]) {
      categoryId = EXPENSE_KEYWORDS[keyword];
      type = 'expense';
    }
    // 模糊匹配：包含关键词
    else {
      let found = false;
      // 查收入（收入优先）
      for (const [k, v] of Object.entries(INCOME_KEYWORDS)) {
        if (keyword.includes(k) || k.includes(keyword)) {
          categoryId = v;
          type = 'income';
          found = true;
          break;
        }
      }
      // 查支出
      if (!found) {
        for (const [k, v] of Object.entries(EXPENSE_KEYWORDS)) {
          if (keyword.includes(k) || k.includes(keyword)) {
            categoryId = v;
            type = 'expense';
            found = true;
            break;
          }
        }
      }
      // 未匹配到
      if (!found) {
        categoryId = 'expense_other';
        type = 'expense';
      }
    }

    result.items.push({
      categoryId,
      type,
      amount,
      note: keyword,
    });
  }

  return result;
};

/**
 * 多行解析：支持每行一条记录
 * 格式：
 *   面 12
 *   咖啡 25
 *   打车 15
 */
export const parseQuickInputMultiLine = (text: string): QuickParseResult => {
  const result: QuickParseResult = { items: [], errors: [] };
  const lines = text.split('\n').filter(line => line.trim());
  
  if (lines.length === 0) {
    result.errors.push('请输入内容');
    return result;
  }

  for (const line of lines) {
    const lineResult = parseQuickInput(line);
    result.items.push(...lineResult.items);
    result.errors.push(...lineResult.errors);
  }

  return result;
};

/**
 * 获取当前时间的 HH:MM 格式
 */
export const getCurrentTime = (): string => {
  const now = new Date();
  return `${String(now.getHours()).padStart(2, '0')}:${String(now.getMinutes()).padStart(2, '0')}`;
};

/**
 * 获取当前日期的 YYYY-MM-DD 格式
 */
export const getCurrentDate = (): string => {
  const now = new Date();
  const y = now.getFullYear();
  const m = String(now.getMonth() + 1).padStart(2, '0');
  const d = String(now.getDate()).padStart(2, '0');
  return `${y}-${m}-${d}`;
};
