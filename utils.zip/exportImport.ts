// Crypto polyfill for xlsx on Android
if (typeof globalThis.crypto === 'undefined') {
  (globalThis as any).crypto = {
    getRandomValues: (arr: Uint8Array) => {
      for (let i = 0; i < arr.length; i++) {
        arr[i] = Math.floor(Math.random() * 256);
      }
      return arr;
    },
    subtle: {
      digest: async () => new ArrayBuffer(0),
    },
  };
}
import * as XLSX from 'xlsx';
import { Platform } from 'react-native';
import * as FileSystem from 'expo-file-system';
import { Paths } from 'expo-file-system';
import * as LegacyFS from 'expo-file-system/legacy';
import * as Sharing from 'expo-sharing';

// atob polyfill for React Native Android
const atobPolyfill = (base64: string): string => {
  if (typeof atob === 'function') return atob(base64);
  // Manual base64 decode
  const chars = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/=';
  let result = '';
  let i = 0;
  base64 = base64.replace(/[^A-Za-z0-9+/=]/g, '');
  while (i < base64.length) {
    const a = chars.indexOf(base64.charAt(i++));
    const b = chars.indexOf(base64.charAt(i++));
    const c = chars.indexOf(base64.charAt(i++));
    const d = chars.indexOf(base64.charAt(i++));
    const h = ((a << 2) | (b >> 4)) & 255;
    const o = ((b & 15) << 4) | (c >> 2) & 255;
    const p = ((c & 3) << 6) | d & 255;
    result += String.fromCharCode(h);
    if (c !== 64) result += String.fromCharCode(o);
    if (d !== 64) result += String.fromCharCode(p);
  }
  return result;
};

// 中文表头映射
const HEADERS = {
  date: '日期',
  time: '时间',
  type: '类型',
  amount: '金额',
  categoryId: '分类',
  accountId: '账户',
  note: '备注',
  reimbursementStatus: '报销状态',
};

// 类型中文映射
const TYPE_MAP: Record<string, string> = {
  income: '收入',
  expense: '支出',
};

// 报销状态中文映射
const STATUS_MAP: Record<string, string> = {
  none: '无需报销',
  pending: '待报销',
  processing: '报销中',
  reimbursed: '已报销',
  rejected: '已驳回',
};

// 反向映射（中文 → 英文）
const TYPE_REVERSE: Record<string, string> = {
  '收入': 'income',
  '支出': 'expense',
};

const STATUS_REVERSE: Record<string, string> = {
  '无需报销': 'none',
  '待报销': 'pending',
  '已报销': 'reimbursed',
};

// 分类 ID → 中文名称
const CATEGORY_NAME_MAP: Record<string, string> = {
  expense_food: '餐饮', expense_transport: '交通', expense_daily: '日用',
  expense_clothing: '服饰', expense_entertainment: '娱乐', expense_housing: '住房',
  expense_medical: '医疗', expense_education: '教育', expense_communication: '通讯',
  expense_finance: '金融', expense_other: '其他支出',
  income_salary: '工资', income_bonus: '奖金', income_investment: '投资',
  income_parttime: '兼职', income_redpacket: '红包', income_reimbursement: '报销',
  income_other: '其他收入',
};

// 账户 ID → 中文名称
const ACCOUNT_NAME_MAP: Record<string, string> = {
  account_cash: '现金', account_bank: '银行卡', account_credit: '信用卡',
  account_alipay: '支付宝', account_wechat: '微信',
};

// 反向映射：中文名称 → ID
const CATEGORY_ID_MAP: Record<string, string> = {};
const ACCOUNT_ID_MAP: Record<string, string> = {};
Object.entries(CATEGORY_NAME_MAP).forEach(([id, name]) => { CATEGORY_ID_MAP[name] = id; });
Object.entries(ACCOUNT_NAME_MAP).forEach(([id, name]) => { ACCOUNT_ID_MAP[name] = id; });

// 智能分类映射（非标准名称 → 系统分类ID）
const SMART_CATEGORY_MAP: Record<string, string> = {
  // 餐饮相关
  '零食': 'expense_food', '饮料': 'expense_food', '水果': 'expense_food',
  '外卖': 'expense_food', '早餐': 'expense_food', '午餐': 'expense_food',
  '晚餐': 'expense_food', '夜宵': 'expense_food', '食材': 'expense_food',
  '奶茶': 'expense_food', '咖啡': 'expense_food', '甜品': 'expense_food',
  '快餐': 'expense_food', '小吃': 'expense_food', '火锅': 'expense_food',
  '烧烤': 'expense_food', '自助餐': 'expense_food', '聚餐': 'expense_food',
  // 日用相关
  '购物': 'expense_daily', '洗护': 'expense_daily', '超市': 'expense_daily',
  '快递': 'expense_daily', '理发': 'expense_daily', '生活费': 'expense_daily',
  '日用品': 'expense_daily', '清洁': 'expense_daily', '纸巾': 'expense_daily',
  '洗衣液': 'expense_daily', '牙膏': 'expense_daily', '沐浴露': 'expense_daily',
  '洗发水': 'expense_daily', '毛巾': 'expense_daily', '牙刷': 'expense_daily',
  '衣服架': 'expense_daily', '垃圾袋': 'expense_daily', '文具': 'expense_daily',
  '办公用品': 'expense_daily', '日用百货': 'expense_daily',
  // 交通相关
  '打车': 'expense_transport', '公交': 'expense_transport',
  '地铁': 'expense_transport', '加油': 'expense_transport',
  '滴滴': 'expense_transport', '高铁': 'expense_transport', '火车': 'expense_transport',
  '飞机': 'expense_transport', '机票': 'expense_transport', '停车费': 'expense_transport',
  '过路费': 'expense_transport', '共享单车': 'expense_transport', '骑行': 'expense_transport',
  '出租': 'expense_transport', '拼车': 'expense_transport', '顺风车': 'expense_transport',
  // 服饰相关
  '衣服': 'expense_clothing', '裤子': 'expense_clothing', '鞋子': 'expense_clothing',
  '袜子': 'expense_clothing', '帽子': 'expense_clothing', '内衣': 'expense_clothing',
  '外套': 'expense_clothing', 'T恤': 'expense_clothing', '羽绒服': 'expense_clothing',
  // 住房相关
  '房租': 'expense_housing', '水电': 'expense_housing', '物业': 'expense_housing',
  '网费': 'expense_housing', '电费': 'expense_housing', '水费': 'expense_housing',
  '燃气费': 'expense_housing', '暖气费': 'expense_housing', '家具': 'expense_housing',
  '家电': 'expense_housing', '维修': 'expense_housing', '装修': 'expense_housing',
  // 通讯相关
  '话费': 'expense_communication', '流量': 'expense_communication',
  '手机充值': 'expense_communication', '宽带': 'expense_communication',
  // 医疗相关
  '药': 'expense_medical', '看病': 'expense_medical', '体检': 'expense_medical',
  '挂号': 'expense_medical', '治疗': 'expense_medical', '住院': 'expense_medical',
  '药品': 'expense_medical', '保健': 'expense_medical', '保健品': 'expense_medical',
  // 教育相关
  '书': 'expense_education', '课程': 'expense_education', '培训': 'expense_education',
  '学费': 'expense_education', '考试费': 'expense_education', '文具': 'expense_education',
  '教材': 'expense_education', '网课': 'expense_education',
  // 娱乐相关
  '电影': 'expense_entertainment', '游戏': 'expense_entertainment',
  '旅游': 'expense_entertainment', 'KTV': 'expense_entertainment',
  '演出': 'expense_entertainment', '门票': 'expense_entertainment',
  '会员': 'expense_entertainment', '充值': 'expense_entertainment',
  // 金融相关
  '转账': 'expense_finance', '还款': 'expense_finance', '手续费': 'expense_finance',
  '利息': 'expense_finance', '投资': 'expense_finance',
  // 收入相关
  '红包收入': 'income_redpacket', '工资收入': 'income_salary', '奖金收入': 'income_bonus',
  '兼职收入': 'income_parttime', '理财收入': 'income_investment',
  // 其他支出
  '保险': 'expense_other', '捐赠': 'expense_other', '罚款': 'expense_other',
  '礼物': 'expense_other', '份子钱': 'expense_other', '请客': 'expense_other',
};

/**
 * 智能查找分类ID：精确匹配 → 智能映射 → 默认
 */
const resolveCategoryId = (name: string, type?: string): string => {
  if (CATEGORY_ID_MAP[name]) return CATEGORY_ID_MAP[name];
  if (SMART_CATEGORY_MAP[name]) return SMART_CATEGORY_MAP[name];
  return type === 'income' ? 'income_other' : 'expense_other';
};

/**
 * 生成默认文件名：账痕_2026-08-22_1530.xlsx
 */
export const generateFileName = (format: 'xlsx' | 'xls' | 'txt' | 'csv'): string => {
  const now = new Date();
  const y = now.getFullYear();
  const m = String(now.getMonth() + 1).padStart(2, '0');
  const d = String(now.getDate()).padStart(2, '0');
  const h = String(now.getHours()).padStart(2, '0');
  const min = String(now.getMinutes()).padStart(2, '0');
  return `账痕_${y}-${m}-${d}_${h}${min}.${format}`;
};

/**
 * 格式化交易数据为中文行数据
 */
const formatRows = (transactions: any[]): any[][] => {
  return transactions.map(tx => [
    tx.date,
    tx.time,
    TYPE_MAP[tx.type] || tx.type,
    tx.type === 'expense' ? -tx.amount : tx.amount,
    CATEGORY_NAME_MAP[tx.category_id] || tx.category_id,
    ACCOUNT_NAME_MAP[tx.account_id] || tx.account_id,
    tx.note || '',
    STATUS_MAP[tx.reimbursement_status] || tx.reimbursement_status || '无需报销',
  ]);
};

/**
 * 导出为 xlsx 格式
 */
export const exportToXlsx = async (transactions: any[]): Promise<{ success: boolean; message: string; fileName?: string }> => {
  try {
    if (transactions.length === 0) {
      return { success: false, message: '暂无数据可导出' };
    }

    const header = [Object.values(HEADERS)];
    const rows = formatRows(transactions);
    const data = [...header, ...rows];

    const ws = XLSX.utils.aoa_to_sheet(data);

    // 设置列宽
    ws['!cols'] = [
      { wch: 12 }, // 日期
      { wch: 8 },  // 时间
      { wch: 6 },  // 类型
      { wch: 10 }, // 金额
      { wch: 10 }, // 分类
      { wch: 10 }, // 账户
      { wch: 20 }, // 备注
      { wch: 10 }, // 报销状态
    ];

    const wb = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(wb, ws, '记账数据');

    const fileName = generateFileName('xlsx');
    const xlsxData = XLSX.write(wb, { type: 'array', bookType: 'xlsx' });

    if (Platform.OS === 'web') {
      const blob = new Blob([xlsxData], { type: 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet' });
      const url = URL.createObjectURL(blob);
      const link = document.createElement('a');
      link.href = url;
      link.download = fileName;
      document.body.appendChild(link);
      link.click();
      document.body.removeChild(link);
      URL.revokeObjectURL(url);
      return { success: true, message: `已导出 ${transactions.length} 条记录`, fileName };
    } else {
      const fileUri = Paths.document.uri + fileName;
      const base64 = btoa(String.fromCharCode(...new Uint8Array(xlsxData)));
      await LegacyFS.writeAsStringAsync(fileUri, base64, { encoding: LegacyFS.EncodingType.Base64 });
      if (await Sharing.isAvailableAsync()) {
        await Sharing.shareAsync(fileUri, {
          mimeType: 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
          UTI: 'public.xlsx',
        });
      }
      return { success: true, message: `已导出 ${transactions.length} 条记录`, fileName };
    }
  } catch (error: any) {
    return { success: false, message: error.message || '导出失败' };
  }
};

/**
 * 导出为 xls 格式
 */
export const exportToXls = async (transactions: any[]): Promise<{ success: boolean; message: string; fileName?: string }> => {
  try {
    if (transactions.length === 0) {
      return { success: false, message: '暂无数据可导出' };
    }

    const header = [Object.values(HEADERS)];
    const rows = formatRows(transactions);
    const data = [...header, ...rows];

    const ws = XLSX.utils.aoa_to_sheet(data);
    ws['!cols'] = [
      { wch: 12 }, { wch: 8 }, { wch: 6 }, { wch: 10 },
      { wch: 10 }, { wch: 10 }, { wch: 20 }, { wch: 10 },
    ];

    const wb = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(wb, ws, '记账数据');

    const fileName = generateFileName('xls');
    const xlsData = XLSX.write(wb, { type: 'array', bookType: 'xls' });

    if (Platform.OS === 'web') {
      const blob = new Blob([xlsData], { type: 'application/vnd.ms-excel' });
      const url = URL.createObjectURL(blob);
      const link = document.createElement('a');
      link.href = url;
      link.download = fileName;
      document.body.appendChild(link);
      link.click();
      document.body.removeChild(link);
      URL.revokeObjectURL(url);
      return { success: true, message: `已导出 ${transactions.length} 条记录`, fileName };
    } else {
      const fileUri = Paths.document.uri + fileName;
      const base64 = btoa(String.fromCharCode(...new Uint8Array(xlsData)));
      await LegacyFS.writeAsStringAsync(fileUri, base64, { encoding: LegacyFS.EncodingType.Base64 });
      if (await Sharing.isAvailableAsync()) {
        await Sharing.shareAsync(fileUri, {
          mimeType: 'application/vnd.ms-excel',
          UTI: 'com.microsoft.excel.xls',
        });
      }
      return { success: true, message: `已导出 ${transactions.length} 条记录`, fileName };
    }
  } catch (error: any) {
    return { success: false, message: error.message || '导出失败' };
  }
};

/**
 * 导出为 txt 格式（制表符分隔）
 */
export const exportToTxt = async (transactions: any[]): Promise<{ success: boolean; message: string; fileName?: string }> => {
  try {
    if (transactions.length === 0) {
      return { success: false, message: '暂无数据可导出' };
    }

    const header = Object.values(HEADERS).join('\t');
    const rows = transactions.map(tx =>
      [
        tx.date,
        tx.time,
        TYPE_MAP[tx.type] || tx.type,
        tx.type === 'expense' ? -tx.amount : tx.amount,
        CATEGORY_NAME_MAP[tx.category_id] || tx.category_id,
        ACCOUNT_NAME_MAP[tx.account_id] || tx.account_id,
        tx.note || '',
        STATUS_MAP[tx.reimbursement_status] || tx.reimbursement_status || '无需报销',
      ].join('\t')
    );

    const txt = '\uFEFF' + header + '\n' + rows.join('\n');
    const fileName = generateFileName('txt');

    if (Platform.OS === 'web') {
      const blob = new Blob([txt], { type: 'text/plain;charset=utf-8;' });
      const url = URL.createObjectURL(blob);
      const link = document.createElement('a');
      link.href = url;
      link.download = fileName;
      document.body.appendChild(link);
      link.click();
      document.body.removeChild(link);
      URL.revokeObjectURL(url);
      return { success: true, message: `已导出 ${transactions.length} 条记录`, fileName };
    } else {
      const fileUri = Paths.document.uri + fileName;
      await LegacyFS.writeAsStringAsync(fileUri, txt);
      if (await Sharing.isAvailableAsync()) {
        await Sharing.shareAsync(fileUri, { mimeType: 'text/plain', UTI: 'public.plain-text' });
      }
      return { success: true, message: `已导出 ${transactions.length} 条记录`, fileName };
    }
  } catch (error: any) {
    return { success: false, message: error.message || '导出失败' };
  }
};

/**
 * 导出为 CSV 格式（兼容旧版）
 */
export const exportToCsv = async (transactions: any[]): Promise<{ success: boolean; message: string; fileName?: string }> => {
  try {
    if (transactions.length === 0) {
      return { success: false, message: '暂无数据可导出' };
    }

    let csv = '\uFEFF日期,时间,类型,金额,分类,账户,备注,报销状态\n';
    transactions.forEach(tx => {
      const type = TYPE_MAP[tx.type] || tx.type;
      const status = STATUS_MAP[tx.reimbursement_status] || tx.reimbursement_status || '无需报销';
      const categoryName = CATEGORY_NAME_MAP[tx.category_id] || tx.category_id;
      const accountName = ACCOUNT_NAME_MAP[tx.account_id] || tx.account_id;
      const amount = tx.type === 'expense' ? -tx.amount : tx.amount;
      csv += `${tx.date},${tx.time},${type},${amount},${categoryName},${accountName},"${tx.note || ''}",${status}\n`;
    });

    const fileName = generateFileName('csv');

    if (Platform.OS === 'web') {
      const blob = new Blob([csv], { type: 'text/csv;charset=utf-8;' });
      const url = URL.createObjectURL(blob);
      const link = document.createElement('a');
      link.href = url;
      link.download = fileName;
      document.body.appendChild(link);
      link.click();
      document.body.removeChild(link);
      URL.revokeObjectURL(url);
      return { success: true, message: `已导出 ${transactions.length} 条记录`, fileName };
    } else {
      const fileUri = Paths.document.uri + fileName;
      await LegacyFS.writeAsStringAsync(fileUri, csv);
      if (await Sharing.isAvailableAsync()) {
        await Sharing.shareAsync(fileUri, { mimeType: 'text/csv', UTI: 'public.comma-separated-values-text' });
      }
      return { success: true, message: `已导出 ${transactions.length} 条记录`, fileName };
    }
  } catch (error: any) {
    return { success: false, message: error.message || '导出失败' };
  }
};

/**
 * 根据格式导出
 */
export const exportData = async (
  transactions: any[],
  format: 'xlsx' | 'xls' | 'txt' | 'csv' = 'xlsx'
): Promise<{ success: boolean; message: string; fileName?: string }> => {
  switch (format) {
    case 'xlsx': return exportToXlsx(transactions);
    case 'xls': return exportToXls(transactions);
    case 'txt': return exportToTxt(transactions);
    case 'csv': return exportToCsv(transactions);
    default: return exportToXlsx(transactions);
  }
};

/**
 * 解析 xlsx/xls 文件为数组
 */
const readFileAsArrayBuffer = (fileUri: string): Promise<ArrayBuffer> => {
  return new Promise((resolve, reject) => {
    if (Platform.OS !== 'web') {
      reject(new Error('readFileAsArrayBuffer only for web'));
      return;
    }
    fetch(fileUri)
      .then(res => res.arrayBuffer())
      .then(resolve)
      .catch(reject);
  });
};

const parseExcelFile = async (fileUri: string): Promise<any[][]> => {
  let arrayBuffer: ArrayBuffer;

  if (Platform.OS === 'web') {
    arrayBuffer = await readFileAsArrayBuffer(fileUri);
  } else {
    // Try new API first, fallback to legacy
    let base64 = '';
    try {
      base64 = await FileSystem.readAsStringAsync(fileUri, { encoding: FileSystem.EncodingType.Base64 });
    } catch (e) {
      try {
        base64 = await LegacyFS.readAsStringAsync(fileUri, { encoding: LegacyFS.EncodingType.Base64 });
      } catch (e2: any) {
        console.error('Both FileSystem APIs failed:', e?.message, e2?.message);
        throw new Error(`无法读取文件 (${e?.message || 'unknown'})`);
      }
    }
    const binary = atobPolyfill(base64);
    const bytes = new Uint8Array(binary.length);
    for (let i = 0; i < binary.length; i++) {
      bytes[i] = binary.charCodeAt(i);
    }
    arrayBuffer = bytes.buffer;
  }

  const workbook = XLSX.read(arrayBuffer, { type: 'array' });
  const firstSheet = workbook.Sheets[workbook.SheetNames[0]];
  return XLSX.utils.sheet_to_json(firstSheet, { header: 1 }) as any[][];
};

/**
 * 日期时间正则：2026-08-22 19:10:06 或 2026.08.22 19:10:06
 */
const DATETIME_REGEX = /^\d{4}[.-]\d{2}[.-]\d{2}[\s]+\d{2}:\d{2}(:\d{2})?$/;

/**
 * 解析合并的日期时间字符串，拆分为日期和时间
 * 支持格式：2026-08-22 19:10:06, 2026.08.22 19:10, 2026/08/22 19:10:06
 */
const parseCombinedDateTime = (value: string): { date: string; time: string } | null => {
  const s = value.trim();
  // 匹配: 2026-08-22 19:10:06 或 2026.08.22 19:10:06 或 2026/08/22 19:10:06
  const match = s.match(/^(\d{4})[.-](\d{1,2})[.-](\d{1,2})[\s]+(\d{1,2}):(\d{2})(?::(\d{2}))?/);
  if (match) {
    const [, year, month, day, hour, min, sec] = match;
    return {
      date: `${year}-${month.padStart(2, '0')}-${day.padStart(2, '0')}`,
      time: `${hour.padStart(2, '0')}:${min.padStart(2, '0')}`,
    };
  }
  // 匹配纯日期: 2026-08-22 或 2026.08.22
  const dateOnly = s.match(/^(\d{4})[.-](\d{1,2})[.-](\d{1,2})/);
  if (dateOnly) {
    const [, year, month, day] = dateOnly;
    return {
      date: `${year}-${month.padStart(2, '0')}-${day.padStart(2, '0')}`,
      time: '00:00',
    };
  }
  return null;
};

/**
 * 从任意值提取日期和时间（支持字符串、数字、Excel日期）
 */
const extractDateAndTime = (cell: any): { date: string; time: string } | null => {
  if (cell == null) return null;
  // 字符串格式
  if (typeof cell === 'string') {
    const s = cell.trim();
    // 完整日期时间
    if (DATETIME_REGEX.test(s)) {
      return parseCombinedDateTime(s);
    }
    // 纯日期字符串
    const parsed = parseCombinedDateTime(s);
    if (parsed) return parsed;
  }
  // Excel 数字格式
  if (typeof cell === 'number' && cell > 40000 && cell < 50000) {
    return excelDateToDateTime(cell);
  }
  return null;
};

/**
 * 从行数据解析交易记录（支持中文表头）
 */
const parseRowsToTransactions = (rows: any[][]): { date: string; time: string; type: string; amount: number; category_id: string; account_id: string; note: string; reimbursement_status: string }[] => {
  if (rows.length < 1) return [];

  // 检测是否为无表头的5列格式（第一列匹配日期时间）
  const firstDataRow = rows[0];
  const firstCell = firstDataRow?.[0];
  // 支持字符串日期和 Excel 数字日期
  const isStringDate = typeof firstCell === 'string' && DATETIME_REGEX.test(firstCell.trim());
  const isExcelDate = typeof firstCell === 'number' && firstCell > 40000 && firstCell < 50000;
  const isNoHeaderFormat = firstDataRow && firstDataRow.length >= 4 && (isStringDate || isExcelDate);

  if (isNoHeaderFormat) {
    // 5列无表头格式：日期时间\t分类\t类型\t金额\t备注
    return parseNoHeaderRows(rows);
  }

  // 有表头的标准格式
  if (rows.length < 2) return [];

  // 找到表头行（跳过无关列如：账本、计入收支、计入预算、图片）
  const headerRow = rows[0];
  const headerMap: Record<string, number> = {};

  headerRow.forEach((cell: any, idx: number) => {
    const cellStr = String(cell || '').trim();
    // 支持中英文表头（含小黑记账等第三方格式）
    if (cellStr === '日期' || cellStr === 'date' || cellStr === '时间') headerMap.date = idx;
    else if (cellStr === 'time') headerMap.time = idx;
    else if (cellStr === '类型' || cellStr === 'type' || cellStr === '收支类型') headerMap.type = idx;
    else if (cellStr === '金额' || cellStr === 'amount' || cellStr === '发生金额') headerMap.amount = idx;
    else if (cellStr === '分类' || cellStr === 'category_id' || cellStr === 'categoryId' || cellStr === '记账分类') headerMap.categoryId = idx;
    else if (cellStr === '账户' || cellStr === 'account_id' || cellStr === 'accountId') headerMap.accountId = idx;
    else if (cellStr === '备注' || cellStr === 'note' || cellStr === '描述') headerMap.note = idx;
    else if (cellStr === '报销状态' || cellStr === 'reimbursement_status') headerMap.reimbursementStatus = idx;
    // 忽略：账本、计入收支、计入预算、图片1~9、标签 等无关列
  });

  const transactions: any[] = [];
  for (let i = 1; i < rows.length; i++) {
    const row = rows[i];
    if (!row || row.length === 0) continue;

    const rawAmount = parseFloat(String(row[headerMap.amount ?? -1] || '0'));
    if (isNaN(rawAmount) || rawAmount === 0) continue;
    const amount = Math.abs(rawAmount);

    const rawType = String(row[headerMap.type ?? -1] || '支出');
    const rawStatus = String(row[headerMap.reimbursementStatus ?? -1] || '无需报销');

    // 处理日期字段：支持合并的日期时间、字符串、Excel 数字格式
    let dateStr = '';
    let timeStr = '';
    
    const dateCell = row[headerMap.date ?? -1];
    const dateCellStr = String(dateCell || '').trim();
    
    // 优先尝试从日期列解析（可能包含日期+时间）
    const parsed = extractDateAndTime(dateCell);
    if (parsed) {
      dateStr = parsed.date;
      timeStr = parsed.time;
    }
    
    // 如果有单独的时间列，优先使用
    if (headerMap.time != null) {
      const timeCell = String(row[headerMap.time] || '').trim();
      if (timeCell && /^\d{2}:\d{2}/.test(timeCell)) {
        timeStr = timeCell.slice(0, 5);
      }
    }
    
    // 如果日期为空或格式不对，使用默认值
    if (!dateStr || !/^\d{4}-\d{2}-\d{2}/.test(dateStr)) {
      dateStr = new Date().toISOString().slice(0, 10);
    }
    if (!timeStr || !/^\d{2}:\d{2}/.test(timeStr)) {
      timeStr = new Date().toTimeString().slice(0, 5);
    }
    
    transactions.push({
      date: dateStr,
      time: timeStr,
      type: TYPE_REVERSE[rawType] || rawType,
      amount,
      category_id: resolveCategoryId(String(row[headerMap.categoryId ?? -1] || ''), TYPE_REVERSE[rawType] || rawType),
      account_id: ACCOUNT_ID_MAP[String(row[headerMap.accountId ?? -1] || '')] || String(row[headerMap.accountId ?? -1] || 'account_wechat'),
      note: String(row[headerMap.note ?? -1] || ''),
      reimbursement_status: STATUS_REVERSE[rawStatus] || rawStatus || 'none',
    });
  }

  return transactions;
};

/**
 * 解析无表头的5列格式：日期时间\t分类\t类型\t金额\t备注
 */
/**
 * 将 Excel 数字日期时间转换为 YYYY-MM-DD HH:MM 格式
 * Excel 日期：整数部分是天数（从1900-01-01开始），小数部分是一天中的时间
 */
const excelDateToDateTime = (serial: number): { date: string; time: string } | null => {
  // Excel 日期基准：1899-12-30（考虑1900年闰年bug）
  const excelEpoch = new Date(1899, 11, 30).getTime();
  const msPerDay = 86400000;
  
  const totalMs = excelEpoch + serial * msPerDay;
  const d = new Date(totalMs);
  
  if (isNaN(d.getTime())) return null;
  
  const year = d.getFullYear();
  const month = String(d.getMonth() + 1).padStart(2, '0');
  const day = String(d.getDate()).padStart(2, '0');
  const hours = String(d.getHours()).padStart(2, '0');
  const minutes = String(d.getMinutes()).padStart(2, '0');
  
  return {
    date: `${year}-${month}-${day}`,
    time: `${hours}:${minutes}`,
  };
};

const parseNoHeaderRows = (rows: any[][]): { date: string; time: string; type: string; amount: number; category_id: string; account_id: string; note: string; reimbursement_status: string }[] => {
  const transactions: any[] = [];

  for (const row of rows) {
    if (!row || row.length < 4) continue;

    let date = '';
    let time = '';
    
    const cell0 = row[0];
    
    // 使用 extractDateAndTime 解析各种日期格式
    const parsed = extractDateAndTime(cell0);
    if (parsed) {
      date = parsed.date;
      time = parsed.time;
    } else {
      // 最后尝试：去掉可能的分隔符后解析
      const dateTimeStr = String(cell0 || '').trim();
      const match = dateTimeStr.match(/^(\d{4})[.\-/](\d{1,2})[.\-/](\d{1,2})[\s]+(\d{1,2}):(\d{2})(?::(\d{2}))?/);
      if (!match) continue;
      date = `${match[1]}-${match[2].padStart(2, '0')}-${match[3].padStart(2, '0')}`;
      time = `${match[4].padStart(2, '0')}:${match[5]}`;
    }

    const categoryName = String(row[1] || '').trim();
    const rawType = String(row[2] || '支出').trim();
    const rawAmount = parseFloat(String(row[3] || '0'));
    if (isNaN(rawAmount) || rawAmount === 0) continue;

    const type = TYPE_REVERSE[rawType] || 'expense';
    const amount = Math.abs(rawAmount);

    // 备注：第5列起全部作为备注
    const note = row.slice(4).join(' ').trim();

    transactions.push({
      date,
      time,
      type,
      amount,
      category_id: resolveCategoryId(categoryName, type),
      account_id: 'account_wechat',
      note,
      reimbursement_status: 'none',
    });
  }

  return transactions;
};

/**
 * 导入 xlsx/xls 文件
 */
export const importExcelFile = async (fileUri: string): Promise<{ success: boolean; message: string; transactions?: any[] }> => {
  try {
    const rows = await parseExcelFile(fileUri);
    const transactions = parseRowsToTransactions(rows);

    if (transactions.length === 0) {
      return { success: false, message: '文件为空或格式不正确' };
    }

    return { success: true, message: `解析成功，共 ${transactions.length} 条记录`, transactions };
  } catch (error: any) {
    return { success: false, message: error.message || '文件解析失败' };
  }
};

/**
 * 导入 txt/csv 文件
 */
export const importTextFile = async (text: string): Promise<{ success: boolean; message: string; transactions?: any[] }> => {
  try {
    const lines = text.split('\n').filter(l => l.trim());
    if (lines.length < 1) {
      return { success: false, message: '文件为空或格式不正确' };
    }

    // 检测分隔符
    const firstLine = lines[0];
    const separator = firstLine.includes('\t') ? '\t' : ',';

    // 检测是否为无表头格式
    const firstParts = firstLine.split(separator).map(h => h.trim().replace(/^"|"$/g, ''));
    const isNoHeader = firstParts.length >= 4 && DATETIME_REGEX.test(firstParts[0]);

    if (isNoHeader) {
      // 无表头格式
      const rows: any[][] = lines.map(line => {
        const parts: string[] = [];
        let current = '';
        let inQuotes = false;
        for (const ch of line) {
          if (ch === '"') { inQuotes = !inQuotes; continue; }
          if (ch === separator && !inQuotes) { parts.push(current); current = ''; continue; }
          current += ch;
        }
        parts.push(current);
        return parts;
      });
      const transactions = parseNoHeaderRows(rows);
      if (transactions.length === 0) {
        return { success: false, message: '未找到有效数据' };
      }
      return { success: true, message: `解析成功，共 ${transactions.length} 条记录`, transactions };
    }

    // 有表头格式
    const headerParts = firstParts;
    const headerMap: Record<string, number> = {};
    headerParts.forEach((cell, idx) => {
      if (cell === '日期' || cell === 'date') headerMap.date = idx;
      else if (cell === '时间' || cell === 'time') headerMap.time = idx;
      else if (cell === '类型' || cell === 'type') headerMap.type = idx;
      else if (cell === '金额' || cell === 'amount') headerMap.amount = idx;
      else if (cell === '分类' || cell === 'category_id') headerMap.categoryId = idx;
      else if (cell === '账户' || cell === 'account_id') headerMap.accountId = idx;
      else if (cell === '备注' || cell === 'note') headerMap.note = idx;
      else if (cell === '报销状态' || cell === 'reimbursement_status') headerMap.reimbursementStatus = idx;
    });

    const transactions: any[] = [];
    for (let i = 1; i < lines.length; i++) {
      const line = lines[i].trim();
      if (!line) continue;

      // 简单的 CSV 行解析（处理引号）
      const parts: string[] = [];
      let current = '';
      let inQuotes = false;
      for (const ch of line) {
        if (ch === '"') { inQuotes = !inQuotes; continue; }
        if (ch === separator && !inQuotes) { parts.push(current); current = ''; continue; }
        current += ch;
      }
      parts.push(current);

      const rawAmount = parseFloat(parts[headerMap.amount ?? -1] || '0');
      if (isNaN(rawAmount) || rawAmount === 0) continue;
      const amount = Math.abs(rawAmount);

      const rawType = parts[headerMap.type ?? -1] || '支出';
      const rawStatus = parts[headerMap.reimbursementStatus ?? -1] || '无需报销';

      transactions.push({
        date: parts[headerMap.date ?? -1] || new Date().toISOString().slice(0, 10),
        time: parts[headerMap.time ?? -1] || new Date().toTimeString().slice(0, 5),
        type: TYPE_REVERSE[rawType] || rawType,
        amount,
        category_id: resolveCategoryId(parts[headerMap.categoryId ?? -1] || '', TYPE_REVERSE[rawType] || rawType),
        account_id: ACCOUNT_ID_MAP[parts[headerMap.accountId ?? -1] || ''] || parts[headerMap.accountId ?? -1] || 'account_wechat',
        note: (parts[headerMap.note ?? -1] || '').replace(/^"|"$/g, ''),
        reimbursement_status: STATUS_REVERSE[rawStatus] || rawStatus || 'none',
      });
    }

    if (transactions.length === 0) {
      return { success: false, message: '未找到有效数据' };
    }

    return { success: true, message: `解析成功，共 ${transactions.length} 条记录`, transactions };
  } catch (error: any) {
    return { success: false, message: error.message || '文件解析失败' };
  }
};

/**
 * 通用导入函数（自动检测文件类型）
 */
export const importFile = async (fileUri: string, fileName: string): Promise<{ success: boolean; message: string; transactions?: any[] }> => {
  const ext = fileName.toLowerCase().split('.').pop() || '';

  if (ext === 'xlsx' || ext === 'xls') {
    return importExcelFile(fileUri);
  } else if (ext === 'txt' || ext === 'csv') {
    if (Platform.OS === 'web') {
      const response = await fetch(fileUri);
      const text = await response.text();
      return importTextFile(text);
    } else {
      // Try new API first, fallback to legacy
      let text = '';
      try {
        text = await FileSystem.readAsStringAsync(fileUri, { encoding: FileSystem.EncodingType.UTF8 });
      } catch (e) {
        try {
          text = await LegacyFS.readAsStringAsync(fileUri, { encoding: LegacyFS.EncodingType.UTF8 });
        } catch (e2) {
          console.error('Failed to read text file:', e2);
          throw new Error('无法读取文件，请检查文件权限');
        }
      }
      return importTextFile(text);
    }
  }

  return { success: false, message: `不支持的文件格式: .${ext}` };
};

/**
 * 从 base64 数据导入文件（绕过 content URI 读取失败的问题）
 */
export const importFileFromBase64 = async (base64Data: string, fileName: string): Promise<{ success: boolean; message: string; transactions?: any[] }> => {
  const ext = fileName.toLowerCase().split('.').pop() || '';

  if (ext === 'xlsx' || ext === 'xls') {
    // 将 base64 转换为 ArrayBuffer
    const binary = atobPolyfill(base64Data);
    const bytes = new Uint8Array(binary.length);
    for (let i = 0; i < binary.length; i++) {
      bytes[i] = binary.charCodeAt(i);
    }
    const arrayBuffer = bytes.buffer;
    const workbook = XLSX.read(arrayBuffer, { type: 'array' });
    const firstSheet = workbook.Sheets[workbook.SheetNames[0]];
    const rows = XLSX.utils.sheet_to_json(firstSheet, { header: 1 }) as any[][];
    const transactions = parseRowsToTransactions(rows);
    if (transactions.length === 0) {
      return { success: false, message: '文件中没有找到有效的记账数据' };
    }
    return { success: true, message: `解析到 ${transactions.length} 条记录`, transactions };
  } else if (ext === 'txt' || ext === 'csv') {
    // 将 base64 转换为文本
    const text = atobPolyfill(base64Data);
    return importTextFile(text);
  }

  return { success: false, message: `不支持的文件格式: .${ext}` };
};
