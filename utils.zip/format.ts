import dayjs from 'dayjs';

export const formatCurrency = (amount: number): string => {
  return `¥${amount.toFixed(2)}`;
};

export const formatCurrencyShort = (amount: number): string => {
  if (amount >= 10000) {
    return `¥${(amount / 10000).toFixed(1)}万`;
  }
  return `¥${amount.toFixed(0)}`;
};

export const formatDate = (date: string): string => {
  return dayjs(date).format('YYYY-MM-DD');
};

export const formatDateChinese = (date: string): string => {
  return dayjs(date).format('M月D日');
};

export const formatTime = (time: string): string => {
  return time || '--:--';
};

export const getWeekday = (date: string): string => {
  const weekdays = ['周日', '周一', '周二', '周三', '周四', '周五', '周六'];
  return weekdays[dayjs(date).day()];
};

export const getToday = (): string => {
  return dayjs().format('YYYY-MM-DD');
};

export const getCurrentTime = (): string => {
  return dayjs().format('HH:mm');
};

export const getCurrentYear = (): string => {
  return dayjs().format('YYYY');
};

export const getCurrentYearMonth = (): string => {
  return dayjs().format('YYYY-MM');
};

export const getMonthName = (month: string): string => {
  const monthNum = parseInt(month);
  const names = ['一月', '二月', '三月', '四月', '五月', '六月', '七月', '八月', '九月', '十月', '十一月', '十二月'];
  return names[monthNum - 1] || month;
};

export const getDaysInMonth = (year: string, month: string): number => {
  return dayjs(`${year}-${month}-01`).daysInMonth();
};

export const generateDateRange = (startDate: string, endDate: string): string[] => {
  const dates: string[] = [];
  let current = dayjs(startDate);
  const end = dayjs(endDate);
  while (current.isBefore(end) || current.isSame(end)) {
    dates.push(current.format('YYYY-MM-DD'));
    current = current.add(1, 'day');
  }
  return dates;
};
